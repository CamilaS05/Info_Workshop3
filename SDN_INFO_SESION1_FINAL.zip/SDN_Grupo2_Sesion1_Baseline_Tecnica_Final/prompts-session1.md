# Registro de ingeniería de prompts — Sesión 1

**Proyecto:** SDN Controller/Router educativo, Grupo 2. **Propósito:** documentar técnica, objetivo, texto de consulta, criterio de revisión y refinamiento. La evidencia verificable de revisión corresponde al informe SPDR aportado y a las correcciones registradas; los ejemplos de consultas aquí redactados **no se hacen pasar por conversaciones ejecutadas literalmente**.

## 1. Técnicas y seis prompts de especificación

### P1 — Contextual framing

**Objetivo:** delimitar los procesos, obligaciones y restricciones; FR-01–10, NFR-01–09.

> Contexto: dos aplicaciones Python académicas independientes, Controller y Router, comunicadas por REST/JSON. Controller administra topología persistente y calcula rutas Bellman-Ford; Router solicita ruta HTTP y registra reenvío simulado. MVC y DAO son obligatorios en ambos procesos. La etapa actual permite especificaciones y diagramas, pero no código. Devuelve alcance, límites, dependencias, FR con identificador y criterios verificables; distingue responsabilidades entre dos roles.

**Criterio de crítica:** descartar Router que calcule rutas o servicios que abran archivos.

### P2 — Structured prompting

**Objetivo:** exigir trazabilidad y criterios cuantificables; FR-01–10 y NFR-01–11.

> Organiza una tabla de FR-01 a FR-10 con entrada, proceso, salida, condición de error, aceptación medible, servicio responsable y prueba propuesta. Organiza otra para NFR-01 a NFR-11 y método de verificación. Incluye contrato `GET /route` con `src`, `dst`, `path`, `metric`, `total_cost` y `topology_version`; métricas por retardo, ancho inverso y pérdida; y errores separados `NODE_NOT_FOUND` y `ROUTE_NOT_FOUND`. No inventes resultados de pruebas.

**Criterio de crítica:** los once NFR deben tener mecanismos verificables, con fixture fijo para NFR-10.

### P3 — Role prompting

**Objetivo:** auditar MVC/DAO/DI como arquitecto revisor; SPDR-02 y SPDR-03.

> Actúa como revisor estricto de diseño orientado a objetos. Inspecciona separación Controller/Router, MVC, DAO, services, inyección, y límites de almacenamiento. Exige motor `BellmanFordEngine.compute(weighted_graph,src,dst)` independiente de DAO, y almacenamiento de topología con una fuente autoritativa, snapshots y compromiso atómico. Devuelve hallazgos clasificados y clases/métodos concretos que deben figurar en diagramas. No generes implementación Python.

**Criterio de crítica:** rechazar ruta negativa probada en un motor diferente del productivo o DAO sin control concurrente.

### P4 — Few-shot examples

**Objetivo:** conservar consistencia del contrato; FR-05/07/09, NFR-04.

> Usa los siguientes ejemplos de formato. Ejemplo A, éxito: `GET /route?src=A&dst=D&metric=delay` → 200 `{"src":"A","dst":"D","path":["A","B","D"],"metric":"delay","total_cost":5.0,"topology_version":1}`. Ejemplo B, error: consulta con nodo válido sin conexión → 404 `{"error":{"code":"ROUTE_NOT_FOUND","message":"No existe camino"}}`. Con el mismo estilo especifica los seis endpoints mínimos y respuestas para `NODE_NOT_FOUND`, `CONTROLLER_UNAVAILABLE`, `CONTROLLER_BAD_RESPONSE` y `LOG_WRITE_FAILED`. Identifica qué errores se registran en JSONL y bajo qué prioridad. No generes código.

**Criterio de crítica:** no confundir dato de origen con camino, no omitir `src/dst`, no confundir fake HTTP con integración real.

### P5 — Iterative refinement (dos consultas consecutivas)

**Objetivo:** convertir revisión en cambios comprobables; SPDR-01–10.

> Revisión inicial: evalúa los seis documentos frente a la guía y a una revisión SPDR. Localiza requisitos satisfechos y contradicciones sobre desempate Bellman-Ford, prueba de ciclo negativo, transacciones de topología e integración HTTP. Devuelve una lista priorizada con impacto, documentos y casos de prueba afectados. Evita código fuente.

> Refinamiento: conserva el diseño MVC/DAO válido. Modifica requisitos, diagramas, contratos, plan y pruebas para resolver todos los hallazgos prioritarios: motor ponderado independiente, desempate lexicográfico preciso, commits atómicos, dos procesos en TC-23, JSONL, benchmark fijo y errores de respuesta del Controller. Entrega una matriz de coherencia y riesgos remanentes. No afirmes aprobación humana o pruebas ejecutadas.

**Criterio de crítica:** una revisión se considera aplicada únicamente cuando la solución aparece en **todos** los documentos afectados.

### P6 — Ambigüedades y juicio técnico

**Objetivo:** contrastar decisiones; FR-02/03/04/06/07 y NFR-08.

> Identifica al menos tres ambigüedades que impiden escribir pruebas reproducibles. Para cada una, compara dos opciones, explica su impacto en requisitos, arquitectura y contrato, y propone una decisión técnica justificada. Considera grafo dirigido/no dirigido, empate de rutas, ruta simple ante costo cero, manejo de `p=1`, versión ante operaciones repetidas, atomicidad de escrituras y semántica de cliente HTTP falso frente a HTTP real.

**Criterio de crítica:** cada decisión debe tener una verificación independiente; las propuestas no constituyen confirmaciones personales.

## 2. Registro verificable de revisión técnica y refinamiento

Se utilizó como insumo un **informe de revisión técnica SPDR** con diez hallazgos concretos. El resumen siguiente refleja exclusivamente los hallazgos aportados y los cambios incorporados en esta línea base, sin atribuir respuestas ficticias a P1–P6.

| Insumo real de crítica | Problema detectado | Corrección incorporada | Verificación diseñada |
|---|---|---|---|
| SPDR-01 | Desempate lexicográfico sin procedimiento | Distancias Bellman-Ford, aristas ajustadas, búsqueda de camino simple lexicográfico con factibilidad | `01` §3; TC-21 |
| SPDR-02 | Test de ciclo negativo sin interfaz del motor | `BellmanFordEngine.compute(weighted_graph,src,dst)` accesible en unidad | `02` §2; TC-14 |
| SPDR-03 | Persistencia y concurrencia incompletas | JSON autoritativo, candado, snapshot y reemplazo atómico | `02` §4; TC-24–26 |
| SPDR-04 | Fake HTTP presentado como posible integración | TC-05 aislado y TC-23 end-to-end obligatorio en dos procesos | `06` §2 y §3 |
| SPDR-05 | Log JSONL y duplicados indefinidos | Esquema estable y `event_id` único; `packet_id` reutilizable | `04` §8; TC-29 |
| SPDR-06 | Fixture de rendimiento variable | Topología benchmark de 100 nodos/300 enlaces y reglas reproducibles | `01` NFR-10; TC-12 |
| SPDR-07 | Timeout solo simulado | Servidor HTTP lento de prueba y TC-27 | `01` NFR-11; TC-27 |
| SPDR-08 | Respuestas defectuosas del Controller | 502 `CONTROLLER_BAD_RESPONSE` y cinco causas | `04` §6/9; TC-28 |
| SPDR-09 | Origen/destino inconsistentes entre modelos | `src/dst` normativos en Route y RouteData | `04` §4; TC-01/28 |
| SPDR-10 | Cronograma sin reserva | Ruta crítica, prioridades y cinco minutos de contingencia | `05` §3 |

## 3. Ambigüedades resueltas en la propuesta de diseño

| Cuestión | Alternativas | Decisión de especificación y razón | Prueba |
|---|---|---|---|
| Dirección del grafo | Dirigido / no dirigido | No dirigido; correspondencia natural de enlaces de la práctica | TC-16/17 |
| Desempate | Dependiente del orden / lexicográfico | Ruta simple lexicográficamente menor entre distancias óptimas; incluye costo cero | TC-21 |
| Versión | Cada POST / solo cambio efectivo | Solo se incrementa cuando el archivo confirma estado cambiado | TC-17/24 |
| Pérdida total | Usar enlace para ciertas métricas / excluirlo | `p=1` excluido para todas las métricas | TC-22 |
| Estado | Cache mutable / JSON único | JSON persistido con snapshot y reemplazo atómico | TC-24–26 |
| Integración | Fake / HTTP real | Fake para unidad; dos procesos y HTTP real para TC-23 | TC-05/23 |
| Identificador de paquetes | Deduplicar / aceptar repetidos | Se aceptan repeticiones de `packet_id`, con nuevo `event_id` por intento | TC-29 |

## 4. Estado de evidencias de prompting

El contenido anterior es una **especificación reproducible de técnicas y refinamientos** con una crítica SPDR efectivamente aportada. Las evidencias originales de ejecución literal de P1–P6 y capturas de conversación no están embebidas en el ZIP y no se etiquetan como realizadas. El espacio `demo-evidence/` permite incorporarlas si se dispone de tales registros. La aprobación por el equipo se refleja en `ACTA_REVISION_BASELINE.md`; no es sustituida por IA.

**Principio seguido:** los requisitos definen resultados esperados, los diagramas representan el diseño, la evaluación técnica detecta discrepancias, y la conformidad del software se verifica posteriormente mediante código y pruebas reales.
