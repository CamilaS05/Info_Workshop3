# Matriz de coherencia de la especificación

| Decisión contractual | Requisitos | Arquitectura | Secuencias | API | Plan | Pruebas |
|---|---|---|---|---|---|---|
| Dos procesos HTTP independientes | FR-05/07 | `ControllerClient`, APIs y Views | Secuencia 1 | GET /route y POST /packets | T6–T8 | TC-05/23 |
| Bellman-Ford con desempate lexicográfico | FR-03 | `BellmanFordEngine` | Secuencia 1 | GET /route | T3 | TC-01/21 |
| Ciclos negativos por motor interno | FR-03 | Motor puro sobre `Graph` | Error técnico no productivo | 422 NEGATIVE_CYCLE | T3 | TC-14 |
| Estado persistente, atómico y con versión | FR-01/06 | `JsonTopologyDAO`, candado | Secuencia 2 | POST /links | T2/T4 | TC-17/24/25/26 |
| Diferencia nodo ausente/camino ausente | FR-09 | `RoutingService` | Secuencia 2 | 404 específicos | T4 | TC-10 |
| Errores de red y JSON inválido | FR-07/09 | `ControllerClient` | Secuencia 3 | 503 y 502 | T6/T7 | TC-07/27/28 |
| JSONL append con intentos repetidos | FR-10 | `ForwardingRecord`, DAO | Secuencias 1 y 3 | Registro normativo | T5 | TC-18/29 |
| Fallo de log prevalece sobre 200/404/502/503 | FR-10 | `ForwardingService` | Secuencia 3 | 500 LOG_WRITE_FAILED | T7 | TC-18 |
| Rendimiento fijo | NFR-10 | `ControllerAPI` y motor | Consulta ruta | GET /route | T9 | TC-12 |
| Timeout lógico y real | NFR-11 | `ControllerClient` | Secuencia 3 | 503 | T9 | TC-13/27 |
| MVC/DAO/DI ambas apps | NFR-01/02/07/09 | Componentes y clases | Tres secuencias | Capa REST | T1–T7 | TC-08/09/11 |

## Estado de los artefactos

- **Especificado:** FR/NFR, seis diagramas Mermaid, seis endpoints, reglas de error, pruebas, responsables, riesgos y correcciones SPDR.
- **Pendiente de ejecución:** software Python, `pytest`, pruebas de red, latencias y registros de `test-results.txt`.
- **Pendiente de constancia:** conformidad individual consignada en `ACTA_REVISION_BASELINE.md`; no se presumen aprobaciones.
