# Diagramas de arquitectura

Se incluyen **seis diagramas**: uno de componentes, dos de clases y tres de secuencia. Las fuentes `.mmd` se extraen de los bloques `mermaid` de las especificaciones 02 y 03. Las imágenes PNG son representaciones esquemáticas de referencia; las fuentes Mermaid constituyen el diagrama editable normativo.

| Fuente | Tipo / documento |
|---|---|
| `02-componentes.mmd` | Componentes y conexión REST — 02 §1 |
| `03-clases-controller.mmd` | Clases Controller — 02 §2 |
| `04-clases-router.mmd` | Clases Router — 02 §3 |
| `05-secuencia-forwarding.mmd` | Forwarding exitoso — 03 §2 |
| `06-secuencia-enlace.mmd` | Fallo, ruta y restauración — 03 §3 |
| `07-secuencia-timeout.mmd` | Timeout, error y persistencia — 03 §4 |
