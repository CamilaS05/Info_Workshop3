# Validación interna de la propuesta S1-v1

## Comprobaciones documentales

| Control | Resultado esperado de esta revisión |
|---|---|
| Requisitos | 10 funcionales (FR-01–10) y 11 no funcionales (NFR-01–11) |
| API mínima | 6 endpoints, con `GET /health` en ambos procesos |
| Diagrama estático | 1 de componentes y 2 de clases |
| Diagramas dinámicos | 3 secuencias conforme a los escenarios de la guía |
| Diseño Bellman-Ford | Motor ponderado independiente, desempate lexicográfico y ciclo negativo defensivo |
| Estado persistente | Un archivo JSON autoritativo, snapshots, candado y sustitución atómica |
| Pruebas planificadas | TC-01–TC-29, con TC-08/09 obligatorias y TC-23 HTTP real |
| Calidad medible | NFR-10 con fixture congelado; NFR-11 con fake y servidor HTTP controlado |
| Revisión SPDR | SPDR-01–10 vinculados a correcciones y test |
| Sin código de implementación | Carpetas `controller/`, `router/`, `tests/` reservadas |

**Alcance de la verificación:** estructura y coherencia de documentos, validación sintáctica de JSON de ejemplo, comparación de fuentes Mermaid y cálculo matemático de las rutas del fixture de referencia. No certifica compilación, cobertura de pruebas, rendimiento, funcionamiento HTTP o conformidad humana.
