# Revisión de diseño — Cierre documental de hallazgos SPDR

El informe de revisión técnica examinó requisitos, arquitectura, secuencias, contrato, trazabilidad, verificación y viabilidad. Su diagnóstico original identificó cuatro hallazgos mayores y seis menores. Esta tabla registra el **cierre por especificación**, no la ejecución funcional de pruebas ni una nueva calificación oficial.

| Hallazgo | Riesgo identificado | Solución en línea base | Prueba para validar implementación | Cierre documental |
|---|---|---|---|---|
| SPDR-01 (mayor) | Desempate no determinista entre caminos óptimos | Bellman-Ford + aristas ajustadas + recorrido lexicográfico simple con factibilidad | TC-21 | Especificado |
| SPDR-02 (mayor) | Test de ciclo negativo sin interfaz ejecutable | `BellmanFordEngine.compute(weighted_graph,src,dst)` para producción y unidad | TC-14 | Especificado |
| SPDR-03 (mayor) | Topología/versiones inconsistentes o no durables | Fuente JSON única, candado, snapshot, archivo temporal y replace atómico | TC-24/25/26 | Especificado |
| SPDR-04 (mayor) | Fake HTTP confundido con integración | TC-05 aislado, TC-23 con procesos y red real | TC-05/23 | Especificado |
| SPDR-05 | Log y política de duplicados ambiguos | JSONL normativo, `event_id` UUID único, `packet_id` repetido admitido | TC-29 | Especificado |
| SPDR-06 | Benchmark p95 no reproducible | Fixture fijo, hash, carga y percentil definidos | TC-12 | Especificado |
| SPDR-07 | Timeout no probado en transporte | Simulación de 20 fallos y cinco intentos con servidor local lento | TC-13/27 | Especificado |
| SPDR-08 | Errores de contrato Controller incompletos | Validación de respuesta y 502 ante JSON/campos/estados inválidos | TC-28 | Especificado |
| SPDR-09 | Route sin `src`/`dst` uniformes | Campos normativos en modelos y API de ruta | TC-01/28 | Especificado |
| SPDR-10 | Tiempo y contingencia indefinidos | Etapas paralelas, camino crítico y reserva dentro de 108 minutos | `05` §3 | Especificado |

## Riesgos residuales y alcance de garantías

**Garantía de versión:** el candado de DAO solo cubre un proceso Controller y un worker, sin otros escritores; no pretende ser bloqueo distribuido. Las rutas informan la versión de su snapshot: una actualización concurrente puede comprometerse después de la consulta sin invalidar retroactivamente su consistencia.

**Persistencia:** el punto de confirmación es el reemplazo atómico del archivo. Errores anteriores se revierten sin publicar cambio; no se promete durabilidad de hardware ante pérdida eléctrica arbitraria.

**Precisión de costos:** el desempate se rige por una tolerancia numérica explícita y un chequeo de costo; para producción todos los pesos válidos son no negativos. La prueba de ciclo negativo utiliza un grafo interno artificial.

**Evidencia:** documentos y fixtures disponibles no sustituyen imágenes de ejecución de los prompts exactos ni pruebas de software. Un resultado PASS solo puede registrarse tras ejecución real.
