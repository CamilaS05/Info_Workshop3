# Registro de evidencias de la etapa de diseño

## Evidencia que sí se encuentra en la carpeta

| Elemento | Soporte documental | Estado |
|---|---|---|
| 6 especificaciones con referencias cruzadas | `specs/01` a `specs/06` | Disponible |
| 6 diagramas fuente editables | `diagramas/*.mmd` | Disponible |
| 6 representaciones PNG de consulta | `diagramas/*.png` | Disponible |
| Topología A–D y topología con nodo aislado E | `ejemplos/*.json` | Disponible |
| Benchmark congelado y hash | `ejemplos/topology-benchmark.json` y `BENCHMARK.md` | Disponible |
| Crítica técnica SPDR y cambios de diseño | `REVISION_SPDR.md`, `prompts-session1.md` | Disponible |
| Aprobación personal firmada | `ACTA_REVISION_BASELINE.md` | Sin constancia |
| Capturas auténticas de ejecuciones de prompts concretos | `demo-evidence/` | No incorporadas |
| Capturas o resultados de software | No corresponden a la especificación | No aplica |

## Alcance del material gráfico

Los archivos `.mmd` son las fuentes editables contractuales. Los PNG ilustran sus participantes y relaciones, pero no sustituyen una verificación gráfica en el renderizador Mermaid. La carpeta está diseñada para preservar evidencia que pueda verificarse sin producir capturas o resultados simulados.

## Revisión documental

El conjunto de diseño aborda SPDR-01–SPDR-10; la conformidad final queda vinculada al acta de revisión. Los resultados automáticos del software se registrarán en la fase de implementación y nunca se reportan como pruebas ya aprobadas en este paquete.
