# 04. Contrato API REST/JSON — SDN educativo / Bellman-Ford

**Línea base propuesta:** S1-v1 · **Formato:** UTF-8, `Content-Type: application/json`; puertos configurables (`Controller:8000`, `Router:8001` como valores predeterminados). Este documento define **interfaces propuestas**, no peticiones ejecutadas.

## 1. Convenciones obligatorias

- Todas las respuestas con error siguen `{"error":{"code":"CODIGO","message":"Descripcion"}}`. Los códigos y sus estados HTTP **son contractuales**; el texto de `message` es explicativo y puede incluir detalles sin alterar el código.
- Los identificadores de nodo son cadenas no vacías (sensibles a mayúsculas). `metric` es exactamente `delay`, `inverse_bandwidth` o `loss`; campos adicionales no previstos se rechazan con 400 `INVALID_INPUT` para mantener esquemas estables.
- La capa View convierte errores de validación de FastAPI/Pydantic, incluido su posible 422 por defecto, a **400 `INVALID_INPUT`**. `422 NEGATIVE_CYCLE` se reserva para el diagnóstico algorítmico; topologías productivas no admiten pesos negativos.
- La respuesta de ruta **incluye `src` y `dst`** de forma obligatoria, además de camino, métrica, costo y versión. Se conserva el contrato JSON de manera uniforme en `Route`, `RouteData` y respuestas HTTP. Las rutas son listas de nodos en orden; el costo y la versión describen **un mismo snapshot**.
- `GET /health` informa solo sobre la aplicación consultada. La respuesta 200 del Router no equivale a salud del Controller.

## 2. Endpoints mínimos (cumplimiento de la guía)

| Aplicación | Método y endpoint | Propósito y éxito |
|---|---|---|
| Controller | **GET `/topology`** | Topología vigente, HTTP 200 |
| Controller | **GET `/route?src=A&dst=D&metric=delay`** | Ruta Bellman-Ford, métrica, costo, versión, HTTP 200 |
| Controller | **POST `/links/fail`** | Deshabilitar un enlace, HTTP 200 |
| Controller | **POST `/links/restore`** | Restaurar un enlace, HTTP 200 |
| Router | **POST `/packets`** | Simular reenvío y devolver traza/estado, HTTP 200 |
| Ambos | **GET `/health`** | Disponibilidad del proceso, HTTP 200 |

## 3. Controller — GET /topology

Sin cuerpo ni parámetros. Respuesta HTTP 200, idéntica al contenido validado de `topology.json`:

```json
{
  "nodes": ["A", "B", "C", "D"],
  "links": [
    {"source":"A","target":"B","delay_ms":2,"bandwidth_mbps":10,"loss_probability":0.01,"enabled":true},
    {"source":"B","target":"D","delay_ms":3,"bandwidth_mbps":10,"loss_probability":0.02,"enabled":true},
    {"source":"A","target":"C","delay_ms":4,"bandwidth_mbps":20,"loss_probability":0.02,"enabled":true},
    {"source":"C","target":"D","delay_ms":5,"bandwidth_mbps":20,"loss_probability":0.03,"enabled":true}
  ],
  "topology_version": 1
}
```

`nodes` es un arreglo de cadenas únicas; `links` es un arreglo de enlaces no dirigidos distintos; `topology_version` es entero ≥1. Un enlace admite retardo finito ≥0, ancho finito >0, pérdida finita ∈[0,1] y booleano `enabled`. `JsonTopologyDAO` controla el almacenamiento. Si falla la lectura durante operación: HTTP 503 `TOPOLOGY_UNAVAILABLE`. Una topología inválida **al iniciar** rechaza el arranque, por lo que aún no existe API disponible.

## 4. Controller — GET /route

Solicitud: `GET /route?src=A&dst=D&metric=delay`. Parámetros `src`, `dst`, `metric` obligatorios. Respuesta 200:

```json
{"src":"A","dst":"D","path":["A","B","D"],"metric":"delay","total_cost":5.0,"topology_version":1}
```

Tipos: `src`, `dst`, `metric` cadenas; `path` arreglo no vacío de cadenas; `total_cost` número finito ≥0 en producción; `topology_version` entero ≥1. `src=dst` produce `[src]` y 0, si el nodo existe. La salida corresponde a una instantánea única e incluye el desempate por camino simple lexicográficamente menor dentro de la tolerancia especificada en `01-requirements.md` §3. Métricas: `delay` (ms), `inverse_bandwidth` (suma de 1/Mbps), `loss` (suma de `-ln(1-p)` adimensional). Enlaces inactivos o con `p=1` se excluyen en todas.

**Errores distintos:** 400 `INVALID_INPUT` si faltan campos o `metric` es inválida; 404 `NODE_NOT_FOUND` si un nodo no existe; 404 `ROUTE_NOT_FOUND` cuando ambos existen pero no hay ruta; 422 `NEGATIVE_CYCLE` si el motor recibe un grafo de ensayo inválido con ciclo negativo alcanzable (imposible con datos productivos válidos); 503 `TOPOLOGY_UNAVAILABLE` si el DAO no puede leer un estado confirmado.

## 5. Controller — POST /links/fail y POST /links/restore

Ambos reciben el cuerpo JSON:

```json
{"source":"B","target":"D"}
```

Tras fallar el enlace B—D en topología base se retorna HTTP 200:

```json
{"link":{"source":"B","target":"D","enabled":false},"topology_version":2}
```

Después de restaurarlo se retorna HTTP 200:

```json
{"link":{"source":"B","target":"D","enabled":true},"topology_version":3}
```

En grafo no dirigido B—D y D—B refieren al mismo enlace. Repetir una operación ya aplicada devuelve 200 con **la misma versión**. Se entrega HTTP 200 **solo después** de reemplazar de manera atómica el JSON persistido. Un error de escritura previo al compromiso conserva estado y versión y devuelve 500 `TOPOLOGY_WRITE_FAILED`. Enlace inexistente: 404 `LINK_NOT_FOUND`; parámetros inválidos: 400 `INVALID_INPUT`; problema de lectura durante operación: 503 `TOPOLOGY_UNAVAILABLE`. La versión no se incrementa por consultas GET.

## 6. Router — POST /packets

Cuerpo JSON válido (todos los campos obligatorios; `payload` puede ser cadena vacía):

```json
{"packet_id":"pkt-001","src":"A","dst":"D","metric":"delay","payload":"hola"}
```

Salida HTTP 200 tras recibir ruta válida y guardar el registro:

```json
{"packet_id":"pkt-001","status":"delivered","trace":["A","B","D"],"route_cost":5.0,"metric":"delay","topology_version":1}
```

`packet_id`, `src`, `dst` son cadenas no vacías, `metric` está en las tres opciones, `payload` es cadena. `trace` copia **sin modificaciones** `RouteData.path` del Controller. La salida de Router no afirma envío físico. El cliente HTTP valida `src`, `dst`, métrica, estructura y tipos de la respuesta: si el Controller responde con un par `src/dst` o métrica diferentes, JSON inválido, campos incompletos, traza mal formada o status inesperado, se obtiene 502 `CONTROLLER_BAD_RESPONSE`; no se acepta silenciosamente.

**Errores:** 400 `INVALID_INPUT` por esquema de paquete (se rechaza **antes** de contar intento); 404 `NODE_NOT_FOUND` / `ROUTE_NOT_FOUND` (respuesta válida del Controller, propagada); 503 `CONTROLLER_UNAVAILABLE` por conexión/timeout de 2 s; 502 `CONTROLLER_BAD_RESPONSE` por JSON/esquema/estado HTTP imprevistos, incluido 5xx no contemplado del Controller. Si el Controller responde 503 `TOPOLOGY_UNAVAILABLE`, Router lo trata como 503 `CONTROLLER_UNAVAILABLE` (no hay ruta consultable). Errores de validación 400 válidos del Controller se pueden propagar. Todos los intentos aceptados por el Router, exitosos o fallidos, se registran antes de responder; si el registro falla, prevalece 500 `LOG_WRITE_FAILED`.

## 7. Ambos — GET /health

Controller, HTTP 200:

```json
{"status":"ok","application":"controller"}
```

Router, HTTP 200:

```json
{"status":"ok","application":"router"}
```

No se consulta el otro proceso ni se realizan escrituras de logs para `/health`.

## 8. Esquema normativo de persistencia del Router — JSONL (SPDR-05)

Cada línea de `forwarding.jsonl` es **un objeto JSON independiente** con los siguientes campos obligatorios:

```json
{"event_id":"e2c43992-8e1f-47af-8662-0dd29ec0d123","packet_id":"pkt-001","src":"A","dst":"D","metric":"delay","status":"delivered","trace":["A","B","D"],"route_cost":5.0,"topology_version":1,"error_code":null,"error_message":null}
```

- `event_id`: UUID único generado por el Router **para cada intento**, independiente de `packet_id`.
- `packet_id`: identificador suministrado por cliente; **duplicados permitidos** y registrados como **eventos distintos**, sin sobrescritura ni deduplicación.
- `status`: `delivered` o `failed`. En `failed`, `trace=[]` si no se recibió ruta; `route_cost` y `topology_version` son `null` si no están disponibles; `error_code` y `error_message` contienen la causa. En `delivered`, ambos errores son `null`.
- `src`, `dst`, `metric` reflejan la solicitud ya validada. `trace` es arreglo de cadenas. El DAO añade una línea JSON completa por intento bajo escritura sincronizada; un fallo de append genera `LOG_WRITE_FAILED` (500), sin declarar guardado.

Ejemplo de intento fallido por timeout:

```json
{"event_id":"e6d2f0b1-93c3-4340-9b46-e2a3780a2345","packet_id":"pkt-002","src":"A","dst":"D","metric":"delay","status":"failed","trace":[],"route_cost":null,"topology_version":null,"error_code":"CONTROLLER_UNAVAILABLE","error_message":"No se pudo consultar al Controller"}
```

## 9. Códigos HTTP, casos y prioridades

| HTTP | `error.code` | Causa |
|---|---|---|
| 400 | `INVALID_INPUT` | JSON o parámetros inválidos, campos no permitidos, métrica desconocida. |
| 404 | `NODE_NOT_FOUND` | `src` o `dst` válido pero inexistente. |
| 404 | `ROUTE_NOT_FOUND` | Nodos válidos y presentes, sin ruta. |
| 404 | `LINK_NOT_FOUND` | Enlace sin correspondencia en la topología. |
| 422 | `NEGATIVE_CYCLE` | Detección defensiva de ciclo negativo alcanzable. |
| 500 | `TOPOLOGY_WRITE_FAILED` | Fallo de escritura **antes** del reemplazo atómico (Controller). |
| 503 | `TOPOLOGY_UNAVAILABLE` | Estado persistido inaccesible en operación (Controller). |
| 503 | `CONTROLLER_UNAVAILABLE` | Controller inaccesible, timeout o respuesta explícita 503 por topología no disponible (Router). |
| 502 | `CONTROLLER_BAD_RESPONSE` | Contrato/JSON/estado HTTP inesperados al consultar al Controller (Router). |
| 500 | `LOG_WRITE_FAILED` | El DAO del Router no confirmó la persistencia del intento. |

Ejemplo 404 `NODE_NOT_FOUND`:

```json
{"error":{"code":"NODE_NOT_FOUND","message":"El nodo X no existe"}}
```

Ejemplo 404 `ROUTE_NOT_FOUND`:

```json
{"error":{"code":"ROUTE_NOT_FOUND","message":"No existe un camino entre A y E"}}
```

Ejemplo 502:

```json
{"error":{"code":"CONTROLLER_BAD_RESPONSE","message":"El Controller devolvio una respuesta incompatible"}}
```

Ejemplo 500 de topología:

```json
{"error":{"code":"TOPOLOGY_WRITE_FAILED","message":"No se pudo confirmar el cambio del enlace"}}
```

**Prioridad:** a) entrada mal formada antes de forwarding → 400 sin registro; b) intento aceptado → consulta y resultado/error; c) se persiste evento; d) si el DAO falla, **siempre** 500 `LOG_WRITE_FAILED`, sustituyendo 200/404/502/503; si guarda bien se emite la respuesta original. El Router no propaga errores 500 internos del Controller como si fueran una ruta válida.

## 10. Aceptación contractual y límites

- Los seis endpoints de la guía existen con los métodos descritos; `GET /route` incluye seis campos normativos (`src`, `dst`, `path`, `metric`, `total_cost`, `topology_version`).
- Las respuestas de error tienen forma estable con 400/404/502/503/500/422 según la matriz; los frameworks no exponen su 422 genérico en violación del contrato.
- `POST /links/fail` confirma cambio solo tras persistencia, conserva idempotencia y versión, y cumple el límite de un trabajador Controller.
- Un intento de paquete produce evento JSONL con esquema estable y `event_id` nuevo aunque se repita `packet_id`.
- Las comprobaciones contractuales unitarias están en TC-20, TC-28/29; la integración HTTP **real** con ambos procesos está en TC-23. Las pruebas se ejecutan en la fase de implementación.
