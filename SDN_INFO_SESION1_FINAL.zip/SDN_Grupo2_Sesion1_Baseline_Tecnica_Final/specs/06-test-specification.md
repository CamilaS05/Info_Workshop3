# 06. Especificación de pruebas — SDN educativo / Bellman-Ford

**Línea base propuesta:** S1-v1 · **Estado:** casos definidos; **no ejecutados** en la etapa de especificación. La ejecución, las aserciones automatizadas y el archivo de resultados corresponden a la implementación.

## 1. Fixtures, entorno y reglas de aislamiento

- `ejemplos/topology-example.json`: A–B (2 ms, 10 Mbps, p=0.01), B–D (3 ms, 10 Mbps, p=0.02), A–C (4 ms, 20 Mbps, p=0.02), C–D (5 ms, 20 Mbps, p=0.03), versión 1.
- `ejemplos/topology-isolated-example.json`: mismos cuatro enlaces y **nodo E sin enlaces**. Consultar A→E debe producir `ROUTE_NOT_FOUND`; A→Z debe producir `NODE_NOT_FOUND`.
- `ejemplos/topology-benchmark.json`: fixture **congelado**, exactamente 100 nodos `N000`–`N099` y 300 aristas no dirigidas distintas, generado con `i=0..99`, pasos `s∈{1,2,5}`, enlace entre `N(i)` y `N((i+s) mod 100)`, `delay_ms=1+((17i+13s) mod 9)`, `bandwidth_mbps=10`, `loss_probability=0.01`, `enabled=true`, versión 1. Su SHA-256 se registra en `ejemplos/BENCHMARK.md`.
- Las pruebas que modifican la topología copian el fixture a un **archivo temporal** y usan un Controller nuevo. Cada caso empieza con versión 1 a menos que se indique explícitamente una secuencia dentro del mismo caso. No se altera el fixture original.
- Puertos de ejemplo Controller 8000 y Router 8001, configurables. Ensayos en localhost, un worker Controller, sin escritores externos. Para TC-23 se ejecutan **dos procesos reales separados**; para TC-05 se usa doble HTTP. Nunca se interpreta uno como evidencia del otro.
- Enrutamiento defensivo TC-14: el motor recibe directamente un `nx.DiGraph` artificial; la validación de la topología JSON productiva no se modifica.

## 2. Catálogo de casos automatizados (TC-01 a TC-29)

| ID | Preparación/entrada | Aserciones y resultado esperado | Componente / tipo | FR/NFR |
|---|---|---|---|---|
| **TC-01** | GET ruta A→D `delay` con fixture base | HTTP 200, `src=A`, `dst=D`, `path=[A,B,D]`, costo 5, versión 1 | Controller / contrato | FR-03/05 |
| **TC-02** | Consultar tres métricas del fixture base | `delay`: [A,B,D] costo 5; `inverse_bandwidth`: [A,C,D] costo 0.1; `loss`: [A,B,D] costo aproximado 0.030253 | Motor / unidad | FR-04 |
| **TC-03** | Fallar B–D y consultar A→D | 200 fallo, versión 2, `[A,C,D]`, costo 9, versión 2 | Controller / integración local | FR-06 |
| **TC-04** | Después de TC-03, restaurar B–D | 200, versión 3, `[A,B,D]`, costo 5 | Controller / integración local | FR-06 |
| **TC-05** | `FakeHTTPTransport` devuelve ruta JSON completa | Cliente arma `GET /route` con `src,dst,metric`, valida respuesta y produce `RouteData`, sin red real. **No cuenta como end-to-end.** | Router / contrato aislado | FR-07, NFR-03 |
| **TC-06** | `POST /packets` con ruta del Controller simulada | 200 delivered, trace `[A,B,D]`, existe registro **antes** de respuesta | Router / servicio | FR-08/10 |
| **TC-07** | Controller apagado durante `POST /packets` | 503 `CONTROLLER_UNAVAILABLE`, evento failed guardado, Router `/health` 200 | Router / error | FR-09/10, NFR-06 |
| **TC-08** | `RoutingService` con `FakeTopologyDAO` | Obtiene ruta esperada **sin servidor, archivos reales ni DAO concreto**; constructor acepta fake | Arquitectura / unidad **obligatoria** | NFR-02/07/09 |
| **TC-09** | `ForwardingService` con `FakeForwardingLogDAO` y cliente fake | `save` invocado una vez por intento, traza correcta; sin disco ni Controller | Arquitectura / unidad **obligatoria** | FR-10, NFR-02/07/09 |
| **TC-10** | Fixture aislado; GET A→Z y GET A→E | Primer 404 `NODE_NOT_FOUND`, segundo 404 `ROUTE_NOT_FOUND` | Controller / contrato | FR-09 |
| **TC-11** | Inspección de código y DI | APIs sin algoritmos ni acceso directo a archivos; MVC/DAO en ambas apps; prueba de sustitución con fakes | Arquitectura / estática | NFR-01/02/03/07 |
| **TC-12** | Fixture exacto benchmark. 10 warmup + 100 GET secuenciales A→N050 sobre localhost, Controller un worker | Todas las respuestas 200 y versión 1; 100 duraciones de HTTP medidas, p95 = valor 95 ordenado ≤500 ms; reportar CPU/OS/carga y hash | Rendimiento / integración | NFR-10 |
| **TC-13** | 20 fallos simulados de timeout/conexión, timeout configurado 2 s | 20/20 HTTP 503 en ≤3 s; logs `failed`, Router `/health` 200; **solo** acredita control lógico | Router / fake temporalizado | NFR-11 |
| **TC-14** | `BellmanFordEngine.compute()` con grafo dirigido de prueba: A→B peso 1, B→C peso -3, C→B peso 1, C→D peso 1 | `NegativeCycleError` por ciclo B–C–B alcanzable desde A. **Segunda aserción separada:** `ControllerAPI` con servicio inyectado que lanza ese error ⇒ 422 `NEGATIVE_CYCLE`. JSON productivo con peso negativo sigue inválido. | Motor + API / dos unidades | FR-03 |
| **TC-15** | DAO carga fixture válido; después copia con JSON corrupto | Lectura correcta en normal; topología inicial inválida rechaza arranque sin exponer API falsa | DAO / unidad | FR-01 |
| **TC-16** | Lineal, malla, desconectada con aislados | Los tres grafos se representan sin cambios en servicios | Controller / unidad | FR-02 |
| **TC-17** | Fail B–D dos veces, restore dos veces | Versiones `2,2,3,3`; estado y archivo alineados | Controller / DAO | FR-06 |
| **TC-18** | Fake DAO de logs falla al guardar resultado, tanto éxito como error Controller | En ambos casos 500 `LOG_WRITE_FAILED`, no 200 ni 503; Router health 200 | Router / unidad | FR-10, NFR-06 |
| **TC-19** | Cambiar todas las variables de configuración | Puertos, URLs, timeout y paths usados efectivamente sin alterar servicios | Bootstrap / configuración | NFR-05 |
| **TC-20** | JSON mal formado, campo vacío, métrica desconocida y campo adicional | 400 `INVALID_INPUT` con `error.code/message`, no 422 de framework; `GET /health` 200 | Ambas API / contrato | FR-05/09, NFR-04/06 |
| **TC-21** | Empate con A–B(1), B–C(1), C–D(1), B–E(1), E–D(1): A–B–C–D frente A–B–E–D, ambos costo 3; permutar orden de enlaces; además empate con ciclo de costo 0 A–B(0), B–C(0), B–D(1), C–D(1) | En el primer grafo siempre `[A,B,C,D]`; en el segundo `[A,B,C,D]` (más lexicográfico que `[A,B,D]`), **sin repetir nodos**, independientemente de orden de inserción; costo óptimo verificado | Motor / unidad | FR-03, SPDR-01 |
| **TC-22** | `loss_probability=1` en un enlace esencial | Enlace excluido de todas las métricas, sin calcular `ln(0)`; se usa alternativa o se informa ausencia de ruta | Builder / unidad | FR-04 |
| **TC-23** | **Levantar Controller y Router reales en dos procesos**, topología temporal v1; enviar `POST /packets` al puerto Router | Comprobar Router 200, `trace=[A,B,D]`, costo 5, versión 1; **evidenciar** `GET /route` del Router al Controller mediante log HTTP/proxy; verificar nueva línea de JSONL con `event_id`, `packet_id`, trace y status. Prohibidos fakes o `TestClient` como sustituto de esta prueba | **End-to-end REAL obligatoria** | FR-05/07/08/10, NFR-04, SPDR-04 |
| **TC-24** | Sustituir operación de reemplazo atómico por fake que falla **antes** del commit | 500 `TOPOLOGY_WRITE_FAILED`; bytes del JSON, versión y `enabled` inalterados; nueva ruta igual a previa; ningún temporal residual | DAO / error | FR-06, SPDR-03 |
| **TC-25** | Confirmar fallo B–D, detener Controller, crear una nueva instancia desde mismo archivo | Tras reinicio `enabled=false`, versión 2 y ruta alternativa costo 9; restaurar y reiniciar recupera versión 3 | DAO / reinicio | FR-01/06, SPDR-03 |
| **TC-26** | Ejecutar solicitudes de ruta simultáneas con fallo/restauración bajo mismo Controller y un worker | Cada respuesta es coherente: v1/v3 ⇒ `[A,B,D]` costo 5; v2 ⇒ `[A,C,D]` costo 9; nunca mezcla ruta de una versión y número de otra; JSON permanece válido | DAO / concurrencia | FR-03/06, SPDR-03 |
| **TC-27** | Cliente HTTP real contra servidor local deliberadamente lento (>2 s), cinco veces | Cada intento produce 503 `CONTROLLER_UNAVAILABLE` y límite de 3 s; evidencia temporización real de transporte (distinta de TC-13) | Router / transporte | FR-09, NFR-11, SPDR-07 |
| **TC-28** | Respuesta del Controller: JSON inválido, campos ausentes, src/dst contradictorios, status 204, 500 inesperado | Cada respuesta resulta en 502 `CONTROLLER_BAD_RESPONSE` con log failed; `GET /health` Router 200 | Cliente HTTP / contrato | FR-07/09, NFR-04, SPDR-08/09 |
| **TC-29** | Dos `POST /packets` con el mismo `packet_id` y rutas correctas | Dos líneas JSONL, `event_id` distintos, `packet_id` repetido admitido; todos los campos normativos y JSON válido | Log DAO / persistencia | FR-10, SPDR-05 |

## 3. Validación cruzada de las correcciones SPDR

| Hallazgo | Diseño verificable | Test mínimo de cierre |
|---|---|---|
| SPDR-01 | Aristas ajustadas, selección lexicográfica con test de alcanzabilidad sin nodos ya usados | TC-21 (dos empates y orden permutado) |
| SPDR-02 | `BellmanFordEngine.compute(weighted_graph,src,dst)`, independiente de DAO | TC-14 en **mismo motor** + aserción API 422 |
| SPDR-03 | Fuente única, lock, snapshot, compromiso por `replace`, reinicio | TC-24, TC-25, TC-26 |
| SPDR-04 | Diferenciación real HTTP y doble HTTP | TC-05 **aislado** y TC-23 **end-to-end real** |
| SPDR-05 | Evento JSONL `event_id` y duplicados definidos | TC-29 |
| SPDR-06 | Benchmark congelado con 100 nodos/300 aristas y hash | TC-12 |
| SPDR-07 | Fake lógico + servidor local lento | TC-13 y TC-27 |
| SPDR-08 | Mapeo 502 ante errores del Controller | TC-28 |
| SPDR-09 | Ruta con `src`, `dst` normativos | TC-01 y TC-28 |
| SPDR-10 | Camino crítico y reserva en 108 minutos | `05-implementation-plan.md` §3 |

## 4. Selección prioritaria, calidad y aceptación

La guía exige **al menos ocho pruebas automatizadas aprobadas** e incluye expresamente **TC-08 y TC-09**. El alcance de verificación mínima prevista incluye TC-01, TC-03, TC-04, TC-05, TC-06, **TC-08**, **TC-09** y **TC-23**; el test end-to-end real **no se sustituye** por dobles HTTP. Los hallazgos P0 cuentan además con TC-14, TC-21 y TC-24–26 definidos, aunque su ejecución puede requerir más trabajo que el mínimo de ocho; toda prueba sin ejecutar se consigna como pendiente. La revisión arquitectónica TC-11 se documenta incluso si hay ocho resultados verdes.

**Evidencia futura:** `test-results.txt` debe registrar test, estado verdadero PASS/FAIL/PENDING, entorno, comando, salida y motivo si falla; TC-12 conserva las 100 muestras y el hash del fixture; TC-13 y TC-27 almacenan duraciones individualizadas; TC-23 incluye evidencia de **dos procesos en marcha, petición HTTP y registro persistido**. No se presentan valores ni capturas fabricadas de la Sesión 2.
