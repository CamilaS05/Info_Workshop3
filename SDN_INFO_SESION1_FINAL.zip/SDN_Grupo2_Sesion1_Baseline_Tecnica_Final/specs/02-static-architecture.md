# 02. Arquitectura estática — SDN educativo / Bellman-Ford

**Línea base:** S1-v1 · **Cobertura:** componentes, clases, responsabilidades, MVC, DAO e inyección de dependencias.

## 1. Diagrama de componentes

```mermaid
flowchart LR
  U[Cliente REST]
  subgraph R[Proceso Router - worker independiente]
    RB[RouterBootstrap - DI]
    RA[RouterAPI - Controller MVC]
    RV[RouterViews - JSON]
    RM[Packet / ForwardingResult / RouteData]
    FS[ForwardingService]
    HC[ControllerClient - HTTP]
    FL[ForwardingLogDAO - interfaz]
    JL[JsonlForwardingLogDAO]
    LOG[(forwarding.jsonl)]
    RB -. configura .-> RA
    RB -. inyecta .-> FS
    RB -. construye .-> HC
    RB -. construye .-> JL
    RA --> RV
    RA --> FS
    FS --> RM
    FS --> HC
    FS --> FL
    JL -. implementa .-> FL
    JL --> LOG
  end
  subgraph C[Proceso Controller - un worker]
    CB[ControllerBootstrap - DI]
    CA[ControllerAPI - Controller MVC]
    CV[ControllerViews - JSON]
    CM[Topology / Link / Route]
    LS[LinkService]
    RS[RoutingService]
    WG[WeightedGraphBuilder]
    BF[BellmanFordEngine]
    TD[TopologyDAO - interfaz]
    JD[JsonTopologyDAO - lock y escritura atomica]
    TOPO[(topology.json - estado autoritativo)]
    CB -. configura .-> CA
    CB -. inyecta .-> LS
    CB -. inyecta .-> RS
    CB -. construye .-> JD
    CA --> CV
    CA --> RS
    CA --> LS
    RS --> TD
    RS --> WG
    RS --> BF
    RS --> CM
    LS --> TD
    JD -. implementa .-> TD
    JD --> TOPO
  end
  U -->|POST /packets| RA
  U -->|GET /topology, GET /route, POST /links, GET /health| CA
  HC -->|HTTP GET /route JSON| CA
```

El Controller es propietario exclusivo de `topology.json` y el Router de `forwarding.jsonl`. Las dependencias puntadas representan construcción o implementación; las continuas llamadas. El Router **no comparte modelos Python ni archivos** con el Controller. El cliente HTTP usa el contrato, no la clase `Route` del otro proceso.

## 2. Diagrama de clases — Controller

```mermaid
classDiagram
  class Topology {
    +list nodes
    +list links
    +int topology_version
  }
  class Link {
    +str source
    +str target
    +float delay_ms
    +float bandwidth_mbps
    +float loss_probability
    +bool enabled
  }
  class Route {
    +str src
    +str dst
    +list path
    +str metric
    +float total_cost
    +int topology_version
  }
  class PathResult {
    +list path
    +float total_cost
  }
  class TopologyDAO {
    <<interface>>
    +get_topology() Topology
    +set_link_status(src,dst,enabled) Topology
  }
  class JsonTopologyDAO {
    +str file_path
    +Lock state_lock
    +get_topology() Topology
    +set_link_status(src,dst,enabled) Topology
  }
  class WeightedGraphBuilder {
    +build(topology,metric) Graph
  }
  class BellmanFordEngine {
    +compute(weighted_graph,src,dst) PathResult
  }
  class RoutingService {
    +TopologyDAO topology_dao
    +WeightedGraphBuilder builder
    +BellmanFordEngine engine
    +get_route(src,dst,metric) Route
  }
  class LinkService {
    +TopologyDAO topology_dao
    +get_topology() Topology
    +set_status(src,dst,enabled) Topology
  }
  class ControllerViews {
    <<View>>
    +TopologyResponse
    +RouteResponse
    +LinkStateRequest
    +LinkStateResponse
    +ErrorResponse
  }
  class ControllerAPI {
    +get_topology()
    +get_route(src,dst,metric)
    +fail_link(source,target)
    +restore_link(source,target)
    +health()
  }
  class ControllerBootstrap {
    +build_app() App
  }
  Topology "1" o-- "0..*" Link
  JsonTopologyDAO ..|> TopologyDAO
  RoutingService --> TopologyDAO
  RoutingService --> WeightedGraphBuilder
  RoutingService --> BellmanFordEngine
  BellmanFordEngine ..> PathResult
  RoutingService ..> Route
  LinkService --> TopologyDAO
  ControllerAPI --> RoutingService
  ControllerAPI --> LinkService
  ControllerAPI ..> ControllerViews
  ControllerBootstrap ..> JsonTopologyDAO
  ControllerBootstrap ..> RoutingService
  ControllerBootstrap ..> LinkService
  ControllerBootstrap ..> ControllerAPI
```

**Responsabilidades:** `Topology` y `Link` contienen datos validados; `Route` conserva origen/destino, camino, costo, métrica y versión del mismo snapshot. `JsonTopologyDAO` valida y lee/escribe el JSON bajo exclusión mutua y reemplazo atómico; los servicios solo utilizan su interfaz. `WeightedGraphBuilder` convierte los enlaces aptos a grafo NetworkX ponderado sin leer archivos. `BellmanFordEngine` **no** accede al DAO ni al API: recibe un grafo ya ponderado, calcula distancias Bellman-Ford, detecta ciclos negativos alcanzables y aplica el desempate de `01` §3. `RoutingService` coordina snapshot único + builder + motor. `LinkService` solicita las transiciones de estado. `ControllerAPI` maneja peticiones/respuestas sin lógica algorítmica. `ControllerBootstrap` crea e inyecta objetos y configuración.

## 3. Diagrama de clases — Router

```mermaid
classDiagram
  class Packet {
    +str packet_id
    +str src
    +str dst
    +str metric
    +str payload
  }
  class RouteData {
    +str src
    +str dst
    +list path
    +str metric
    +float total_cost
    +int topology_version
  }
  class ForwardingResult {
    +str packet_id
    +str status
    +list trace
    +float route_cost
    +int topology_version
    +str error_code
  }
  class ForwardingRecord {
    +str event_id
    +str packet_id
    +str src
    +str dst
    +str metric
    +str status
    +list trace
    +float route_cost
    +int topology_version
    +str error_code
    +str error_message
  }
  class ForwardingLogDAO {
    <<interface>>
    +save(record) void
    +list_results() list
  }
  class JsonlForwardingLogDAO {
    +str file_path
    +save(record) void
    +list_results() list
  }
  class ControllerClient {
    +str base_url
    +float timeout_seconds
    +get_route(src,dst,metric) RouteData
  }
  class ForwardingService {
    +ControllerClient controller_client
    +ForwardingLogDAO log_dao
    +forward(packet) ForwardingResult
  }
  class RouterViews {
    <<View>>
    +PacketRequest
    +ForwardingResponse
    +ErrorResponse
  }
  class RouterAPI {
    +post_packet(packet)
    +health()
  }
  class RouterBootstrap {
    +build_app() App
  }
  JsonlForwardingLogDAO ..|> ForwardingLogDAO
  ControllerClient ..> RouteData
  ForwardingService --> ControllerClient
  ForwardingService --> ForwardingLogDAO
  ForwardingService ..> ForwardingRecord
  ForwardingService ..> ForwardingResult
  ForwardingService ..> Packet
  RouterAPI --> ForwardingService
  RouterAPI ..> RouterViews
  RouterBootstrap ..> ControllerClient
  RouterBootstrap ..> JsonlForwardingLogDAO
  RouterBootstrap ..> ForwardingService
  RouterBootstrap ..> RouterAPI
```

**Responsabilidades:** `Packet` es el modelo de entrada; `RouteData` es el DTO **local** validado a partir de JSON; `ForwardingResult` es el resultado del servicio; `ForwardingRecord` es la fila JSONL con `event_id` único. `ControllerClient` usa HTTP y rechaza respuestas incompatibles; `ForwardingService` reproduce `RouteData.path` como traza y registra cada intento válido antes de devolver éxito o error. Los handlers no realizan forwarding, HTTP manual ni escritura de archivos; `JsonlForwardingLogDAO` es el único escritor de JSONL.

## 4. Contrato de estado y persistencia atómica (SPDR-03)

1. **Fuente autoritativa:** `topology.json` persistente. No hay cache mutable de topología independiente ni base de datos secundaria. `JsonTopologyDAO` valida y carga al iniciar; cada operación DAO lee la versión confirmada bajo el **mismo candado por proceso**.
2. **Snapshot consistente:** `get_topology()` adquiere candado, lee/valida un estado completo y devuelve copia independiente; después libera candado. `RoutingService.get_route()` utiliza **solo esa copia** (sin volver a solicitar versión o enlaces). Una operación concurrente puede ser anterior o posterior a esa lectura, pero no se mezclan versiones dentro de la respuesta.
3. **Actualización atómica:** `set_link_status()` adquiere candado, obtiene el estado confirmado, valida el enlace, compara `enabled`; si es igual responde con versión sin cambio. Si cambia, crea copia con `topology_version+1`; escribe archivo temporal **en el mismo directorio**, `flush`, sincroniza el archivo y reemplaza el original mediante reemplazo atómico (`os.replace`). El punto de compromiso es el reemplazo: **solo después** se devuelve éxito. No se publica un estado intermedio.
4. **Error de escritura:** un fallo **antes del reemplazo** elimina el temporal, conserva archivo y versión anteriores y devuelve `TOPOLOGY_WRITE_FAILED` 500. No se confirma actualización en memoria. Si el reemplazo se completó, el estado queda confirmado y se verifica en nuevas lecturas; no se inventa una reversión de una operación ya confirmada.
5. **Reinicio:** el proceso recupera el JSON persistido (incluidos versión y `enabled`). Si el archivo es inválido al iniciar, el arranque falla de forma explícita; una lectura fallida durante operación responde `TOPOLOGY_UNAVAILABLE` 503.
6. **Límite de concurrencia:** garantía para **un único proceso Controller y un worker**, sin editores/escritores externos. La sincronización en memoria no protege múltiples procesos; este escenario no está soportado por el diseño. Los tests TC-24–26 prueban reversión, recuperación y consultas concurrentes.

**Durabilidad acotada:** el archivo se sincroniza antes del reemplazo; la garantía ante apagado inesperado depende del sistema de archivos. El contrato exige atomicidad de la vista de archivo y coherencia de versión; no afirma durabilidad transaccional bajo cualquier avería física.

## 5. Mapeo MVC / DAO de ambas aplicaciones

| Aplicación | Model | View (JSON y validación) | Controller MVC | Servicios/algoritmo | DAO / persistencia |
|---|---|---|---|---|---|
| Controller | `Topology`, `Link`, `Route`, `PathResult` | `ControllerViews` | `ControllerAPI` | `LinkService`, `RoutingService`, `WeightedGraphBuilder`, `BellmanFordEngine` | `TopologyDAO` → `JsonTopologyDAO` → `topology.json` |
| Router | `Packet`, `RouteData`, `ForwardingResult`, `ForwardingRecord` | `RouterViews` | `RouterAPI` | `ForwardingService`, `ControllerClient` (adaptador HTTP) | `ForwardingLogDAO` → `JsonlForwardingLogDAO` → `forwarding.jsonl` |

**Inyección de dependencias (composición):** `ControllerBootstrap` crea un `JsonTopologyDAO`, un `WeightedGraphBuilder`, un `BellmanFordEngine`, inyecta las **abstracciones** en `RoutingService`/`LinkService` y ambos en `ControllerAPI`. `RouterBootstrap` inyecta `ControllerClient` y `ForwardingLogDAO` en `ForwardingService`, que a su vez se inyecta en `RouterAPI`. TC-08 reemplaza DAO de topología por fake; TC-09 reemplaza DAO de registros y cliente HTTP por fakes; TC-14 llama al motor con grafo ponderado artificial.

**Invariantes:** ninguna API ni servicio abre archivos; solo DAOs concretos. No existe cálculo de rutas en Router. El contrato `04-api-contract.md` es el límite de comunicación entre procesos. Las clases que intervienen en las tres secuencias de `03` aparecen aquí, incluido `BellmanFordEngine`.

## 6. Relación entre clases, requisitos y pruebas

| Componente | Requisitos | Pruebas |
|---|---|---|
| `BellmanFordEngine`, `WeightedGraphBuilder`, `RoutingService` | FR-02/03/04; NFR-03 | TC-01/02/14/21/22 |
| `JsonTopologyDAO`, `LinkService` | FR-01/06; NFR-02 | TC-03/04/17/24/25/26 |
| `ControllerAPI`, `ControllerViews` | FR-05/09, NFR-04 | TC-20/23/28 |
| `ControllerClient`, `ForwardingService`, `ForwardingLogDAO` | FR-07/08/10; NFR-09 | TC-05/06/09/18/23/29 |
| `ControllerBootstrap` / `RouterBootstrap` | NFR-01/05/07 | TC-11/19 |

La implementación del algoritmo y de los servicios está prevista para la siguiente etapa, sin código de aplicación en esta línea base.
