# 03. Arquitectura dinámica — SDN educativo / Bellman-Ford

**Línea base propuesta:** S1-v1 · **Diagramas:** tres secuencias obligatorias. Cada participante es una clase de `02-static-architecture.md` y cada solicitud HTTP corresponde a `04-api-contract.md`.

## 1. Supuestos de las secuencias

Topología no dirigida: A–B 2 ms, B–D 3 ms, A–C 4 ms, C–D 5 ms. Versión inicial 1. Solicitudes de rutas calculadas a partir de **una copia consistente** del JSON persistido y con el algoritmo de `01-requirements.md` §3. Entre Controller y Router solo viajan mensajes JSON; no se comparten objetos Python. Los diagramas muestran **comportamientos especificados**, no ejecuciones ya realizadas.

## 2. Secuencia 1 — Reenvío exitoso y registro previo a la respuesta

```mermaid
sequenceDiagram
  autonumber
  actor U as Cliente
  participant RA as RouterAPI
  participant FS as ForwardingService
  participant HC as ControllerClient
  participant CA as ControllerAPI
  participant RS as RoutingService
  participant TD as TopologyDAO
  participant WG as WeightedGraphBuilder
  participant BF as BellmanFordEngine
  participant LD as ForwardingLogDAO
  U->>RA: POST /packets JSON pkt-001 A D delay
  RA->>FS: forward(Packet)
  FS->>HC: get_route(A,D,delay)
  HC->>CA: HTTP GET /route?src=A&dst=D&metric=delay
  CA->>RS: get_route(A,D,delay)
  RS->>TD: get_topology()
  Note over TD: Lock y lectura de snapshot version 1
  TD-->>RS: Topology copia inmutable v1
  RS->>WG: build(topology,delay)
  WG-->>RS: Graph con pesos y enlaces aptos
  RS->>BF: compute(graph,A,D)
  Note over BF: Bellman-Ford + desempate lexicografico
  BF-->>RS: PathResult [A,B,D], costo 5
  RS-->>CA: Route A D [A,B,D] delay 5 v1
  CA-->>HC: HTTP 200 JSON con src dst path metric costo version
  HC-->>FS: RouteData local validado
  Note over FS: trace = path, no calcula rutas
  FS->>LD: save(ForwardingRecord delivered event_id unico)
  LD-->>FS: Registro persistido
  FS-->>RA: ForwardingResult delivered trace [A,B,D]
  RA-->>U: HTTP 200 JSON trace [A,B,D] y version 1
```

**Aserciones futuras:** `ControllerClient` realiza HTTP real en TC-23; `trace` es idéntica a `path`; el registro JSONL existe **antes** del HTTP 200; `src`, `dst` y `topology_version` provienen de la misma respuesta validada. En caso de fallo del log, la salida es 500 `LOG_WRITE_FAILED` y no 200.

## 3. Secuencia 2 — Fallo, actualización atómica, alternativa/inalcanzable y restauración

```mermaid
sequenceDiagram
  autonumber
  actor U as Cliente
  participant CA as ControllerAPI
  participant LS as LinkService
  participant TD as TopologyDAO
  participant RS as RoutingService
  participant WG as WeightedGraphBuilder
  participant BF as BellmanFordEngine
  U->>CA: POST /links/fail {source:B,target:D}
  CA->>LS: set_status(B,D,false)
  LS->>TD: set_link_status(B,D,false)
  Note over TD: Lock, archivo temporal, replace atomico
  alt Escritura confirmada
    TD-->>LS: Topology v2 B-D inactivo
    LS-->>CA: Topology v2
    CA-->>U: HTTP 200 enabled=false version 2
    U->>CA: GET /route?src=A&dst=D&metric=delay
    CA->>RS: get_route(A,D,delay)
    RS->>TD: get_topology()
    TD-->>RS: Snapshot consistente v2
    RS->>WG: build(topology,delay)
    WG-->>RS: Graph sin B-D
    RS->>BF: compute(graph,A,D)
    alt Existe ruta alternativa
      BF-->>RS: PathResult [A,C,D], costo 9
      RS-->>CA: Route A D [A,C,D] v2
      CA-->>U: HTTP 200 JSON ruta alternativa v2
    else No hay camino con nodos existentes
      BF-->>RS: NoPath
      RS-->>CA: ROUTE_NOT_FOUND
      CA-->>U: HTTP 404 error ROUTE_NOT_FOUND
    end
  else Fallo antes del reemplazo
    TD-->>LS: TOPOLOGY_WRITE_FAILED; archivo v1 intacto
    LS-->>CA: TOPOLOGY_WRITE_FAILED
    CA-->>U: HTTP 500 error TOPOLOGY_WRITE_FAILED
  end
  U->>CA: POST /links/restore {source:B,target:D}
  CA->>LS: set_status(B,D,true)
  LS->>TD: set_link_status(B,D,true)
  TD-->>LS: Topology confirmada con B-D activo
  LS-->>CA: Topology vigente
  CA-->>U: HTTP 200 enabled=true version vigente
  U->>CA: GET /route?src=A&dst=D&metric=delay
  CA->>RS: get_route(A,D,delay)
  RS->>TD: get_topology()
  TD-->>RS: Snapshot vigente
  RS->>WG: build(topology,delay)
  WG-->>RS: Graph
  RS->>BF: compute(graph,A,D)
  BF-->>RS: PathResult [A,B,D] costo 5
  RS-->>CA: Route A D [A,B,D] version vigente
  CA-->>U: HTTP 200 JSON ruta restaurada
```

**Condiciones:** sobre el fixture inicial, el primer fallo cambia versión 1→2, la restauración posterior 2→3 y la ruta vuelve a `[A,B,D]`. La rama «sin camino» requiere una topología distinta en la que A y D existan pero estén desconectados. Si el fallo de escritura deja B–D activo, la restauración es idempotente y mantiene versión 1; por eso el diagrama usa «versión vigente» en la fase final. Las consultas del Controller no generan logs de forwarding, pues no son `POST /packets`. TC-24 comprueba rollback, TC-25 el reinicio y TC-26 concurrencia/consistencia de versión.

## 4. Secuencia 3 — Error/timeout Controller y respuesta estable del Router

```mermaid
sequenceDiagram
  autonumber
  actor U as Cliente
  participant RA as RouterAPI
  participant FS as ForwardingService
  participant HC as ControllerClient
  participant CA as ControllerAPI
  participant LD as ForwardingLogDAO
  U->>RA: POST /packets pkt-002 A D delay
  RA->>FS: forward(Packet)
  FS->>HC: get_route(A,D,delay)
  alt Conexion rechazada o timeout de 2 segundos
    HC-xCA: HTTP GET /route fallido
    HC-->>FS: CONTROLLER_UNAVAILABLE
    FS->>LD: save(ForwardingRecord failed event_id unico)
    alt Registro guardado
      LD-->>FS: Ok
      FS-->>RA: CONTROLLER_UNAVAILABLE
      RA-->>U: HTTP 503 error CONTROLLER_UNAVAILABLE
    else Error de persistencia
      LD-->>FS: Error al guardar
      FS-->>RA: LOG_WRITE_FAILED
      RA-->>U: HTTP 500 error LOG_WRITE_FAILED
    end
  else HTTP recibido pero JSON o contrato invalido
    CA-->>HC: HTTP con cuerpo invalido o estado inesperado
    HC-->>FS: CONTROLLER_BAD_RESPONSE
    FS->>LD: save(ForwardingRecord failed)
    LD-->>FS: Ok
    FS-->>RA: CONTROLLER_BAD_RESPONSE
    RA-->>U: HTTP 502 error CONTROLLER_BAD_RESPONSE
  end
  U->>RA: GET /health
  RA-->>U: HTTP 200 JSON status ok application router
```

**Criterios:** un error de red o tiempo de espera (cliente HTTP de 2 s) produce 503 solo si se registra el intento; respuestas HTTP incompatibles o JSON mal formado producen 502; el error del DAO tiene prioridad y produce 500. `GET /health` comprueba la disponibilidad del Router **sin afirmar** que el Controller funcione. TC-07/13/18/27/28.

## 5. Consistencia de clases, endpoints y resultados

| Secuencia | Clases / método principal | Endpoint o respuesta | Verificación |
|---|---|---|---|
| 1 | `RouterAPI.post_packet`, `ForwardingService.forward`, `ControllerClient.get_route`, `ControllerAPI.get_route`, `RoutingService.get_route`, `TopologyDAO.get_topology`, `WeightedGraphBuilder.build`, `BellmanFordEngine.compute`, `ForwardingLogDAO.save` | Router `POST /packets` → Controller `GET /route` → HTTP 200 | TC-06, TC-23, TC-29 |
| 2 | `ControllerAPI.fail_link/restore_link`, `LinkService.set_status`, `TopologyDAO.set_link_status/get_topology`, `RoutingService.get_route`, `BellmanFordEngine.compute` | `POST /links/fail` / `/restore` y `GET /route`; 200/404/500 | TC-03, TC-04, TC-24–26 |
| 3 | `RouterAPI.post_packet`, `ForwardingService.forward`, `ControllerClient.get_route`, `ForwardingLogDAO.save` | Router `POST /packets` → 503/502/500; `GET /health` → 200 | TC-07, TC-18, TC-27, TC-28 |

Las reglas de estado, esquema de errores y precedencias son vinculantes en `02-static-architecture.md` §4 y `04-api-contract.md` §§8–10.
