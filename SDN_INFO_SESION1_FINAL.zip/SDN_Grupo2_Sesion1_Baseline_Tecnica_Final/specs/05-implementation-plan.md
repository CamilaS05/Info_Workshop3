# 05. Plan de implementación, trazabilidad y control de línea base

**Línea base propuesta:** S1-v1 · **Planeación:** trabajo de implementación en la etapa posterior; este archivo no contiene código ejecutable.

## 1. División de responsabilidades y dependencias

| Rol | Propiedad principal | Responsabilidad de verificación |
|---|---|---|
| A — Controller | Modelos `Topology`, `Link`, `Route`, `JsonTopologyDAO`, `RoutingService`, `BellmanFordEngine`, `WeightedGraphBuilder`, `LinkService`, `ControllerAPI` | Bellman-Ford, persistencia atómica, rutas y pruebas DAO aisladas |
| B — Router | Modelos `Packet`, `RouteData`, `ForwardingResult`, `ForwardingRecord`, `ControllerClient`, `ForwardingService`, `ForwardingLogDAO`, `RouterAPI` | Llamadas HTTP, simulación de reenvío, log y manejo de errores |
| A+B | Especificación REST, pruebas de integración, revisión arquitectónica y línea base compartida | TC-23 real, trazabilidad, congelamiento y control de cambios |

**Orden de integración:** el contrato `04-api-contract.md` y los nombres de campos (`src`, `dst`, `path`, `metric`, `total_cost`, `topology_version`) son compartidos antes de escribir los endpoints. El cliente HTTP no importa clases internas de Controller.

## 2. Desglose de trabajo y ruta crítica

| Tarea | Responsable | Dependencias | Entregable / condición de salida | Requisitos / pruebas |
|---|---|---|---|---|
| T1 | A | Línea base | Modelos, validación de topología, copia consistente | FR-01/02; TC-15/16 |
| T2 | A | T1 | DAO JSON con candado, escritura temporal/replace, reinicio | FR-06; TC-17/24–26 |
| T3 | A | T1 | Builder + motor Bellman-Ford aislado; desempate y ciclo negativo | FR-03/04; TC-01/02/14/21/22 |
| T4 | A | T2, T3 | Servicios, Controller REST, validación uniforme | FR-05/06/09; TC-03/04/20 |
| T5 | B | Línea base | Modelos y DAO JSONL con `event_id` único | FR-10; TC-09/18/29 |
| T6 | B | T5, contrato API | Cliente HTTP con validación `RouteData` y errores 502/503 | FR-07/09; TC-05/07/28 |
| T7 | B | T5, T6 | Servicio de forwarding y Router REST | FR-08/10; TC-06/09 |
| T8 | A+B | T4 y T7 | **Dos procesos reales** comunicados vía HTTP, caso éxito y logs confirmados | FR-07/08/10; TC-23 |
| T9 | A+B | T3/4, T5/7 y T8 | Pruebas automatizadas, revisión MVC/DAO, fallos y métricas | NFR-01–11; TC-08/09/11/12/13/27 |
| T10 | A+B | T9 | README ejecutable, evidencia auténtica, resultados y limitaciones | NFR-08; registro final |

**Ruta crítica técnica:** T1→T2/T3→T4 y T5→T6→T7 avanzan en paralelo; convergen en T8; luego T9→T10. Las pruebas de aislamiento TC-08/09 se desarrollan junto con los respectivos servicios para no acumularlas al final. El `BellmanFordEngine` debe recibir un grafo ponderado y **no** quedar acoplado a TopologyDAO; de lo contrario TC-14 no es verificable.

## 3. Presupuesto para la etapa de implementación: 108 minutos (SPDR-10)

| Bloque | Minutos | Trabajo planificado |
|---|---:|---|
| Revisión de especificación y configuración | 10 | Dependencias, variables de entorno, topología y contrato API |
| Modelos, DAO e inyección (en paralelo A/B) | 24 | T1/T2 y T5, interfaz de motores y clientes |
| Servicios y endpoints (en paralelo A/B) | 29 | T3/T4 y T6/T7; pruebas aisladas durante el desarrollo |
| Integración real y depuración | 15 | T8: levantar ambos procesos; POST /packets, GET /route y JSONL |
| Verificación prioritaria | 20 | T9, capturas auténticas; pruebas arquitectónicas y manejo de fallos |
| Publicación y resultados | 5 | T10 y evidencias de comandos y estados |
| **Reserva de contingencia** | **5** | Corrección de bloqueo HTTP/DAO/entorno sin cambiar contrato |
| **Total** | **108** | Dos frentes paralelos, un punto de integración |

**Prioridad P0 (no negociable):** (a) contrato de rutas y desempate definidos; (b) cálculo independiente y test defensivo; (c) persistencia atómica con versión; (d) prueba end-to-end con dos procesos genuinos; (e) TC-08 y TC-09. **Mínimo de evaluación:** al menos 8 pruebas automatizadas aprobadas con TC-08 y TC-09, revisión estática MVC/DAO y caso TCP/HTTP real TC-23. El catálogo integral excede razonablemente los 108 minutos y no se presenta como ya ejecutado; cualquier prueba pendiente se reporta como pendiente, no se elimina.

**Plan ante riesgo:** falta de tiempo → conservar primero Controller/Router mínimos y pruebas P0; fallo en intercambio JSON → contrastar `04` y probar TC-05 antes de TC-23; fallo de disco → verificar `TOPOLOGY_WRITE_FAILED` y `LOG_WRITE_FAILED` sin editar los requisitos; desacuerdo de API → detener integración y registrar cambio con impacto transversal; caída en rendimiento → registrar mediciones reales y limitación, no ajustar umbrales a posteriori.

## 4. Matriz requisitos → diseño → prueba (trazabilidad)

| Requisito | Componentes responsables | Pruebas / evidencia futura |
|---|---|---|
| FR-01 | `Topology`, `JsonTopologyDAO`, `ControllerAPI` | TC-15, TC-25 |
| FR-02 | `WeightedGraphBuilder`, `RoutingService` | TC-16 |
| FR-03 | `BellmanFordEngine`, `RoutingService`, `Route` | TC-01, TC-14, TC-21 |
| FR-04 | `WeightedGraphBuilder`, `BellmanFordEngine` | TC-02, TC-22 |
| FR-05 | `ControllerAPI`, `ControllerViews` | TC-01, TC-20, TC-23 |
| FR-06 | `LinkService`, `JsonTopologyDAO` | TC-03, TC-04, TC-17, TC-24–26 |
| FR-07 | `ControllerClient`, `ForwardingService` | TC-05 (doble HTTP), **TC-23 (HTTP real)** |
| FR-08 | `RouterAPI`, `ForwardingService`, `RouteData` | TC-06, TC-23 |
| FR-09 | Ambas APIs, `ControllerClient` | TC-07, TC-10, TC-20, TC-28 |
| FR-10 | `ForwardingRecord`, `ForwardingLogDAO` | TC-06, TC-09, TC-18, TC-29 |
| NFR-01 | APIs y Views de ambas apps | TC-11 inspección de MVC |
| NFR-02 | DAOs concretos y servicios | TC-08/09, TC-11 |
| NFR-03 | `BellmanFordEngine`, `ForwardingService` | TC-05, TC-11, TC-14 |
| NFR-04 | Views y cliente HTTP | TC-20, TC-23, TC-28 |
| NFR-05 | `ControllerBootstrap`, `RouterBootstrap` | TC-19 |
| NFR-06 | APIs y servicios | TC-07, TC-18, TC-20 |
| NFR-07 | Servicios, inyección por constructor | TC-08, TC-09, TC-11 |
| NFR-08 | Esta matriz y `06-test-specification.md` | Inspección de correspondencias |
| NFR-09 | Interfaces TopologyDAO/ForwardingLogDAO | TC-08, TC-09 |
| NFR-10 | `ControllerAPI`, `RoutingService` | TC-12 con fixture fijo |
| NFR-11 | `ControllerClient`, `RouterAPI` | TC-13 fake + TC-27 servidor lento |

## 5. Cierre de especificaciones y control de cambios

Los seis documentos `specs/01` a `specs/06`, la documentación de prompting y la topología de referencia constituyen una propuesta coherente **S1-v1**. La validación documental no equivale a resultados ejecutados ni a aprobación académica. La confirmación del equipo se registra en `ACTA_REVISION_BASELINE.md`; un acta sin confirmaciones queda **pendiente**, sin simular firmas.

| Versión | Hallazgo | Solución documentada | Artefactos afectados |
|---|---|---|---|
| S1-v1 | SPDR-01 desempate no operacional | Grafo de aristas ajustadas, recorrido lexicográfico simple con prueba de alcanzabilidad | 01, 02, 06 |
| S1-v1 | SPDR-02 ciclo negativo no invocable | Motor puro sobre grafo ponderado + test separado del mapeo HTTP 422 | 01, 02, 06 |
| S1-v1 | SPDR-03 persistencia y concurrencia | Fuente única JSON, lock, copia por petición, reemplazo atómico y reinicio | 01, 02, 03, 04, 06 |
| S1-v1 | SPDR-04 integración HTTP ambigua | TC-05 aislado separado de TC-23 end-to-end real obligatorio | 03, 05, 06 |
| S1-v1 | SPDR-05–10 contratos y viabilidad | JSONL, fixture NFR-10, timeout de transporte, errores 502, `src/dst`, cronograma y reserva | 01, 02, 04, 05, 06 |

**Regla para futuros cambios:** identificar hallazgo, decisión, responsable de revisión, versión y documentos afectados; modificar en conjunto requisitos, arquitectura, API, secuencias, tareas y pruebas. Ninguna diferencia se resuelve silenciosamente cambiando un test para que coincida con código defectuoso.
