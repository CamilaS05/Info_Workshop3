# 01. Especificación de requisitos — SDN educativo / Bellman-Ford

**Línea base propuesta:** S1-v1 · **Alcance:** diseño previo a implementación · **Referencias vinculantes:** `02`–`06` y `prompts-session1.md`.

## 1. Problema, alcance y decisiones

Dos aplicaciones Python independientes intercambian REST/JSON: **Controller** mantiene una topología y decide rutas; **Router** solicita esas rutas por HTTP, simula el recorrido y registra los resultados. No se transmite tráfico físico ni se implementa OpenFlow. El Router no calcula caminos. El grafo de producción es **no dirigido**, con nodos de identificador de texto no vacío, sin enlaces duplicados ni bucles, y admite nodos aislados. Las cadenas son sensibles a mayúsculas y se comparan lexicográficamente por puntos de código Unicode.

Archivo de topología: `nodes` (lista), `links` (lista) y `topology_version` (entero ≥1). Un enlace tiene `source`, `target`, `delay_ms` ≥0, `bandwidth_mbps` >0, `loss_probability` en [0,1] y `enabled` booleano. Los pesos son `delay_ms`, `1/bandwidth_mbps` y `-ln(1-loss_probability)`; un enlace `enabled=false` o con pérdida **p=1** queda excluido para todas las métricas. Todos los valores numéricos deben ser finitos y no booleanos. La validación inicial rechaza topologías inválidas y evita exponer una topología ficticia.

El archivo JSON persistente es **la única fuente autoritativa**; sus actualizaciones de enlace son atómicas dentro de un único proceso Controller y un único trabajador HTTP (no se admiten procesos escritores externos). El DAO entrega una **copia inmutable por solicitud**. La versión solo aumenta al confirmar un cambio real y persiste tras reiniciar. Una ruta conserva el camino, el costo y la versión del **mismo snapshot**. Los detalles de concurrencia y errores están en `02-static-architecture.md` §4.

## 2. Requisitos funcionales (entradas, salidas, aceptación, errores)

| ID | Entrada / comportamiento | Salida y criterio de aceptación | Errores |
|---|---|---|---|
| FR-01 | Cargar `topology.json` mediante `TopologyDAO`. | `GET /topology` 200 reproduce la topología y su versión persistida; reinicio recupera estado confirmado. | Archivo inicial ausente, corrupto o inválido: **arranque rechazado** con diagnóstico; lectura posterior inhabilitada: 503 `TOPOLOGY_UNAVAILABLE`. |
| FR-02 | Grafo válido arbitrario, incluyendo nodos aislados. | NetworkX representa topologías lineal, malla y desconectada sin alterar servicios; TC-16. | Datos inválidos: error de validación. |
| FR-03 | `GET /route` con `src`, `dst`, `metric`. | 200 devuelve `src`, `dst`, `path`, `metric`, `total_cost`, `topology_version`; Bellman-Ford minimiza el costo y **desempata por el camino simple completo lexicográficamente menor** conforme a §3; TC-01, TC-21. | 404 `NODE_NOT_FOUND`/`ROUTE_NOT_FOUND`; ciclo negativo alcanzable en motor defensivo: 422 `NEGATIVE_CYCLE`. |
| FR-04 | Métrica `delay`, `inverse_bandwidth`, `loss`. | Costo acumulado de enlaces aptos por las fórmulas de §1; TC-02 y TC-22. | Parámetro erróneo 400 `INVALID_INPUT`; esquema inválido no entra en producción. |
| FR-05 | Consultas REST de topología y rutas. | Los seis endpoints, JSON y códigos satisfacen `04-api-contract.md`; TC-01, TC-20 y TC-23. | Errores controlados en formato `error.code/error.message`. |
| FR-06 | `POST /links/fail` y `/links/restore` con dos nodos. | Estado confirmado y versión actualizados; operación repetida no modifica versión, escritura fallida no confirma cambio; tras reinicio persiste; TC-03/04/17/24–26. | 404 `LINK_NOT_FOUND`, 500 `TOPOLOGY_WRITE_FAILED`, 503 `TOPOLOGY_UNAVAILABLE`. |
| FR-07 | Router recibe un paquete válido. | `ControllerClient` consulta `GET /route` mediante HTTP **real** en integración TC-23; cliente doble solo para prueba aislada TC-05. | Tiempo agotado/desconexión: 503 `CONTROLLER_UNAVAILABLE`; respuesta inválida: 502 `CONTROLLER_BAD_RESPONSE`. |
| FR-08 | `POST /packets` con `packet_id`, `src`, `dst`, `metric`, `payload`. | 200 `delivered` y `trace` idéntica al `path` recibido, sin recalcular ruta ni enviar paquetes; TC-06/23. | 400 validación; 404 sin ruta; 502/503 según adaptador HTTP. |
| FR-09 | Entradas incorrectas, nodos inexistentes, rutas ausentes y fallos de comunicación. | Error JSON estable, código HTTP específico y `GET /health` local en 200 tras fallos previstos; TC-07/10/20/28. | 400, 404, 502, 503 según la causa. |
| FR-10 | Todo intento **válido y procesado** de forwarding. | `ForwardingLogDAO.save` persiste un registro JSONL completo **antes** de responder, incluso en errores de ruta/conexión; se permite repetir `packet_id` y se genera `event_id` único por intento; TC-06/09/18/29. | Si falla persistencia, responde 500 `LOG_WRITE_FAILED` incluso si el error inicial era 404/502/503. |

Las peticiones rechazadas por esquema antes de iniciar forwarding no generan registro. Un Controller que falle al iniciar no tiene por qué responder `GET /health`, a diferencia de errores controlados durante su operación.

## 3. Decisión algorítmica vinculante (SPDR-01 y SPDR-02)

**Fase 1 — distancias óptimas:** `WeightedGraphBuilder` transforma una instantánea validada en un grafo NetworkX ponderado. `BellmanFordEngine.compute(graph, src, dst)` utiliza Bellman-Ford **desde `src`** para obtener las distancias; una excepción de ciclo negativo *alcanzable* se convierte en `NegativeCycleError`. El motor recibe el grafo ponderado, no lee DAO, archivos, HTTP ni recompone métricas.

**Fase 2 — desempate:** para cada arista habilitada se considera la orientación `u→v` si `dist[u]+peso(u,v)` coincide con `dist[v]` dentro de tolerancia `abs_tol=1e-12`, `rel_tol=1e-12` (regla numérica explícita). Se forma un subgrafo dirigido de **aristas ajustadas** (*tight edges*). Desde `src` se escoge el siguiente nodo lexicográficamente menor que (a) no haya sido visitado y (b) **aún pueda alcanzar `dst` por aristas ajustadas sin reutilizar nodos visitados**. Se repite hasta `dst`. Así se selecciona el camino **simple** de menor orden lexicográfico entre los caminos de costo óptimo (considerando la tolerancia numérica definida), incluso con aristas de costo cero. No se depende del orden de inserción de nodos/enlaces de NetworkX; si `src=dst`, la ruta es `[src]` con costo 0 una vez comprobada la ausencia de ciclos negativos alcanzables.

**Precaución numérica:** se rechazan pesos no finitos; se usa la misma regla de comparación en construcción de aristas ajustadas y en el control final de costo. La validación final debe comprobar que la suma del camino elegido coincide con la distancia de Bellman-Ford dentro de la tolerancia indicada. El costo publicado es el costo de esa ruta. TC-21 cubre igualdades, prefijos comunes, orden de inserción invertido y ciclos de costo cero.

**Interfaz defensiva:** en producción `RoutingService.get_route()` obtiene un `Topology` validado, construye el grafo y delega en **ese mismo** `BellmanFordEngine`. Para TC-14, una prueba unitaria invoca directamente `BellmanFordEngine.compute()` con un `nx.DiGraph` artificial con pesos negativos. Así se ensaya el mismo motor **sin debilitar** la validación JSON. Una prueba separada inyecta un servicio que genera `NegativeCycleError` en `ControllerAPI` y comprueba su traducción a HTTP 422. No se promete que una topología válida pueda disparar 422.

## 4. Requisitos no funcionales

| ID | Restricción / prueba definida |
|---|---|
| NFR-01 | MVC visible en ambos procesos: Model, View y Controller HTTP separados; TC-11. |
| NFR-02 | Lectura/escritura de archivos solo en implementaciones DAO concretas, no en handlers o servicios; TC-11. |
| NFR-03 | Bellman-Ford exclusivamente en `BellmanFordEngine`, invocado por `RoutingService`; reenvío exclusivamente en `ForwardingService`; TC-11. |
| NFR-04 | Contrato HTTP/JSON idéntico a `04-api-contract.md`, incluidas respuestas de error de validación 400; TC-20, TC-23 y TC-28. |
| NFR-05 | `CONTROLLER_PORT`, `ROUTER_PORT`, `TOPOLOGY_FILE`, `FORWARDING_LOG_FILE`, `CONTROLLER_URL` y `CONTROLLER_TIMEOUT_SECONDS` configurables; TC-19. |
| NFR-06 | Errores previstos en ejecución no detienen la aplicación; `/health` continúa en 200; TC-07, TC-18, TC-20. |
| NFR-07 | Diseño orientado a objetos, modular, servicios probables sin servidor y dependencias inyectadas; TC-08/09. |
| NFR-08 | Cada FR/NFR posee componente, tarea y verificación trazada en `05-implementation-plan.md`; auditoría cruzada. |
| NFR-09 | DAO intercambiables por fakes sin HTTP/disco; TC-08/09. |
| **NFR-10** | Sobre fixture **fijo** `ejemplos/topology-benchmark.json` (100 nodos, 300 enlaces), 10 solicitudes de calentamiento no contabilizadas + 100 `GET /route?src=N000&dst=N050&metric=delay` consecutivas por loopback, 1 worker, sin carga externa y versión 1. p95 **≤500 ms**, definida como muestra ordenada n.º 95; conservar las 100 mediciones y descripción del equipo; TC-12. |
| **NFR-11** | Timeout HTTP de 2 s. Con 20 fallos simulados (fake cliente), el Router retorna 503 en **≤3 s en 20/20**; adicionalmente, 5 ensayos ante un servidor HTTP local controlado que retrase su respuesta **más de 2 s** comprueban el timeout de transporte y el mismo límite de 3 s; TC-13/27. |

Las metas NFR-10/11 son **criterios futuros**, no resultados medidos en la Sesión 1. El benchmark está acotado a las condiciones anteriores; no implica rendimiento en producción o bajo concurrencia múltiple.

## 5. Criterios de aceptación del escenario principal

Ejemplo persistente A—B: 2 ms, B—D: 3 ms, A—C: 4 ms, C—D: 5 ms; inicial `topology_version=1`. `GET /route` A→D por retardo retorna `[A,B,D]` con costo 5 y versión 1. Tras deshabilitar B—D, retorna `[A,C,D]` con costo 9 y versión 2. Restaurar devuelve `[A,B,D]` con costo 5 y versión 3. Repetir una operación ya aplicada no altera la versión. A→E sobre topología con nodo E aislado implica `ROUTE_NOT_FOUND`; A→Z con Z ausente implica `NODE_NOT_FOUND`.

**Prioridad de fallos:** antes de publicar un resultado de forwarding se confirma su registro; un error del DAO de logs implica `LOG_WRITE_FAILED` con independencia del resultado de enrutamiento. El Router no tiene persistencia de topología y nunca decide rutas.
