# Fixture reproducible de latencia NFR-10

**Archivo:** `topology-benchmark.json` · **SHA-256:** `ba3ce8a7093b0f85ee75b5bdb645e7da9e6f36b9794c5ec1f2236e043740802c`.

**Definición:** 100 nodos N000–N099; para cada índice i en 0–99 y cada salto s=1, 2 o 5, enlace no dirigido entre N(i) y N((i+s) módulo 100). Son 300 pares distintos. Retardo (ms) = 1 + ((17i+13s) módulo 9), ancho 10 Mbps, pérdida 0.01, enabled true, versión 1. Sin generadores aleatorios.

**Consulta fija:** `GET /route?src=N000&dst=N050&metric=delay`; una sola instancia Controller y un worker sobre loopback, sin otras cargas; 10 solicitudes de calentamiento y 100 muestras HTTP consecutivas. p95 corresponde al elemento n.º 95 tras ordenar las 100 muestras; aceptación p95 ≤ 500 ms. El hash distingue este fixture de modificaciones accidentales.

El archivo es un **dato de prueba de especificación**, no un script de implementación ni evidencia de rendimiento medido.
