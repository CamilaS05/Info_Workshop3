# Grupo 2 — SDN educativo: Controller y Router con Bellman-Ford

**Asignatura:** Informática para Telecomunicaciones · **Etapa:** Sesión 1, especificación y arquitectura · **Línea base de diseño:** S1-v1.

**Autoría y distribución:** Erika Juliana Diaz Yanalá — Estudiante A, Controller. Maria Camila Salazar Cifuentes — Estudiante B, Router. El diseño fue elaborado con asistencia de inteligencia artificial y sometido a revisión crítica documentada en `prompts-session1.md` y `REVISION_SPDR.md`.

## Alcance

Dos aplicaciones Python independientes se comunicarán por HTTP/REST/JSON. Controller administrará la topología y los caminos mínimos; Router solicitará rutas, simulará el reenvío y registrará los resultados. Ambas aplicaciones adoptan MVC, DAO e inyección de dependencias. Esta entrega contiene **documentación de diseño**, fixtures y diagramas; no contiene código Python de aplicación ni resultados de prueba ejecutados.

## Entregables de especificación

| Archivo | Contenido |
|---|---|
| `specs/01-requirements.md` | Entradas, salidas, errores, FR-01–10, NFR-01–11 y criterios algorítmicos exactos |
| `specs/02-static-architecture.md` | Diagrama de componentes, dos diagramas de clases, MVC/DAO/DI y persistencia atómica |
| `specs/03-dynamic-architecture.md` | Tres secuencias: reenvío, enlace fallido/restaurado, Controller sin respuesta |
| `specs/04-api-contract.md` | Seis endpoints mínimos, contratos JSON, `src/dst`, códigos y registro JSONL |
| `specs/05-implementation-plan.md` | Tareas, roles A/B, dependencias, trazabilidad y presupuesto de 108 minutos |
| `specs/06-test-specification.md` | TC-01–TC-29, criterios verificables y pruebas aisladas vs end-to-end |
| `prompts-session1.md` | Cinco técnicas, seis prompts, resolución de ambigüedades y revisión SPDR aplicada |

## Anexos y estructura

- `diagramas/`: seis fuentes Mermaid (`.mmd`) correspondientes exactamente a los seis bloques del documento 02 y 03; representaciones PNG de consulta.
- `ejemplos/`: topologías base, con nodo aislado y benchmark congelado; `BENCHMARK.md` documenta su generación y huella de integridad.
- `REVISION_SPDR.md`: diez hallazgos y su cierre de diseño, sin confundir especificación con resultados funcionales.
- `MATRIZ_CONSISTENCIA.md`: comprobación entre las seis especificaciones.
- `ACTA_REVISION_BASELINE.md`: formato institucional de confirmación humana, sin firmas presumidas.
- `demo-evidence/`: destino de evidencias reales. `controller/`, `router/`, `tests/` se mantienen sin implementación en esta etapa.

## Decisiones técnicas distintivas

Bellman-Ford queda encapsulado en un motor comprobable con grafo ya ponderado; el desempate selecciona el camino simple de menor orden lexicográfico entre óptimos. La topología JSON es el estado autoritativo, con bloqueo en un worker, snapshots coherentes y reemplazo atómico. La verificación HTTP end-to-end **requiere** dos procesos reales (TC-23); los dobles HTTP (TC-05) no la reemplazan. El registro usa JSONL con `event_id` único, y un error al guardar prevalece sobre el resultado de forwarding.

**Estado de calidad:** los diez hallazgos SPDR cuentan con solución documental y prueba de aceptación definida. Su aprobación personal y la ejecución del software no se dan por realizadas ni se suplanta evidencia inexistente.
