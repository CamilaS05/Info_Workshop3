# Registro de revisión de línea base — S1-v1

**Objeto:** evaluación de coherencia entre especificación de requisitos, arquitectura, REST/JSON, plan y pruebas del sistema SDN académico. Esta acta se conserva con campos de conformidad sin atribuir declaraciones que no estén registradas.

## Control documental

| Criterio | Resultado de revisión documental |
|---|---|
| FR-01–FR-10 y NFR-01–NFR-11 especificados | Incluidos en `01-requirements.md` |
| Diagrama de componentes y dos diagramas de clases | Incluidos en `02-static-architecture.md` |
| Tres secuencias, con clases y métodos correspondientes | Incluidas en `03-dynamic-architecture.md` |
| Seis endpoints y errores REST | Incluidos en `04-api-contract.md` |
| Responsabilidades, dependencias, trazabilidad y riesgos | Incluidos en `05-implementation-plan.md` |
| Pruebas P0 SPDR y aceptación automáticas | Especificadas en `06-test-specification.md` |
| Técnicas de IA y crítica técnica | Registradas en `prompts-session1.md` |
| Resultados de ejecución de la Sesión 2 | No aplican a esta línea base documental |

## Conformidad del equipo

| Rol | Integrante | Constancia de conformidad |
|---|---|---|
| Estudiante A — Controller | Erika Juliana Diaz Yanalá | __________________________ |
| Estudiante B — Router | Maria Camila Salazar Cifuentes | __________________________ |

**Estado de conformidad formal:** pendiente de constancia. La revisión documental incorporada no se presenta como firma, aprobación académica ni evidencia de ejecución.

## Control de cambios de diseño

El historial de correcciones SPDR-01–SPDR-10 aparece en `REVISION_SPDR.md`, con trazabilidad a las especificaciones. Toda modificación posterior a S1-v1 debe identificar motivo, decisión y todos los artefactos afectados antes de su incorporación al código.
