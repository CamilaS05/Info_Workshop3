# Auditoría de consistencia de la línea base propuesta S1-v1

**Equipo:** A — Erika Juliana Diaz Yanalá; B — Maria Camila Salazar Cifuentes. **Fecha de preparación:** 2026-10-27.

| Exigencia de la guía | Dónde quedó especificada | Estado documental | Verificación que falta |
|---|---|---|---|
| Entradas/salidas/errores/aceptación para FR-01–FR-10 | `01-requirements.md`, §Requisitos funcionales | Incluido | Validar por las dos |
| NFR-01–09 y dos NFR nuevas medibles | `01-requirements.md`, §Requisitos no funcionales | Incluido (NFR-10/11) | Medir en Sesión 2 |
| Dos procesos independientes y REST/JSON | `02` §2; `03` §1; `04` §2 | Incluido | Verificar al implementar |
| MVC de Controller y Router | `02` §3, §4, §5 | Incluido | Inspección de código en Sesión 2 |
| DAO y límites de persistencia de ambos | `02` §2–6 | Incluido | TC-08, TC-09 |
| DI (inyección), servicios fuera de handlers | `02` §6 y diagramas de clase | Incluido | TC-08, TC-09, TC-11 |
| Diagrama de componentes y de clases | `02` §2–4 + `diagramas/` | Incluido | Validar render Mermaid Live |
| Tres diagramas de secuencia | `03` §2–4 + `diagramas/` | Incluido | Validar render Mermaid Live |
| Seis rutas mínimas (GET health en ambas) | `04` §2–7 | Incluido | Implementar y probar en Sesión 2 |
| Ejemplos JSON y 400/404/503 diferenciados | `04` §3–9 | Incluido | Pruebas de contrato en Sesión 2 |
| Tareas, dependencias y roles | `05` §1–2 | Incluido | Confirmar responsables |
| Requisitos ↔ componentes ↔ pruebas | `05` §3; `06` §2/4 | Incluido; TC-01–22 | Ejecutar las pruebas en Sesión 2 |
| Cinco técnicas obligatorias y ≥3 ambigüedades | `prompts-session1.md` §§1–3 | Textos y decisiones propuestos | Ejecutar prompts y decidir en equipo |
| Checkpoint y registro de cambios | `05` §§6–7 | Campos incluidos | Aprobación real pendiente |

## Hallazgos corregidos en esta consolidación

1. Se incorporó **TC-15 a TC-22** para cubrir carga de topologías, variaciones, idempotencia, error de registro, configuración, entradas inválidas, desempate y `p=1` con pruebas identificadas.
2. Se ajustó `05-implementation-plan.md` para remitir a TC-01–22 y enlazar casos adicionales con los FR/NFR.
3. En el diagrama de clases del Router se introdujo `RouteData` como **DTO local**; nunca se importa una clase del Controller entre procesos.
4. Los nombres y roles del equipo aparecen en los documentos sin falsificar aprobación o registros de prompts.

## Ajustes de la auditoría definitiva — 28 de octubre de 2026

1. TC-10 usa ahora la topología separada con nodo `E` aislado y no el fixture A–D; se añadió `ejemplos/topology-isolated-example.json`.
2. TC-03, TC-04 y TC-17 reinician topología con versión 1; se evita contaminación entre pruebas.
3. Se precisó el caso defensivo de ciclo negativo en un grafo artificial de test, sin aceptar retardos negativos en entradas normales.
4. La carga inicial con JSON inválido produce error de arranque explícito; NFR-06 garantiza estabilidad ante errores de peticiones **después** de que la aplicación arranque.
5. Se precisó cálculo p95 de NFR-10 y se revisó el prompt iterativo P5 para que considere los seis diagramas.
6. Estas correcciones están documentadas; **no constituyen aprobación real de A y B**.

## Limitaciones explícitas

- La validación sintáctica/estructural de Markdown, los JSON de muestra y las fuentes Mermaid **no demuestra que los endpoints funcionen**; todavía no existe código implementado.
- No se atribuyen revisiones finales ni respuestas de IA a las integrantes.
- Si un diagrama requiere un ajuste visual al abrirlo en Mermaid Live, actualizar su fuente `.mmd`, la copia del bloque en `specs/` y registrar el cambio.
