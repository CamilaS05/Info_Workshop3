# Registro de ingeniería de prompts — Sesión 1, Grupo 2 (Bellman-Ford)

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Versión de plantilla:** S1-v1  
**Estado:** textos y criterios preparados; **prompts/evidencias que no se hayan ejecutado se mantienen pendientes**. Este archivo no fabrica respuestas ni atribuye a las estudiantes acciones no realizadas.  
**Referencia:** `specs/05-implementation-plan.md`, sección 5. La guía exige técnicas de prompting en Sesión 1 y al menos seis prompts sustanciales en total entre Sesiones 1 y 2.

## 1. Técnicas obligatorias y propósito

| ID | Técnica | Objetivo | Requisitos vinculados | Evidencia que deben completar |
|---|---|---|---|---|
| P1 | **Contextual framing** | Dar alcance SDN académico, roles y límites antes de especificar | FR-01–10; NFR-01 | Respuesta real + captura |
| P2 | **Structured prompting** | Exigir IDs, entradas, salidas, errores y aceptación verificable | FR-01–10; NFR-01–11 | Tabla real generada + captura |
| P3 | **Role prompting** | Auditoría de arquitectura MVC, DAO, servicios e inyección | NFR-01–03, 07, 09 | Hallazgos y correcciones comprobadas |
| P4 | **Few-shot examples** | Utilizar un ejemplo válido de JSON para obtener respuestas coherentes | FR-05, 07–09; NFR-04 | Salida JSON real + crítica |
| P5 | **Iterative refinement** | Mejorar borradores mediante retroalimentación explícita | FR-06–10; NFR-01–04 | Versiones anterior y corregida |
| P6 | **Crítica y ambigüedades** | Identificar ≥3 ambigüedades, comparar opciones y decidir como equipo | FR-02–04, FR-06, NFR-08 | Salida y decisión humana justificada |

> **Cómo usar la plantilla:** copiar cada prompt a una conversación con IA, incorporar los documentos relevantes (sin datos sensibles), conservar lo que la IA realmente responda y anotar correcciones **que sí se apliquen**. Si aún no lo ejecutaron, dejar el campo «Pendiente».

## 2. Textos completos de prompts propuestos

### P1 — Contextual framing

**Técnica:** contextual framing.  
**Objetivo:** delimitar el problema antes de diseñar.

> Actúa como asistente de análisis de requisitos de una práctica universitaria de sexto semestre sobre SDN educativo. Necesitamos DOS procesos Python independientes: Controller administra una topología JSON mediante DAO y escoge rutas con NetworkX/Bellman-Ford; Router consulta por REST/JSON, simula forwarding y guarda resultados mediante DAO. Ambos siguen MVC y dependencia inyectada. NO es OpenFlow real ni se transmiten paquetes físicos. Durante la Sesión 1 NO generes código. Describe alcance, límites, entradas y salidas generales, papeles de Estudiante A/B y lista de FR-01 a FR-10. Cada requisito debe tener ID y criterio de aceptación verificable.

**Control humano:** rechazar sugerencias de cálculo autónomo en Router o de comunicación mediante importación de clases entre procesos.

### P2 — Structured prompting

**Técnica:** structured prompting.  
**Objetivo:** obtener especificación verificable.

> Con el contexto SDN anterior, produce una tabla que contenga TODOS los requisitos FR-01 a FR-10 y NFR-01 a NFR-11. Para cada FR incluye columnas: ID, entrada, procesamiento, salida, errores, criterio de aceptación comprobable, componente responsable y caso de prueba. Define al final NFR-10 (p95 de GET /route <= 500 ms en 100 consultas locales con hasta 100 nodos/300 enlaces) y NFR-11 (20/20 fallos de Controller con respuesta HTTP 503 <= 3 s y timeout HTTP de 2 s), indicando método de medición. Utiliza las métricas delay, inverse_bandwidth y loss y distingue 404 NODE_NOT_FOUND de 404 ROUTE_NOT_FOUND. No escribas Python ni afirmes que pruebas hayan pasado.

**Control humano:** comprobar IDs exactos, umbrales medibles y coherencia con `01-requirements.md`.

### P3 — Role prompting

**Técnica:** role prompting.  
**Objetivo:** auditar diseño estático.

> Actúa como arquitecta de software encargada de aprobar o rechazar una arquitectura antes de permitir su implementación. Revisa dos procesos, Controller y Router, usando MVC con modelos, vistas JSON, APIs HTTP como controladores, servicios de dominio y DAO por inyección. Exige `TopologyDAO`/`JsonTopologyDAO` para Controller y `ForwardingLogDAO`/`JsonlForwardingLogDAO` para Router. Devuelve (1) una tabla de clases y responsabilidades, (2) relaciones y dependencias que deben figurar en el diagrama de clases y (3) al menos tres errores arquitectónicos concretos posibles y su solución. Indica qué normas NFR-01, NFR-02, NFR-03 y NFR-09 verifica cada observación. No generes código de implementación.

**Control humano:** revisar que archivos solo los manipulen DAOs y que algoritmos no estén en handlers.

### P4 — Few-shot examples

**Técnica:** few-shot examples (dos ejemplos guía).  
**Objetivo:** diseñar respuestas JSON uniformes.

> Diseña el contrato REST/JSON del SDN usando el ESTILO de estos ejemplos correctos: EJEMPLO 1, petición `GET /route?src=A&dst=D&metric=delay`, respuesta HTTP 200 `{"path":["A","B","D"],"metric":"delay","total_cost":5.0,"topology_version":1}`. EJEMPLO 2, petición de ruta válida sin camino, respuesta HTTP 404 `{"error":{"code":"ROUTE_NOT_FOUND","message":"No hay ruta disponible entre A y D"}}`. Aplica el mismo formato, sin copiar errores entre casos, a `GET /topology`, `POST /links/fail`, `POST /links/restore`, `POST /packets` y ambos `GET /health`; incluye para cada uno método, entrada, salida, HTTP status y errores. Diferencia `INVALID_INPUT` (400), `NODE_NOT_FOUND` (404), `ROUTE_NOT_FOUND` (404) y `CONTROLLER_UNAVAILABLE` (503), e incluye fallos de log (500). Cada endpoint debe relacionarse con IDs FR y criterios de aceptación. Sin código Python.

**Control humano:** cotejar nombres y versiones con `04-api-contract.md`.

### P5 — Iterative refinement

**Técnica:** iterative refinement.  
**Objetivo:** documentar dos iteraciones reales de revisión, no solo una orden inicial.

> Primera revisión: examina mis diagramas de componentes, clases y las tres secuencias frente a los requisitos y el contrato API que adjunto. Enumera contradicciones verificables por ubicación, clases ausentes, pasos omitidos y llamadas REST incorrectas. NO generes código. Devuélveme observaciones priorizadas con requisito afectado.

**SEGUNDA petición, solo después de recibir la primera respuesta:**

> Corrige exclusivamente los problemas confirmados en la revisión anterior, conservando los acuerdos del equipo: Controller calcula Bellman-Ford; Router consulta por HTTP; DAO guarda archivos; `topology_version` aumenta solo al cambiar el enlace; error de Controller => 503, timeout 2 s; log antes de responder al cliente. Devuelve los seis diagramas Mermaid completos (componentes, dos de clases y tres de secuencia), enumera cambios antes/después y comprueba contra los nombres de clases de `02-static-architecture.md` y endpoints de `04-api-contract.md`. No inventes pruebas ejecutadas.

**Control humano:** guardar captura de **ambas** interacciones y registrar correcciones aplicadas efectivamente.

### P6 — Identificación y resolución de ambigüedades

**Técnica:** revisión crítica y juicio técnico.  
**Objetivo:** identificar **al menos tres** decisiones no totalmente fijadas antes de codificar.

> Como revisor técnico escéptico del proyecto SDN Grupo 2, identifica al menos TRES ambigüedades del diseño que impidan implementar o probar el Controller/Router (por ejemplo: grafo dirigido o no dirigido, empate de rutas, actualización de topology_version en operaciones repetidas y tratamiento de loss_probability=1). Para cada ambigüedad, describe dos opciones, impacto sobre los criterios de aceptación, riesgo de incompatibilidad con el contrato API y recomendación. Incluye IDs de requisitos afectados. NO tomes decisiones por el equipo; termina pidiendo su aprobación y NO generes código.

**Control humano:** comparar sugerencias con la guía y validar personalmente los acuerdos de la sección 3.

## 3. Tres o más ambigüedades y decisión técnica propuesta

Esta tabla consolida decisiones **ya reflejadas como propuestas** en los documentos `01`–`04`; A y B deben ratificarlas. No constituye, por sí sola, evidencia de que P6 haya sido ejecutado.

| Ambigüedad | Opciones | Decisión propuesta y razón | Requisitos/documentos |
|---|---|---|---|
| Naturaleza del grafo | Dirigido / no dirigido | **No dirigido**; simplifica la topología didáctica y las operaciones sobre enlaces sin repetir arcos. | FR-02, FR-06; `01`, `04` |
| Empates de menor costo | Cualquier ruta óptima / desempate fijo | **Ruta lexicográficamente menor**; hace reproducibles los criterios y TC-01. | FR-03; `01`, `04`, `06` |
| Versión ante fallo/restauración repetidos | Incrementar siempre / solo ante cambio | **Solo ante cambio efectivo**; idempotencia y versiones sin incrementos ficticios. | FR-06; `01`, `03`, `04` |
| Enlace con pérdida `p = 1` | Usarlo en delay / excluir siempre | **Excluirlo de cualquier ruta**; la guía dice que es inutilizable. | FR-04; `01`, `04` |

**Confirmación de A — Erika Juliana Diaz Yanalá:** fecha y aprobación _pendientes_. Para documentarlas, registrar qué tres ambigüedades concretas fueron revisadas después de la salida real de P6 y por qué se eligió cada decisión.  
**Confirmación de B — Maria Camila Salazar Cifuentes:** fecha y aprobación _pendientes_.

## 4. Registro de ejecución y crítica: COMPLETAR CON EVIDENCIA REAL

| Prompt | Ejecutado (sí/no) y fecha | Resumen fiel de respuesta observada | Error/ambigüedad REAL detectada | Refinamiento/corrección REAL aplicada | Evidencia (archivo o enlace) |
|---|---|---|---|---|---|
| P1 | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |
| P2 | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |
| P3 | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |
| P4 | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |
| P5 inicial + P5 iteración | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |
| P6 | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |

**Para que el registro sea aceptable:** el texto de los prompts está aquí, pero las respuestas y críticas deben provenir de ejecuciones auténticas; se recomienda guardar capturas `demo-evidence/prompt-P1.png` … `prompt-P6.png` y `prompt-P5-iteracion.png`. Si ya hicieron solicitudes reales en la conversación actual para revisar `01`–`04`, pueden documentarlas con su texto y resultado auténticos, indicando técnica aplicada sin inventar contenido.

## 5. Checkpoint de la Sesión 1 y control de cambios

- [ ] Se revisaron `specs/01` a `specs/06` y este archivo `prompts-session1.md`.
- [ ] Se documentaron las cinco técnicas con **respuestas reales**, objetivos, ID de requisitos y criterios de aceptación.
- [ ] Se pidió a la IA identificar **≥3 ambigüedades** y se justificaron decisiones humanas por A y B.
- [ ] Diagramas, requisitos, API y pruebas concuerdan; cualquier diferencia se corrigió o registró como pendiente.
- [ ] Ambas estudiantes confirmaron el diseño y la versión S1-v1; constan fecha, repositorio y/o firma en `specs/05-implementation-plan.md`.
- [ ] Modificaciones posteriores se registrarán con motivo y todos los artefactos afectados.

**No declarar «completado» hasta realizar los pasos pendientes.** Ningún prompt sustituye las verificaciones humanas o las pruebas de Sesión 2.


## 6. Distribución de la documentación de prompts

- **Erika Juliana Diaz Yanalá (A):** contextual framing (P1), role prompting (P3), revisión de Bellman-Ford y decisiones de topología.
- **Maria Camila Salazar Cifuentes (B):** structured prompting (P2), few-shot (P4), validación del contrato Router/errores.
- **Ambas:** iterative refinement (P5), ambigüedades (P6), revisión y evidencias reales.

**Atención:** estos son prompts **listos para ejecutar**, no pruebas de ejecución previa. La hoja de registro de la sección 4 debe completarse con capturas y respuestas reales antes de marcar la Sesión 1 como aprobada.
