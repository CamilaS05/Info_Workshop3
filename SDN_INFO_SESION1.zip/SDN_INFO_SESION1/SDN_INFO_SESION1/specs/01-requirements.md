# 01. Requisitos — SDN educativo (Grupo 2, Bellman-Ford)

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Versión:** S1-v1 (revisada) | **Estado:** documento preparado para entrega; aprobación final pendiente de Estudiante A y Estudiante B.

## Alcance y convenciones
Dos procesos Python independientes: **Controller** (topología y rutas) y **Router** (consulta por HTTP y simula reenvío). Comunicación REST/JSON; **no** se usa OpenFlow ni se envían paquetes de red reales. El Controller usa NetworkX y Bellman-Ford. El Router **nunca calcula rutas**.

Convenciones de diseño propuestas, pendientes de ratificación por ambas estudiantes: grafo **no dirigido**, enlaces identificados por pares de nodos; un enlace deshabilitado se excluye de las rutas; métrica `delay` en ms, `inverse_bandwidth` en 1/Mbps y `loss` adimensional. Todos los nodos son cadenas únicas no vacías. `topology_version` empieza en 1 y solo aumenta cuando cambia realmente el estado de un enlace. No se aceptan enlaces duplicados ni bucles a sí mismos. Se admiten nodos aislados.

## Requisitos funcionales
| ID | Entrada y comportamiento | Salida / aceptación verificable | Errores relevantes |
|---|---|---|---|
| FR-01 | Cargar `topology.json` usando `TopologyDAO`. | `GET /topology` devuelve nodos, enlaces y versión cargados. | Topología inicial mal formada: detener el arranque con diagnóstico explícito (fail-fast), sin servir una topología inventada. |
| FR-02 | Recibir cualquier grafo válido según convenciones. | Criterio de aceptación: cargar y consultar mediante `GET /topology` tres topologías válidas (lineal, malla y desconectada), comprobando que se representan todos sus nodos y enlaces con NetworkX sin modificar la lógica de carga. | Nodo/enlace inválido: rechazo con descripción. |
| FR-03 | `src`, `dst` y `metric` para Bellman-Ford. | `GET /route` responde con camino mínimo, costo, métrica y versión; desempate determinista por ruta lexicográficamente menor. | Nodo inexistente: 404 `NODE_NOT_FOUND`; sin camino: 404 `ROUTE_NOT_FOUND`; ciclo negativo alcanzable: 422 `NEGATIVE_CYCLE`. |
| FR-04 | `delay`, `inverse_bandwidth`, `loss`. | Por enlace: `delay_ms`, `1/bandwidth_mbps` (b>0), `-ln(1-loss_probability)` (0≤p<1). Para p=1 el enlace no es utilizable. | Métrica inválida o b≤0: 400. Pérdida fuera de [0,1]: 400. |
| FR-05 | Solicitud HTTP de ruta. | Criterio de aceptación: `GET /route` devuelve campos, tipos de datos y estructura JSON según los ejemplos/esquemas de `04-api-contract.md`; los códigos HTTP de éxito y error también coinciden con ese contrato. | 400/404/422 según contrato. |
| FR-06 | `POST /links/fail` / `restore` con dos nodos. | Se actualiza enlace, versión y rutas posteriores; operación repetida mantiene la versión. | Enlace inexistente: 404 `LINK_NOT_FOUND`. |
| FR-07 | `POST /packets` en Router. | `ControllerClient` hace una solicitud HTTP real a `GET /route`. | Controller no disponible/timeout: Router devuelve 503. |
| FR-08 | Paquete con origen, destino, identificador y carga. | Router devuelve `trace` igual a la ruta seleccionada y estado `delivered` (simulado). | Ruta no disponible: respuesta 404 controlada. |
| FR-09 | Entradas incorrectas, destinos inaccesibles y fallas HTTP. | Criterio de aceptación: ante cada error esperado, responder con JSON que incluya `error.code` y `error.message`; después, `GET /health` de la aplicación afectada debe responder HTTP 200, demostrando que sigue disponible. | 400 invalid input, 404 nodo/ruta, 503 Controller no disponible. |
| FR-10 | Cada intento de forwarding, incluso fallo. | `ForwardingLogDAO` guarda ID, estado, traza, causa y versión cuando existe. | Fallo de persistencia: 500 `LOG_WRITE_FAILED` documentado. |

## Requisitos no funcionales
| ID | Exigencia / cómo comprobarla |
|---|---|
| NFR-01 | Ambas aplicaciones usan MVC; inspeccionar responsabilidades de Model, View y Controller en diagrama y carpetas. |
| NFR-02 | Persistencia y carga solo a través de interfaces DAO; búsqueda estática de operaciones sobre archivos fuera de clases DAO. |
| NFR-03 | Bellman-Ford está en `RoutingService` y forwarding en `ForwardingService`, nunca en handlers HTTP; revisión de fuentes. |
| NFR-04 | HTTP y JSON coinciden con `04-api-contract.md`; pruebas de contrato. |
| NFR-05 | Puertos y ubicación de topología configurables mediante variables de entorno; prueba cambiando sus valores. |
| NFR-06 | Errores esperados mantienen ambos procesos disponibles; hacer solicitud `GET /health` después de cada fallo. |
| NFR-07 | Diseño modular orientado a objetos con dependencias inyectadas; revisar diagrama y pruebas aisladas. |
| NFR-08 | Cada requisito tiene un componente y al menos una prueba trazable; matriz de `05-implementation-plan.md`. |
| NFR-09 | DAO sustituible por fake/mock; pruebas TC-08 y TC-09 sin archivos reales ni HTTP. |
| **NFR-10 (nuevo)** | En entorno local de prueba, `GET /route` tendrá latencia p95 ≤ **500 ms** en 100 consultas consecutivas sobre una topología documentada de hasta 100 nodos/300 enlaces; incluir tiempo HTTP completo, registrar las 100 muestras y calcular p95 como el valor ordenado en posición 95 (objetivo por verificar en Sesión 2). |
| **NFR-11 (nuevo)** | En 20 simulaciones de timeout/conexión fallida, el Router responderá 503 en ≤ **3 s** cada vez, con timeout HTTP de **2 s**; test automatizado con fake HTTP client (objetivo por verificar en Sesión 2). |

## Reglas transversales de validación y criterios de aceptación

- **Topología de inicio:** `JsonTopologyDAO` valida su archivo antes de habilitar la API; si es inexistente, corrupto o incumple el esquema de `04-api-contract.md`, se detiene el arranque con un error explícito. La exigencia NFR-06 de permanencia aplica a **errores esperados en solicitudes mientras el servicio ya está iniciado**, no a una configuración inicial inválida.
- **Valores admitidos:** `delay_ms` numérico ≥ 0; `bandwidth_mbps` numérico > 0; `loss_probability` entre 0 y 1 inclusive. `p=1` define enlace existente pero **no transitable en ninguna métrica**. Se excluyen enlaces `enabled=false`. Las métricas y sus unidades se documentan en el contrato API.
- **Errores HTTP:** `400 INVALID_INPUT` para JSON mal formado, campos obligatorios ausentes, tipos inválidos o métrica no permitida; `404 NODE_NOT_FOUND` para un nodo válido como texto pero inexistente; `404 ROUTE_NOT_FOUND` cuando los dos nodos existen y están desconectados. Se reserva `422 NEGATIVE_CYCLE` para una **prueba defensiva con grafo artificial no válido**: las topologías de producción no admiten pesos negativos.
- **Aislamiento de pruebas:** cada caso TC que modifique enlaces arranca desde una copia de la topología con `topology_version=1`; las pruebas no reutilizan involuntariamente el estado de la prueba previa.
- **Evidencia verificable en Sesión 2:** TC-01–TC-22 definen las expectativas; TC-08/TC-09 comprueban inyección de DAO sin HTTP ni disco; no son resultados ya ejecutados.

## Casos de uso y criterio global
1. **Consultar ruta:** cliente → Controller → TopologyDAO/NetworkX/Bellman-Ford → JSON con costo.
2. **Enviar paquete:** cliente → Router → Controller por HTTP → traza simulada → registro por DAO.
3. **Interrumpir/restaurar:** administrador → Controller → cambio persistido → nueva consulta usa estado vigente.
4. **Controller caído:** Router responde 503, registra el fallo y sigue funcionando.

**Datos de prueba propuestos:** enlaces A—B (2 ms), B—D (3 ms), A—C (4 ms), C—D (5 ms). Ruta A→D por `delay`: `A,B,D`, costo 5. Al fallar B—D: `A,C,D`, costo 9; al restaurar: `A,B,D`, costo 5. Para todas las aristas fijar `bandwidth_mbps` positivo y `loss_probability` entre 0 y 1. Las verificaciones se implementan **solo en Sesión 2**.


## Responsables de verificación previa a Sesión 2

- **Estudiante A — Erika Juliana Diaz Yanalá:** revisar FR-01 a FR-06, NFR-10 y modelo de topología; cotejar con API y pruebas.
- **Estudiante B — Maria Camila Salazar Cifuentes:** revisar FR-07 a FR-10, NFR-11 y manejo de errores del Router; cotejar con API y pruebas.
- **Ambas:** revisar NFR-01 a NFR-09 y aprobar o corregir las convenciones técnicas. La aprobación no se supone realizada.

**Verificación prevista:** `06-test-specification.md` contiene TC-01 a TC-22, incluidos carga JSON, tres topologías, idempotencia, error de log, configuración y desempate. Son pruebas **planificadas**, no ejecutadas.
