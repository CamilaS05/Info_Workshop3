# 03. Arquitectura dinámica — SDN educativo (Grupo 2, Bellman-Ford)

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Versión:** S1-v1 (revisada)  
**Estado:** documento de especificación preparado para entrega; pendiente de aprobación real de Estudiante A y Estudiante B.  
**Sesión:** 1 — especificación y arquitectura (sin implementar código).

## 1. Objetivo y reglas de coherencia

Se describen las interacciones de **dos aplicaciones independientes**: **Controller** (Estudiante A: topología y rutas) y **Router** (Estudiante B: consulta de rutas, simulación de reenvío y registro). La comunicación entre procesos es **HTTP REST/JSON**; el Router no calcula rutas ni accede al archivo de topología.

Los participantes de los diagramas (`RouterAPI`, `ForwardingService`, `ControllerClient`, `ControllerAPI`, `RoutingService`, `LinkService`, `TopologyDAO` y `ForwardingLogDAO`) aparecen en `02-static-architecture.md`. Los mensajes usan sus métodos públicos y los endpoints de `04-api-contract.md`.

**Ejemplo común (topología base restablecida antes de cada prueba):** grafo no dirigido con enlaces A–B (2 ms), B–D (3 ms), A–C (4 ms), C–D (5 ms), y métrica `delay`. Inicialmente `topology_version=1`: A → B → D cuesta **5 ms**. Si falla B–D, A → C → D cuesta **9 ms** y la versión pasa a **2**; cuando se restaura B–D, vuelve la ruta original y la versión pasa a **3**. Estos son **resultados esperados de diseño**, no pruebas ya ejecutadas.

## 2. Secuencia 1 — Reenvío satisfactorio de un paquete

**Objetivo:** cliente → API Router → servicio de reenvío → cliente HTTP → API Controller → servicio de enrutamiento → DAO de topología → ruta → DAO de registro → respuesta. Se verifica la separación de control y forwarding (FR-03, FR-05, FR-07, FR-08 y FR-10).

```mermaid
sequenceDiagram
    autonumber
    actor U as Cliente
    participant RA as RouterAPI
    participant FS as ForwardingService
    participant HC as ControllerClient
    participant CA as ControllerAPI
    participant RS as RoutingService
    participant TD as TopologyDAO
    participant LD as ForwardingLogDAO

    U->>RA: POST /packets (packet_id=pkt-001, src=A, dst=D, metric=delay)
    Note over RA: RouterViews valida PacketRequest
    RA->>FS: forward(packet)
    FS->>HC: get_route(A,D,delay)
    HC->>CA: HTTP GET /route?src=A&dst=D&metric=delay
    CA->>RS: get_route(A,D,delay)
    RS->>TD: get_topology()
    TD-->>RS: Topology(version=1)
    Note over RS: NetworkX y Bellman-Ford, solo en RoutingService
    RS-->>CA: Route(path=[A,B,D], total_cost=5, version=1)
    CA-->>HC: HTTP 200 JSON (path, metric, total_cost, topology_version)
    HC-->>FS: Datos de ruta decodificados (sin compartir objetos Python)
    Note over FS: Simula trace=[A,B,D]; NO recalcula caminos
    FS->>LD: save(ForwardingResult(status=delivered, trace=[A,B,D]))
    LD-->>FS: Guardado correcto
    FS-->>RA: ForwardingResult(delivered, trace=[A,B,D], version=1)
    Note over RA: RouterViews serializa ForwardingResponse
    RA-->>U: HTTP 200 JSON (packet_id, status, trace, route_cost, metric, topology_version)
```

**Entrada HTTP del Router:**

```json
{"packet_id":"pkt-001","src":"A","dst":"D","metric":"delay","payload":"hola"}
```

**Salida esperada (HTTP 200):**

```json
{"packet_id":"pkt-001","status":"delivered","trace":["A","B","D"],"route_cost":5.0,"metric":"delay","topology_version":1}
```

**Criterios de aceptación (para probar en Sesión 2):** el Router solicita la ruta a `GET /route` mediante HTTP; no calcula Bellman-Ford; `trace` coincide exactamente con `path`; el DAO guarda el resultado **antes** de responder con éxito; se retorna HTTP 200 con la estructura del contrato.

## 3. Secuencia 2 — Fallo de enlace, recálculo y restauración

**Objetivo:** deshabilitar B–D, persistir el cambio de topología, consultar otra ruta y recibir una alternativa o `ROUTE_NOT_FOUND`; restaurar B–D y comprobar el regreso del camino original (FR-03, FR-06 y FR-09).

```mermaid
sequenceDiagram
    autonumber
    actor U as Cliente
    participant CA as ControllerAPI
    participant LS as LinkService
    participant TD as TopologyDAO
    participant RS as RoutingService

    U->>CA: POST /links/fail (source=B, target=D)
    CA->>LS: set_status(B,D,false)
    LS->>TD: set_link_status(B,D,false)
    Note over TD: JsonTopologyDAO persiste enabled=false y aumenta version
    TD-->>LS: Topology(version=2)
    LS-->>CA: Topology(version=2)
    CA-->>U: HTTP 200 JSON (enabled=false, topology_version=2)

    U->>CA: GET /route?src=A&dst=D&metric=delay
    CA->>RS: get_route(A,D,delay)
    RS->>TD: get_topology()
    TD-->>RS: Topology(version=2, B-D inactivo)
    Note over RS: Excluye enlaces caidos y ejecuta Bellman-Ford
    alt Existe camino alternativo (topologia del ejemplo)
        RS-->>CA: Route(path=[A,C,D], total_cost=9, version=2)
        CA-->>U: HTTP 200 JSON (path=[A,C,D], total_cost=9, topology_version=2)
    else No existe camino entre nodos validos
        RS-->>CA: Error ROUTE_NOT_FOUND
        CA-->>U: HTTP 404 JSON (error.code=ROUTE_NOT_FOUND)
    end

    U->>CA: POST /links/restore (source=B, target=D)
    CA->>LS: set_status(B,D,true)
    LS->>TD: set_link_status(B,D,true)
    Note over TD: JsonTopologyDAO persiste enabled=true y aumenta version
    TD-->>LS: Topology(version=3)
    LS-->>CA: Topology(version=3)
    CA-->>U: HTTP 200 JSON (enabled=true, topology_version=3)

    U->>CA: GET /route?src=A&dst=D&metric=delay
    CA->>RS: get_route(A,D,delay)
    RS->>TD: get_topology()
    TD-->>RS: Topology(version=3, B-D activo)
    RS-->>CA: Route(path=[A,B,D], total_cost=5, version=3)
    CA-->>U: HTTP 200 JSON (path=[A,B,D], total_cost=5, topology_version=3)
```

**Solicitudes de cambio de enlace:** ambas utilizan `{"source":"B","target":"D"}`. La operación `POST /links/fail` entrega `enabled:false` y versión 2; `POST /links/restore` entrega `enabled:true` y versión 3. Una operación repetida sin cambio real **no aumenta** la versión.

**Resultados esperados:** después del fallo, `GET /route` devuelve 200 con ruta `["A","C","D"]` y costo **9 ms**; para una topología donde no hay alternativa devuelve 404 con `{"error":{"code":"ROUTE_NOT_FOUND","message":"No hay ruta disponible entre A y D"}}`. Tras restaurar se obtiene 200 con `["A","B","D"]`, costo **5 ms** y versión **3**.

**Criterios de aceptación (Sesión 2):** el caso alternativo y el caso sin ruta usan dos topologías de prueba **distintas**; no se puede declarar `ROUTE_NOT_FOUND` para la topología base A–B–D/A–C–D con un solo enlace B–D fallido. Los cambios pasan por `LinkService` y `TopologyDAO`, persisten su estado, afectan consultas posteriores y se revierten al restaurar. **Nota:** esta secuencia usa consultas directas a la API del Controller; no genera registros en `ForwardingLogDAO` porque no se ha enviado un `POST /packets` al Router.

## 4. Secuencia 3 — Controller no disponible o timeout

**Objetivo:** si el Router no puede consultar la ruta porque el Controller no responde o vence el tiempo de espera, registrar el intento fallido, devolver un error JSON estable y mantenerse disponible (FR-07, FR-09, FR-10 y NFR-11).

```mermaid
sequenceDiagram
    autonumber
    actor U as Cliente
    participant RA as RouterAPI
    participant FS as ForwardingService
    participant HC as ControllerClient
    participant CA as ControllerAPI
    participant LD as ForwardingLogDAO

    U->>RA: POST /packets (packet_id=pkt-002, src=A, dst=D, metric=delay)
    Note over RA: RouterViews valida PacketRequest
    RA->>FS: forward(packet)
    FS->>HC: get_route(A,D,delay)
    HC-xCA: HTTP GET /route no disponible o timeout (2 s)
    Note over HC,CA: No llega una respuesta HTTP util del Controller
    HC-->>FS: Error CONTROLLER_UNAVAILABLE
    FS->>LD: save(ForwardingResult(status=failed, trace=[], error_code=CONTROLLER_UNAVAILABLE))
    LD-->>FS: Guardado correcto
    FS-->>RA: Error CONTROLLER_UNAVAILABLE (registro completado)
    Note over RA: RouterViews serializa ErrorResponse
    RA-->>U: HTTP 503 JSON (error.code=CONTROLLER_UNAVAILABLE)

    U->>RA: GET /health
    RA-->>U: HTTP 200 JSON (status=ok, application=router)
```

**Respuesta de fallo esperada (HTTP 503):**

```json
{"error":{"code":"CONTROLLER_UNAVAILABLE","message":"El Controller no esta disponible o supero el tiempo de espera"}}
```

**Respuesta de salud del Router (HTTP 200):**

```json
{"status":"ok","application":"router"}
```

**Criterios de aceptación (Sesión 2):** tanto el error de conexión como el timeout HTTP de **2 segundos** producen `CONTROLLER_UNAVAILABLE` y 503 si el DAO de logs está disponible; el resultado fallido se registra antes de responder; `GET /health` continúa en 200. El objetivo medible NFR-11 exige que **cada una de 20 simulaciones** responda en **3 segundos o menos**; este desempeño aún no ha sido medido.

## 5. Reglas de errores y consistencia entre documentos

| Situación | Comportamiento exigido | Dónde se aplica |
|---|---|---|
| Paquete encaminado correctamente | Guardar `ForwardingResult(delivered)` y responder 200. | Secuencia 1, `ForwardingService` → `ForwardingLogDAO`. |
| Enlace caído con ruta alternativa | Excluir B–D y entregar la ruta vigente y nueva versión. | Secuencia 2, `RoutingService` → `TopologyDAO`. |
| Sin ruta, con nodos existentes | 404 `ROUTE_NOT_FOUND`. Si se origina en `POST /packets`, el Router registra el intento fallido. | Secuencia 2; regla FR-09/FR-10. |
| Nodo inexistente | 404 `NODE_NOT_FOUND` (distinto de una ruta inexistente). | `GET /route` y consultas remitidas por Router. |
| Controller desconectado o timeout | Router registra fallo y retorna 503 `CONTROLLER_UNAVAILABLE`. | Secuencia 3. |
| Falla al registrar el resultado | Responder **500 `LOG_WRITE_FAILED`**: no afirmar que el registro fue exitoso. | Secuencias 1 y 3, cuando falla `ForwardingLogDAO.save(...)`. |
| Entradas inválidas | 400 `INVALID_INPUT` en JSON. | Validación de Views / APIs. |

El formato de error es `{"error":{"code":"...","message":"..."}}`, de acuerdo con `04-api-contract.md`. Los DAOs concretos acceden a almacenamiento; las APIs HTTP delegan en servicios; **solo `RoutingService` ejecuta Bellman-Ford** y **solo `ForwardingService` simula el reenvío**. La ruta entre aplicaciones se comunica como JSON, sin importar objetos o código interno del otro proceso.

## 6. Matriz de localización y trazabilidad

| Exigencia de la Sesión 1 | Ubicación dentro de este documento | Elementos que la satisfacen |
|---|---|---|
| **Tres diagramas de secuencia coherentes** | Secciones **2, 3 y 4** | Tres bloques `mermaid` (`sequenceDiagram`), escenarios y criterios de aceptación. |
| **Secuencia 1: paquete → Router → Controller → ruta → log → respuesta** | **Sección 2** | `RouterAPI`, `ForwardingService`, `ControllerClient`, `ControllerAPI`, `RoutingService`, `TopologyDAO`, `ForwardingLogDAO`. |
| **Secuencia 2: fallo → actualización → nueva ruta/inalcanzable → restauración** | **Sección 3** | `ControllerAPI`, `LinkService`, `TopologyDAO`, `RoutingService`, alternativa `alt/else`, consulta posterior a restauración. |
| **Secuencia 3: error/timeout → procesamiento → error estable** | **Sección 4** | `ControllerClient`, `ForwardingService`, `ForwardingLogDAO`, `RouterAPI`, HTTP 503, `GET /health`. |
| **Coherencia estática y dinámica** | **Secciones 1 y 5** | Métodos de las clases presentes en `02-static-architecture.md`; no se inventan capas ni cálculos en HTTP. |
| **Coherencia con REST y errores** | **Secciones 2–5** | Endpoints, cuerpos, respuestas y códigos acordados en `04-api-contract.md`. |

## 7. Lista de revisión para Estudiantes A y B

- [x] El documento especifica **tres** secuencias, con participantes que aparecen en la arquitectura estática.
- [x] La secuencia 1 llega hasta `ForwardingLogDAO.save(result)` antes de retornar HTTP 200.
- [x] La secuencia 2 actualiza el enlace, contempla ruta alternativa / sin ruta, restaura el enlace y repite la consulta.
- [x] La secuencia 3 distingue fallo de comunicación/timeout, guarda el intento fallido y define HTTP 503 estable.
- [x] Las consultas y cambios usan el contrato HTTP/JSON; solo las implementaciones DAO administran archivos.
- [ ] Estudiante A: validar en [Mermaid Live Editor](https://mermaid.live) los diagramas del Controller y registrar nombre/fecha: ____________________.
- [ ] Estudiante B: validar en [Mermaid Live Editor](https://mermaid.live) los diagramas del Router y registrar nombre/fecha: ____________________.
- [ ] Ambas estudiantes: comprobar la correspondencia final con `01-requirements.md`, `02-static-architecture.md` y `04-api-contract.md`, y aprobar S1-v1.

**Importante:** este archivo constituye la **especificación** de la Sesión 1. No afirma que las aplicaciones estén implementadas o que las pruebas automáticas de la Sesión 2 ya hayan sido ejecutadas.


## Responsables de inspección

- **Erika Juliana Diaz Yanalá (A):** revisar las respuestas, versiones y clases del Controller en las secuencias 1 y 2.
- **Maria Camila Salazar Cifuentes (B):** revisar los registros `ForwardingLogDAO`, `ControllerClient` y los errores del Router en las secuencias 1 y 3.
- **Ambas:** verificar en Mermaid Live los tres bloques antes de aprobar S1-v1.
