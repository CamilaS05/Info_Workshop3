# 05. Plan de implementación, trazabilidad y cierre de especificaciones — Grupo 2

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Versión propuesta:** S1-v1 (revisada)  
**Estado:** contenido preparado para revisión; **aprobación humana y evidencias reales pendientes**.  
**Fase:** Sesión 1 — especificación y arquitectura. **No se genera código de implementación en esta sesión.**

## 1. Alcance, entregables y responsabilidades

La solución educativa contiene **dos procesos Python independientes** que se comunican mediante **REST/JSON**, sin OpenFlow ni transmisión de paquetes reales. El **Controller** gestiona la topología y calcula rutas con NetworkX/Bellman-Ford; el **Router** pide la ruta al Controller y simula el reenvío. Ambos implementan **MVC, DAO e inyección de dependencias**. Los servicios de dominio no acceden directamente a archivos y las APIs HTTP no contienen el algoritmo.

| Responsable | Subsistema | Trabajo principal de Sesión 2 | Revisión cruzada |
|---|---|---|---|
| **Estudiante A — Erika Juliana Diaz Yanalá** | Controller | `Topology`, `Link`, `Route`, `TopologyDAO`, `JsonTopologyDAO`, `RoutingService`, `LinkService`, `ControllerAPI`; rutas y enlaces | Revisar Router, errores 503 y registro de forwarding |
| **Estudiante B — Maria Camila Salazar Cifuentes** | Router | `Packet`, `ForwardingResult`, `ForwardingLogDAO`, `JsonlForwardingLogDAO`, `ControllerClient`, `ForwardingService`, `RouterAPI` | Revisar Controller, métricas de ruta y versión de topología |
| **Ambas** | Integración | Acordar contrato API; integrar, probar, revisar diagramas, documentar resultados y commits separados | Aprobar conjuntamente la línea base S1-v1 |

**Restricción temporal:** en Sesión 1 se diseñan documentos y se registran prompts; la implementación, los servidores y las pruebas `pytest` corresponden a Sesión 2.

## 2. Desglose del trabajo de implementación (para Sesión 2)

| ID | Tarea y entregable previsto | Responsable | Dependencia | Requisitos | Verificación prevista |
|---|---|---|---|---|---|
| T01 | Modelos `Topology`, `Link`, `Route` y esquemas de entrada/salida | A | S1-v1 aprobada | FR-01, FR-02, NFR-01, NFR-07 | Inspección MVC; TC-01, TC-02 |
| T02 | Interfaz `TopologyDAO`, `JsonTopologyDAO` e inyección de DAO | A | T01 | FR-01, FR-06, NFR-02, NFR-09 | TC-08; revisión de persistencia |
| T03 | `RoutingService` y NetworkX/Bellman-Ford con tres métricas | A | T01, T02 | FR-02, FR-03, FR-04, NFR-03 | TC-01, TC-02, TC-14, TC-21, TC-22 |
| T04 | `LinkService`, `ControllerAPI`, configuración y `/health` | A | T02, T03 | FR-05, FR-06, FR-09, NFR-04–06 | TC-03, TC-04, TC-10; revisión API |
| T05 | `Packet`, `ForwardingResult`, esquemas Router e interfaz/log DAO | B | S1-v1 aprobada | FR-08, FR-10, NFR-01, NFR-02 | TC-06, TC-09; inspección MVC |
| T06 | `ControllerClient` con URL configurable y timeout de 2 s | B | T05, contrato API | FR-07, FR-09, NFR-05, NFR-11 | TC-05, TC-07, TC-13 |
| T07 | `ForwardingService` con dependencias inyectadas y registro de intentos | B | T05, T06 | FR-08, FR-09, FR-10, NFR-03, NFR-09 | TC-06, TC-07, TC-09 |
| T08 | `RouterAPI` (`POST /packets`, `GET /health`), errores JSON | B | T07 | FR-07, FR-08, FR-09, NFR-04, NFR-06 | TC-05–07, TC-10, TC-20 |
| T09 | Integración REST de los dos procesos, pruebas y control de arquitectura | A+B | T04, T08 | FR-01–10, NFR-01–11 | TC-01–22; revisiones de contrato/estática |
| T10 | Medir rendimiento y preparar defensa/resultados honestos | A+B | T09 | NFR-08, NFR-10, NFR-11 | TC-12, TC-13; `test-results.txt` |

**Secuencia sugerida:** A desarrolla T01→T04 mientras B desarrolla T05→T08; luego ambas realizan T09→T10. A y B hacen commits propios y revisan el trabajo de la compañera. No se asignan tareas de implementación a Sesión 1.

## 3. Matriz de trazabilidad requisitos → componentes → verificación

### 3.1. Funcionales

| ID | Componente responsable | Pruebas/cotejos previstos |
|---|---|---|
| FR-01 | `TopologyDAO`, `JsonTopologyDAO` | TC-08, TC-15 (carga de `topology.json`) según `01-requirements.md` |
| FR-02 | `Topology`, `RoutingService`, NetworkX | TC-01 y TC-16 (tres grafos: lineal, malla y desconectado) |
| FR-03 | `RoutingService` | TC-01, TC-14, TC-21 |
| FR-04 | `RoutingService`, `Link` | TC-02, TC-22 |
| FR-05 | `ControllerAPI`, esquemas JSON | Contrato `04-api-contract.md`; TC-01, TC-03, TC-04 |
| FR-06 | `LinkService`, `TopologyDAO` | TC-03, TC-04, TC-17 (idempotencia) |
| FR-07 | `ControllerClient`, `ForwardingService` | TC-05, TC-07 |
| FR-08 | `ForwardingService`, `RouterAPI` | TC-06 |
| FR-09 | `ControllerAPI`, `RouterAPI`, `ControllerClient` | TC-07, TC-10 (**fixture con E aislado**), TC-20; `/health` después de errores |
| FR-10 | `ForwardingService`, `ForwardingLogDAO` | TC-06, TC-09, TC-18 (fallo de escritura) |

### 3.2. No funcionales

| ID | Componente o decisión | Método de verificación |
|---|---|---|
| NFR-01 | Model/View/Controller en ambas apps | TC-11 e inspección de `02-static-architecture.md` |
| NFR-02 | Interfaces DAO; persistencia encapsulada | TC-08, TC-09, TC-11 |
| NFR-03 | Algoritmo/reenvío solo en servicios | TC-05, TC-11 |
| NFR-04 | Contratos JSON de ambas APIs | Casos HTTP TC-03–07, TC-10 y TC-20; cotejo con `04-api-contract.md` |
| NFR-05 | Puertos, URL y archivo de topología configurables | TC-19 (cambio de configuración) |
| NFR-06 | Respuestas estables ante fallos | TC-07, TC-10, TC-13, TC-20 y `GET /health` posterior |
| NFR-07 | Objetos modulares y dependencias inyectadas | TC-08, TC-09, TC-11 |
| NFR-08 | Relación entre requisitos, tareas y pruebas | Esta matriz y `06-test-specification.md` |
| NFR-09 | DAO sustituibles por fake/mock | TC-08 y TC-09 (obligatorios) |
| NFR-10 | `GET /route` p95 ≤ 500 ms/100 solicitudes | TC-12; entorno local y grafo ≤100 nodos/300 enlaces |
| NFR-11 | 20/20 fallos con HTTP 503 en ≤3 s | TC-13; timeout cliente HTTP de 2 s |

**Dependencia de fixtures:** TC-10 emplea `ejemplos/topology-isolated-example.json` con `E` aislado; TC-03/04/17 reinician la topología de ejemplo en versión 1 para conservar costos y versiones. TC-14 emplea un fake con pesos negativos fuera del esquema de producción para verificar la detección defensiva, sin autorizar pesos negativos en `topology.json`.

**Cobertura ampliada:** `06-test-specification.md` contiene TC-01 a TC-22; TC-15 (carga JSON), TC-16 (tres topologías), TC-17 (idempotencia), TC-18 (fallo de registro), TC-19 (configuración), TC-20 (entrada inválida y salud), TC-21 (desempate) y TC-22 (`p=1`) cierran las verificaciones que estaban pendientes de numeración. Las pruebas siguen **sin ejecutar** hasta Sesión 2.

## 4. Correspondencia con diagramas, API y pruebas

| Documento | Qué debe concordar en la revisión |
|---|---|
| `01-requirements.md` | FR-01–10, NFR-01–11; métricas `delay`, `inverse_bandwidth`, `loss`; grafo no dirigido; versión idempotente |
| `02-static-architecture.md` | `ControllerAPI`, `RouterAPI`, `RoutingService`, `LinkService`, `ForwardingService`, `ControllerClient`, interfaces e implementaciones DAO; MVC/DI |
| `03-dynamic-architecture.md` | Secuencia 1 forwarding con log; secuencia 2 fallo/ruta/restauración; secuencia 3 timeout/503 con log |
| `04-api-contract.md` | Controller: `GET /topology`, `GET /route`, `POST /links/fail`, `POST /links/restore`, `GET /health`; Router: `POST /packets`, `GET /health` |
| `06-test-specification.md` | TC-01–22 planificadas; ejecutar al menos 8 pruebas en Sesión 2, **incluidas TC-08 y TC-09**, documentando las no ejecutadas |
| `prompts-session1.md` | Cinco técnicas obligatorias, borradores con IDs/criterios de aceptación, tres ambigüedades, refinamientos y evidencias reales |

**Regla de coherencia:** los participantes de una secuencia existen en la arquitectura estática; sus interacciones utilizan las operaciones del contrato API; el Router no invoca NetworkX/Bellman-Ford. Respuestas 404 `NODE_NOT_FOUND` y 404 `ROUTE_NOT_FOUND` no son equivalentes. `CONTROLLER_UNAVAILABLE` devuelve 503 y, cuando el DAO lo permita, queda registrado como fallo.

## 5. Ingeniería de prompts obligatoria — Sesión 1

El registro **formal y separado** es [`prompts-session1.md`](../prompts-session1.md). Este plan permite verificar que estén cubiertas las cinco técnicas exigidas en la guía.

| Técnica | Prompt modelo | Resultado documentable | Evidencia pendiente de generar por A y B |
|---|---|---|---|
| Contextual framing | P1 | Contexto del problema, límites y FR | Captura de prompt + respuesta real |
| Structured prompting | P2 | Tabla FR/NFR con **ID, entradas, salidas, errores y aceptación verificable** | Captura y revisión contra `01-requirements.md` |
| Role prompting | P3 | Auditoría de MVC, DAO e inyección de dependencias | Captura y fallos/correcciones reales |
| Few-shot examples | P4 | Ejemplo dado de ruta JSON y nuevos ejemplos comparables | Captura y cotejo con contrato API |
| Iterative refinement | P5 | Segunda versión de diagramas tras crítica concreta | Capturas antes/después, cambios justificados |

**Revisión crítica (P6):** pedir explícitamente a la IA **al menos tres ambigüedades**, discutir alternativas y justificar las decisiones del equipo. No usar las respuestas de IA como si fueran aprobación humana.

**Decisiones técnicas propuestas en documentos 01–04, para ratificación de A y B:** (1) grafo no dirigido, (2) versión incrementa solo si cambia estado de enlace, (3) `loss_probability = 1` implica enlace inutilizable para cualquier métrica, (4) empate entre costos mínimos: camino lexicográficamente menor. La guía no fija las primeras, segunda y cuarta convenciones; el equipo debe confirmar que las acepta. El caso `p=1` sí viene definido como enlace inutilizable en la guía.

**Registro honesto:** cada prompt ejecutado debe incluir técnica, objetivo, texto completo, salida observada, aspecto criticado, corrección **realmente aplicada**, requisito(s) y ruta de evidencia. Los seis prompts propuestos son una plantilla, **no evidencia automática de que fueron ejecutados**. No es válido marcar como realizado un prompt que no se haya enviado a la IA ni inventar sus resultados.

## 6. Punto de control para cerrar la Sesión 1 (checkpoint)

Marcar las casillas **solo tras verificación real por ambas estudiantes**:

- [ ] Existen y se revisaron los seis archivos `specs/01-requirements.md` ... `specs/06-test-specification.md`.
- [ ] `prompts-session1.md` incluye las cinco técnicas exigidas y un registro de su uso **real**; hay capturas o enlaces verificables.
- [ ] Los borradores de IA contienen requisitos con **ID** y **criterios de aceptación medibles/comprobables**.
- [ ] La IA identificó ≥3 ambigüedades y ambas estudiantes documentaron las decisiones y motivos.
- [ ] Los diagramas estáticos y las tres secuencias corresponden a clases y endpoints reales **definidos**, no a código aún inexistente.
- [ ] Los códigos 400, 404 y 503, los ejemplos JSON, los casos TC y los requisitos coinciden entre documentos.
- [ ] Se verificó la cobertura ampliada indicada en §3 y, si hubo cambios, se actualizaron los archivos afectados.
- [ ] Estudiante A revisó el diseño Router; Estudiante B revisó el diseño Controller.
- [ ] Ambas aprobaron por escrito la versión S1-v1 y la guardaron en el repositorio compartido con contribuciones identificables.

**Regla:** mientras alguna casilla fundamental siga pendiente, el documento está *preparado para revisión*, pero **no debe declararse línea base aprobada**. Para Sesión 2, el equipo debe llevar la versión aprobada, no pruebas de código ejecutado.

## 7. Acta de aprobación y control de cambios

| Campo | Dato que deben completar las estudiantes |
|---|---|
| Versión congelada | S1-v1 (si ambas la aprueban) |
| Fecha de revisión | Pendiente |
| Estudiante A / firma o confirmación | Pendiente |
| Estudiante B / firma o confirmación | Pendiente |
| Repositorio, rama y commit de referencia | Pendiente |
| Hallazgos pendientes aceptados o corregidos | Pendiente |
| Decisión final | Pendiente: **no asumir aprobación** |

| Fecha | Versión anterior → nueva | Cambio y motivo | Archivos afectados | Revisó/aprobó |
|---|---|---|---|---|
| Por registrar | — | Completar solo cuando se haga un cambio efectivo | — | — |

**Regla de modificaciones posteriores:** anotar qué cambió, por qué, requisitos/diagramas/API/pruebas afectados y quién aprobó. Actualizar todos los documentos relacionados antes de implementar un cambio en Sesión 2.

## 8. Evidencias mínimas para que el equipo pueda demostrar el proceso

1. Guardar en `demo-evidence/` una captura de la estructura `specs/` y el archivo `prompts-session1.md` (prueba de organización, **no** de funcionalidad).
2. Exportar y verificar visualmente en Mermaid los diagramas del documento 02 y los **tres** del 03. Guardar PNG y anotar en el README qué corresponde a cada uno.
3. Ejecutar los prompts pertinentes de `prompts-session1.md`, tomar capturas **auténticas** de la entrada y respuesta, y completar la tabla de crítica/corrección.
4. Registrar revisión cruzada de A y B, acuerdos de ambigüedades y aprobación de S1-v1 en §7.
5. Guardar el repositorio/ZIP. **No adjuntar pruebas `pytest` simuladas ni capturas de servidores inexistentes**: corresponden a Sesión 2.

**Estado general de este documento:** el contenido de planificación, responsables, trazabilidad y método de cierre queda especificado; las evidencias, las firmas y el congelamiento de la versión dependen de las acciones reales del equipo.


**Prioridad de implementación para la Sesión 2:** ejecutar al menos 8 pruebas automatizadas aprobadas, obligatoriamente TC-08 y TC-09 (según guía). TC-15 a TC-22 están especificadas para comprobar aceptación y trazabilidad; si alguna queda sin automatizar, declararlo expresamente en el resultado de Sesión 2.
