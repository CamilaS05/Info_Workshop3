# 04. Contrato de API REST/JSON — Grupo 2, Bellman-Ford

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Versión propuesta:** S1-v1 (revisada)  
**Estado:** especificación lista para revisión y aprobación de Estudiante A y Estudiante B; **no es evidencia de API implementada**.  
**Etapa:** Sesión 1 — especificación antes de escribir código.

## 1. Propósito y convenciones generales

El sistema educativo SDN consta de **dos procesos Python independientes**:

- **Controller (Estudiante A: Erika Juliana Diaz Yanalá):** administra `topology.json`, calcula rutas mediante NetworkX/Bellman-Ford y cambia el estado de los enlaces. URL local de ejemplo: `http://127.0.0.1:8000`.
- **Router (Estudiante B: Maria Camila Salazar Cifuentes):** recibe paquetes simulados, consulta por HTTP `GET /route` al Controller y registra resultados mediante `ForwardingLogDAO`. URL local de ejemplo: `http://127.0.0.1:8001`.

**Reglas de transporte:** puertos y URL del Controller configurables; solicitudes POST con `Content-Type: application/json`; respuestas y errores en JSON UTF-8 (`application/json`). En GET no se envía cuerpo JSON. Los dos programas intercambian **mensajes HTTP/JSON**, no objetos Python.

**Convenciones de datos propuestas para ratificación de ambas estudiantes:** grafo **no dirigido**; nombres de nodos como cadenas únicas no vacías; enlaces sin duplicados ni bucles, aunque sí se permiten nodos aislados. Un enlace se identifica por su par de extremos, sin importar el orden. `topology_version` empieza en **1** y aumenta en **1** únicamente cuando cambia realmente el estado de un enlace. Los enlaces deshabilitados, o con `loss_probability = 1`, nunca se utilizan para rutas.

**Métricas obligatorias:** `delay`: suma de `delay_ms` (ms); `inverse_bandwidth`: suma de `1 / bandwidth_mbps` (1/Mbps; **no** equivale al ancho de banda de cuello de botella); `loss`: suma de `-ln(1 - loss_probability)` (adimensional). Los costos válidos son no negativos; el empate entre caminos mínimos se resuelve escogiendo la ruta lexicográficamente menor.

**Formato único de error:** `{"error":{"code":"CODIGO","message":"Descripcion legible"}}`. Las solicitudes inválidas se normalizan a **HTTP 400**, incluso si el framework web devuelve por defecto 422 en errores de validación. **HTTP 422** queda reservado aquí a `NEGATIVE_CYCLE`. No debe devolverse un falso éxito cuando falle la persistencia.

## 2. Tabla del contrato mínimo obligatorio

| Aplicación | Método | Endpoint | Finalidad | Éxito |
|---|---|---|---|---|
| Controller | GET | `/topology` | Consultar topología activa y versión | 200 |
| Controller | GET | `/route?src=A&dst=D&metric=delay` | Consultar ruta mínima, métrica, costo y versión | 200 |
| Controller | POST | `/links/fail` | Deshabilitar un enlace existente | 200 |
| Controller | POST | `/links/restore` | Restaurar un enlace existente | 200 |
| Router | POST | `/packets` | Simular reenvío según ruta recibida por HTTP | 200 |
| Controller | GET | `/health` | Informar disponibilidad propia | 200 |
| Router | GET | `/health` | Informar disponibilidad propia | 200 |

Los contratos específicos, incluidos sus **ejemplos de petición, respuesta y errores**, aparecen en las secciones **3 a 8**. Los códigos de error se consolidan en la **sección 9**.

## 3. Controller — `GET /topology`

**Entrada:** `GET /topology` sin cuerpo ni parámetros.  
**Salida (HTTP 200):** todos los nodos, enlaces y versión actual; se incluyen enlaces deshabilitados para que el cliente pueda ver el estado real de la topología.

```json
{
  "nodes": ["A", "B", "C", "D"],
  "links": [
    {"source":"A","target":"B","delay_ms":2,"bandwidth_mbps":10,"loss_probability":0.01,"enabled":true},
    {"source":"B","target":"D","delay_ms":3,"bandwidth_mbps":10,"loss_probability":0.02,"enabled":true},
    {"source":"A","target":"C","delay_ms":4,"bandwidth_mbps":20,"loss_probability":0.02,"enabled":true},
    {"source":"C","target":"D","delay_ms":5,"bandwidth_mbps":20,"loss_probability":0.03,"enabled":true}
  ],
  "topology_version": 1
}
```

**Esquema y validación de topología (también para `topology.json`):** `nodes`: lista de cadenas únicas no vacías; `links`: lista de objetos con `source`, `target` (nodos existentes y distintos), `delay_ms` (número ≥ 0), `bandwidth_mbps` (número > 0), `loss_probability` (número entre 0 y 1 inclusive) y `enabled` (booleano); `topology_version`: entero ≥ 1. No hay aristas duplicadas, ni siquiera en sentido inverso. La topología inválida debe rechazarse durante su carga por `TopologyDAO` con un diagnóstico claro y **arranque detenido (fail-fast)**, sin exponer una topología falsa; NFR-06 se refiere a errores de solicitudes en procesos ya iniciados (FR-01/FR-02).

## 4. Controller — `GET /route`

**Petición de ejemplo (sin cuerpo):** `GET /route?src=A&dst=D&metric=delay`.

| Parámetro de consulta | Tipo | Regla |
|---|---|---|
| `src` | cadena | Obligatorio, no vacío; debe existir en la topología. |
| `dst` | cadena | Obligatorio, no vacío; debe existir en la topología. |
| `metric` | enumeración | Obligatorio: `delay`, `inverse_bandwidth` o `loss`. |

**Respuesta (HTTP 200):**

```json
{
  "path": ["A", "B", "D"],
  "metric": "delay",
  "total_cost": 5.0,
  "topology_version": 1
}
```

**Esquema de salida:** `path`: arreglo ordenado de nodos desde `src` hasta `dst`; `metric`: una de las tres cadenas admitidas; `total_cost`: número no negativo en las unidades de la métrica; `topology_version`: entero positivo. Si `src = dst` y el nodo existe: `path = ["A"]`, `total_cost = 0.0`. La misma entrada y versión producen una ruta determinista.

**Otras métricas en la topología de ejemplo:** `inverse_bandwidth` elige `A → C → D`, costo `1/20 + 1/20 = 0.1` (1/Mbps). `loss` elige `A → B → D`, costo `-ln(0.99) - ln(0.98) ≈ 0.030253` (adimensional). Estos son **valores esperados de diseño**, no mediciones de una implementación.

**Errores:** 400 `INVALID_INPUT` (parámetro faltante o métrica inválida); 404 `NODE_NOT_FOUND` (nodo bien formado, pero no existente); 404 `ROUTE_NOT_FOUND` (ambos nodos existen, pero no hay camino); 422 `NEGATIVE_CYCLE` (detección defensiva de Bellman-Ford ante una topología artificial inyectada en un test, con peso negativo y ciclo alcanzable). En una topología cargada normalmente **no puede darse** porque `delay_ms ≥ 0` y las otras métricas tampoco admiten pesos negativos; el caso prueba robustez sin alterar la validación de producción.

## 5. Controller — `POST /links/fail` y `POST /links/restore`

**Entrada común (cuerpo JSON):**

```json
{"source":"B","target":"D"}
```

`source` y `target` son nombres no vacíos; representan un enlace existente en un grafo no dirigido (`B,D` equivale a `D,B`). Un JSON mal formado o un campo ausente produce **400 `INVALID_INPUT`**; un enlace que no existe produce **404 `LINK_NOT_FOUND`**.

**`POST /links/fail` — respuesta HTTP 200:**

```json
{"link":{"source":"B","target":"D","enabled":false},"topology_version":2}
```

**`POST /links/restore` — respuesta HTTP 200:**

```json
{"link":{"source":"B","target":"D","enabled":true},"topology_version":3}
```

**Reglas verificables:** `LinkService` ordena el cambio mediante `TopologyDAO`, que lo persiste; el enlace inactivo se excluye de consultas posteriores. Repetir `/links/fail` sobre un enlace ya deshabilitado, o `/links/restore` sobre uno ya habilitado, devuelve **200 sin aumentar la versión** (idempotencia). Cada prueba parte de una copia de la topología versión 1, para evitar contaminación de estado. En el ejemplo: ruta inicial `A,B,D` costo 5 (versión 1); tras fallar `B,D`, `A,C,D` costo 9 (versión 2); tras restaurar, `A,B,D` costo 5 (versión 3). Si no existe alternativa, `/route` responde **404 `ROUTE_NOT_FOUND`**.

## 6. Router — `POST /packets`

**Entrada (cuerpo JSON):**

```json
{"packet_id":"pkt-001","src":"A","dst":"D","metric":"delay","payload":"hola"}
```

**Validación:** `packet_id`, `src`, `dst`: cadenas no vacías; `metric`: una de las tres métricas; `payload`: cadena (puede estar vacía). Todos los campos son obligatorios. Una solicitud mal formada devuelve **400 `INVALID_INPUT`** y no inicia forwarding.

**Flujo obligatorio:** `RouterAPI` valida la petición → `ForwardingService` utiliza `ControllerClient` para solicitar por HTTP `GET /route` → copia exactamente la ruta recibida en `trace` **sin calcular Bellman-Ford** → guarda `ForwardingResult` en `ForwardingLogDAO` → responde al cliente. `payload` no modifica el costo ni implica transmitir paquetes reales.

**Respuesta de éxito (HTTP 200):**

```json
{
  "packet_id": "pkt-001",
  "status": "delivered",
  "trace": ["A", "B", "D"],
  "route_cost": 5.0,
  "metric": "delay",
  "topology_version": 1
}
```

**Esquema de salida:** `packet_id`: cadena; `status`: `delivered` en respuestas 200; `trace`: arreglo de nodos igual a `path`; `route_cost`: número; `metric`: cadena admitida; `topology_version`: entero. La traza y el costo provienen del Controller.

**Errores:** si la consulta HTTP al Controller devuelve `NODE_NOT_FOUND` o `ROUTE_NOT_FOUND`, el Router registra el intento fallido y responde **404** con ese mismo `error.code`; los 400 originados por la consulta también se transmiten en el formato común. Ante desconexión o timeout (cliente HTTP: **2 s**), el Router registra el fallo y responde **503 `CONTROLLER_UNAVAILABLE`**. Si el DAO de registro falla, responde **500 `LOG_WRITE_FAILED`**, nunca un 200 ni un 503 que afirme implícitamente un registro exitoso.

**Persistencia:** para cada intento válido de forwarding, `ForwardingLogDAO` almacena al menos `packet_id`, `status` (`delivered`/`failed`), `trace`, `error_code` (o `null`), y `topology_version` cuando se conoce; el registro puede incluir `route_cost` y `metric`. Un error de validación previo al forwarding no se considera intento de reenvío. El Router no accede directamente a archivos desde el servicio ni desde la API.

## 7. Controller y Router — `GET /health`

**Entrada:** `GET /health` sin parámetros ni cuerpo en cada aplicación.  
**Respuesta del Controller (HTTP 200):**

```json
{"status":"ok","application":"controller"}
```

**Respuesta del Router (HTTP 200):**

```json
{"status":"ok","application":"router"}
```

**Criterio:** este endpoint informa si **el proceso consultado** responde, no garantiza conectividad con el otro proceso. Tras errores esperados (400, 404 y, en el Router, 503), su propia ruta `/health` debe seguir respondiendo HTTP 200 según NFR-06 y FR-09.

## 8. Ejemplos de respuestas de error JSON

**400 — solicitud inválida:**

```json
{"error":{"code":"INVALID_INPUT","message":"El parametro metric debe ser delay, inverse_bandwidth o loss"}}
```

**404 — nodo inexistente (`NODE_NOT_FOUND`):**

```json
{"error":{"code":"NODE_NOT_FOUND","message":"El nodo X no existe en la topologia"}}
```

**404 — ruta inalcanzable (`ROUTE_NOT_FOUND`):**

```json
{"error":{"code":"ROUTE_NOT_FOUND","message":"No hay ruta disponible entre A y D"}}
```

**404 — enlace inexistente (`LINK_NOT_FOUND`):**

```json
{"error":{"code":"LINK_NOT_FOUND","message":"No existe un enlace entre B y E"}}
```

**503 — Controller inaccesible desde Router:**

```json
{"error":{"code":"CONTROLLER_UNAVAILABLE","message":"El Controller no esta disponible o supero el tiempo de espera"}}
```

**500 — fallo al guardar registro del Router:**

```json
{"error":{"code":"LOG_WRITE_FAILED","message":"No fue posible guardar el resultado del reenvio"}}
```

**422 — ciclo negativo alcanzable (caso defensivo):**

```json
{"error":{"code":"NEGATIVE_CYCLE","message":"Se detecto un ciclo de costo negativo alcanzable"}}
```

Los mensajes son ejemplos legibles; los **códigos HTTP, `error.code` y la estructura JSON son obligatorios**. En particular: **un nodo inexistente no es lo mismo que dos nodos existentes sin ruta**.

## 9. Matriz de códigos HTTP y condiciones de error

| HTTP | `error.code` | Condición | Aplicación que responde |
|---|---|---|---|
| 200 | — | Consulta o operación satisfactoria | Ambas, según endpoint |
| 400 | `INVALID_INPUT` | Campo ausente, tipo incorrecto, JSON inválido o métrica fuera de lista | Ambas |
| 404 | `NODE_NOT_FOUND` | `src` o `dst` no existe en la topología | Controller; Router lo propaga en `/packets` |
| 404 | `ROUTE_NOT_FOUND` | `src` y `dst` existen, pero ninguna ruta está disponible | Controller; Router lo propaga en `/packets` |
| 404 | `LINK_NOT_FOUND` | Enlace solicitado no existe | Controller |
| 422 | `NEGATIVE_CYCLE` | Bellman-Ford detecta ciclo negativo alcanzable en prueba defensiva | Controller |
| 503 | `CONTROLLER_UNAVAILABLE` | Fallo de conexión o timeout al consultar el Controller | Router |
| 500 | `LOG_WRITE_FAILED` | Falla al persistir resultado de forwarding | Router |

**Precedencia de errores al reenviar:** si un intento válido produce un fallo de ruta o de comunicación, se intenta registrar ese fallo antes de responder con 404/503. Si **también falla el guardado**, la respuesta final será 500 `LOG_WRITE_FAILED`. Errores de entrada 400 se resuelven antes de llamar al servicio; no se exige log de forwarding de una solicitud rechazada.

## 10. Verificaciones y criterios de aceptación para Sesión 2

| Verificación | Petición / condición | Resultado esperado | Requisitos relacionados |
|---|---|---|---|
| API de topología | `GET /topology` | 200; incluye nodos, enlaces y `topology_version=1` | FR-01, FR-02, FR-05 |
| Ruta por demora | `GET /route?src=A&dst=D&metric=delay` | 200; `path=[A,B,D]`, `total_cost=5`, versión 1 | FR-03, FR-04, FR-05 |
| Ruta por ancho inverso | `metric=inverse_bandwidth` con topología de ejemplo | 200; `path=[A,C,D]`, costo 0.1 | FR-03, FR-04 |
| Fallo/restauración | `POST /links/fail`, luego `/route`, luego `/links/restore` | Versiones 2 y 3; rutas actualizadas; repetición sin aumento de versión | FR-06 |
| Envío satisfactorio | `POST /packets`, Controller disponible | 200; `trace=[A,B,D]`; se almacena resultado | FR-07, FR-08, FR-10 |
| Nodo inexistente | `/route?src=X&dst=D&metric=delay` | 404 `NODE_NOT_FOUND` | FR-09 |
| Ruta inexistente | Dos nodos válidos y desconectados | 404 `ROUTE_NOT_FOUND` (diferente de nodo inexistente) | FR-09 |
| Parámetros inválidos | `metric=unknown` o JSON de entrada inválido | 400 `INVALID_INPUT`, esquema de error uniforme | FR-05, FR-09 |
| Controller inactivo | `POST /packets` con Controller inaccesible | 503 `CONTROLLER_UNAVAILABLE` y fallo registrado | FR-07, FR-09, FR-10, NFR-11 |
| Persistencia fallida | `ForwardingLogDAO` simulado que falla | 500 `LOG_WRITE_FAILED` | FR-10 |
| Salud posterior al error | `GET /health` luego de un error esperado | 200 y `status=ok` en el proceso que permanece activo | FR-09, NFR-06 |

**Nota:** son **pruebas planificadas**, no resultados de ejecución. En la Sesión 1 no se genera código de implementación. En la Sesión 2 se comprueba el cumplimiento de los códigos, tipos, mensajes JSON y límites medibles (NFR-10/NFR-11).

## 11. Lista de control y aprobación de la especificación

- [x] Están todos los métodos/endpoints del contrato mínimo: topología, rutas, fallo, restauración, paquetes y salud de ambos procesos.
- [x] Cada endpoint tiene entrada y salida definidas, con ejemplos JSON en los endpoints que manejan cuerpos y ejemplos de respuestas GET.
- [x] Se documentan 400, 404, 422, 503 y 500 con estructura uniforme.
- [x] Se distingue `NODE_NOT_FOUND` de `ROUTE_NOT_FOUND`.
- [x] El Router consulta rutas por HTTP, no calcula rutas y registra resultados por DAO.
- [x] Las rutas, versiones y fallos coinciden con `01-requirements.md`, `02-static-architecture.md` y `03-dynamic-architecture.md`.
- [ ] **Estudiante A (Controller) — Erika Juliana Diaz Yanalá:** verificar contrato de `GET /topology`, `GET /route`, `/links/fail`, `/links/restore`, `/health`. Nombre/fecha: ____________________.
- [ ] **Estudiante B (Router) — Maria Camila Salazar Cifuentes:** verificar contrato de `POST /packets`, `/health`, propagación de errores y logs. Nombre/fecha: ____________________.
- [ ] **Ambas estudiantes:** aprobar versión S1-v1 como contrato base antes de programar en Sesión 2.

**Control de cambios:** revisión S1-v1: definición explícita de esquemas de entrada/salida, ejemplos para todos los endpoints, error uniforme, distinción nodo/ruta, versión e idempotencia, fallos de Controller y de persistencia. Cualquier cambio posterior debe anotar motivo y documentos afectados.


**Alcance de esta versión:** contrato propuesto para Sesión 2, no servidor implementado ni pruebas HTTP ejecutadas. Para respuestas `400`, la aplicación deberá adaptar los errores de validación que el framework pudiera devolver como `422` para respetar la especificación congelada.
