# 06. Especificación de pruebas — SDN educativo, Grupo 2 (Bellman-Ford)

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Estado:** pruebas diseñadas para Sesión 2; **ninguna se declara ejecutada o aprobada**.

## 1. Alcance y reglas de verificación

La Sesión 1 define las entradas, acciones y resultados **esperados**. En Sesión 2 se implementan con `pytest` u otro marco automatizado, se registran salidas auténticas en `test-results.txt` y se conserva evidencia. Según la guía deben aprobarse **al menos ocho pruebas**, obligatoriamente TC-08 y TC-09, incluyendo revisión de arquitectura. No se fabrican resultados.

Entorno de referencia: Controller en `localhost:8000`, Router en `localhost:8001`, configurables; archivos JSON `ejemplos/topology-example.json` (A–D) y `ejemplos/topology-isolated-example.json` (A–E, con E aislado); grafo no dirigido. **Cada prueba se ejecutará sobre una copia fresca del fixture y reiniciará `topology_version=1`, sin compartir cambios realizados por TC-03/04/17.** A–B = 2 ms / 10 Mbps / p=0.01; B–D = 3 ms / 10 Mbps / p=0.02; A–C = 4 ms / 20 Mbps / p=0.02; C–D = 5 ms / 20 Mbps / p=0.03. Inicio `topology_version=1`.

## 1.1. Preparación y control de condiciones

1. Mantener `ejemplos/topology-example.json` **inmutable**; las pruebas de fallo/restauración copian el archivo a un directorio temporal antes de cambiar `enabled`/`topology_version`.
2. Para `TC-10`, cargar específicamente `ejemplos/topology-isolated-example.json`, que contiene el nodo `E` sin enlaces. Si se usa el ejemplo normal A–D, la prueba A→E devuelve correctamente `NODE_NOT_FOUND` y **no** sirve para probar `ROUTE_NOT_FOUND`.
3. Los resultados del mismo endpoint entre dos pruebas no son comparables si cambió la versión; por eso se reinicia el fixture con versión 1.
4. Los casos se **especifican** en Sesión 1; su ejecución y la generación de `test-results.txt` corresponden exclusivamente a Sesión 2.

## 2. Casos automatizables con resultados esperados

| ID | Acción / entrada | Resultado esperado (criterio verificable) | Requisitos | Responsable |
|---|---|---|---|---|
| TC-01 | `GET /route?src=A&dst=D&metric=delay` | 200, `path=[A,B,D]`, `total_cost=5`, `topology_version=1`. | FR-03, FR-05 | A |
| TC-02 | Consultar `delay`, `inverse_bandwidth`, `loss` sobre ejemplo. | Costos por enlace `d`, `1/b`, `-ln(1-p)`; inverso elige `[A,C,D]` con 0.1 y pérdida elige `[A,B,D]` con ≈0.030253. | FR-04 | A |
| TC-03 | `POST /links/fail` B–D y repetir consulta de ruta. | 200 en fallo, versión 2, alternativa `[A,C,D]` con costo 9 ms. | FR-06 | A |
| TC-04 | Restaurar B–D y consultar ruta. | 200 en restauración, versión 3, ruta `[A,B,D]` con costo 5 ms. | FR-06 | A |
| TC-05 | Enviar paquete instrumentando cliente HTTP. | Router realiza `GET /route` real o verificable mediante doble HTTP, **no** calcula rutas localmente. | FR-07, NFR-03 | B |
| TC-06 | Enviar pkt-001 A→D mediante `POST /packets`. | 200, `status=delivered`, `trace=[A,B,D]` y guardado en DAO antes del 200. | FR-08, FR-10 | B |
| TC-07 | Apagar/desconectar Controller durante un paquete. | Router devuelve 503 `CONTROLLER_UNAVAILABLE`, registra fallo, `/health` Router sigue 200. | FR-09, FR-10, NFR-06 | B |
| TC-08 | Inyectar `FakeTopologyDAO` a `RoutingService` sin HTTP/disco. | Ruta correcta sin servidor ni archivos reales; aislamiento de DAO demostrado. **Obligatoria.** | NFR-02, NFR-07, NFR-09 | A |
| TC-09 | Inyectar `FakeForwardingLogDAO` y cliente HTTP fake a `ForwardingService`. | Resultado correcto y operación `save` invocada sin disco ni Controller real. **Obligatoria.** | FR-10, NFR-02, NFR-07, NFR-09 | B |
| TC-10 | Con `topology-isolated-example.json`, consultar A→Z (Z ausente) y A→E (E existe aislado). | Primer caso 404 `NODE_NOT_FOUND`; segundo 404 `ROUTE_NOT_FOUND` (sin confundir ausencia de nodo con ausencia de camino). | FR-09 | A+B |
| TC-11 | Analizar código de handlers, servicios y DAOs. | MVC presente en ambos; endpoints sin Bellman-Ford, forwarding ni acceso a archivos; DAOs reemplazables. | NFR-01, NFR-02, NFR-03, NFR-07 | A+B |
| TC-12 | Medir 100 `GET /route` consecutivos, con grafo concreto ≤100 nodos/300 enlaces; documentar equipo, carga, configuración y 100 tiempos HTTP de extremo a extremo. | Ordenar las 100 muestras y tomar la posición 95 como p95; aceptar si p95 ≤500 ms. Guardar resultados reales. | NFR-10 | A+B |
| TC-13 | Simular 20 errores de conexión/timeout, timeout HTTP de 2 s. | 20/20 respuestas 503 `CONTROLLER_UNAVAILABLE` en ≤3 s y Router estable. | NFR-11, FR-09 | B |
| TC-14 | Inyectar en unidad un grafo artificial no válido con arista negativa alcanzable en grafo no dirigido mediante fake, sin pasar por validación ordinaria de JSON. | Bellman-Ford detecta un ciclo negativo alcanzable y la capa de API, al recibir ese error del servicio, lo representa como 422 `NEGATIVE_CYCLE`. El esquema de producción sigue rechazando `delay_ms < 0`. | FR-03 | A |
| TC-15 | Leer `ejemplos/topology-example.json` mediante `JsonTopologyDAO`; probar JSON mal formado. | Nodos/enlaces/versión correctos; fallo inválido de carga es controlado y no produce topología falsa. | FR-01 | A |
| TC-16 | Cargar grafos válidos: lineal, malla y desconectado (con aislados). | Los tres se representan sin modificar `RoutingService` ni `TopologyDAO` y conservan nodos/enlaces. | FR-02 | A |
| TC-17 | Fallar dos veces B–D y restaurar dos veces B–D. | Primer cambio aumenta versión 1→2, segundo mantiene 2; restauración 2→3 y repetida mantiene 3. | FR-06 | A |
| TC-18 | `FakeForwardingLogDAO.save` lanza error en intento de forwarding. | Respuesta 500 `LOG_WRITE_FAILED`, nunca 200 ni 503 falso; el Router sigue disponible. | FR-10, FR-09 | B |
| TC-19 | Cambiar puertos, `TOPOLOGY_FILE`, `FORWARDING_LOG_FILE` y `CONTROLLER_URL` desde configuración. | Apps utilizan nueva configuración sin modificar lógica; nuevos puertos/archivos/URL efectivos. | NFR-05 | A+B |
| TC-20 | Enviar JSON inválido, `metric=unknown` y campo requerido vacío; luego consultar `/health`. | 400 `INVALID_INPUT` con `error.code/message`, no 422 de validación de framework; salud 200 después. | FR-05, FR-09, NFR-04, NFR-06 | A+B |
| TC-21 | Construir dos rutas de costo mínimo idéntico. | Siempre se retorna la ruta lexicográficamente menor, con versión idéntica. | FR-03 | A |
| TC-22 | Definir enlace con `loss_probability=1` y consulta usando cada métrica. | Enlace inutilizable se excluye de rutas `delay`, `inverse_bandwidth` y `loss`; nunca aplicar `ln(0)`. | FR-04 | A |

## 3. Casos mínimos prioritarios para Sesión 2

Primer bloque sugerido para conseguir **ocho resultados reales**: TC-01, TC-02, TC-03, TC-04, TC-05, TC-06, **TC-08** y **TC-09**. Después priorizar TC-07, TC-10, TC-11 y pruebas medibles TC-12/13. El orden es sugerido; solo cuentan como aprobadas las que efectivamente pasen. La inspección de código debe demostrar separación MVC/DAO incluso si se tienen ocho tests verdes.

## 4. Trazabilidad de requisitos no funcionales

| NFR | Tests/verificación |
|---|---|
| NFR-01 | TC-11 (MVC de ambas apps) |
| NFR-02 | TC-08, TC-09, TC-11 |
| NFR-03 | TC-05, TC-11 |
| NFR-04 | TC-01, TC-03–07, TC-10, TC-20 y comparación con `04-api-contract.md` |
| NFR-05 | TC-19 |
| NFR-06 | TC-07, TC-18, TC-20 |
| NFR-07 | TC-08, TC-09, TC-11 |
| NFR-08 | Matriz de `05-implementation-plan.md` + correspondencias de esta tabla |
| NFR-09 | TC-08 y TC-09 |
| NFR-10 | TC-12 |
| NFR-11 | TC-13 |

## 5. Registro de resultados (solo Sesión 2)

Guardar comandos, entorno, versión de topología y salida auténtica de pruebas en `test-results.txt`. Si TC-12/TC-13 fallan, registrar el valor real, diagnóstico y limitación; nunca rebajar umbrales para declarar éxito. Los *mocks/fakes* pueden demostrar aislamiento; las pruebas end-to-end deben usar dos procesos reales y HTTP efectivo.

**Responsables:** **Erika Juliana Diaz Yanalá** documentará pruebas del Controller; **Maria Camila Salazar Cifuentes** las del Router; ambas realizarán pruebas de integración y revisión de código.
