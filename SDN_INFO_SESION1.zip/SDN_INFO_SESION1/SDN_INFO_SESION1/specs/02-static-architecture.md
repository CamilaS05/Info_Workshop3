# 02. Arquitectura estática — SDN educativo (Grupo 2, Bellman-Ford)

**Equipo — Grupo 2:** **Estudiante A (SDN Controller): Erika Juliana Diaz Yanalá**; **Estudiante B (SDN Router): Maria Camila Salazar Cifuentes**.  
**Fecha de preparación:** 27 de octubre de 2026. **Línea base propuesta:** S1-v1; pendiente de verificación y aprobación de ambas.  

**Versión:** S1-v1 (revisada)  
**Estado:** especificación completa para revisión final y aprobación de Estudiante A y Estudiante B.  
**Etapa:** Sesión 1 — diseño; **no** incluye código de implementación ni pruebas ejecutadas.

## Localización de los requisitos solicitados

| Requisito de la Sesión 1 | Dónde se evidencia en este archivo |
|---|---|
| **Diagrama de componentes** | **Sección 2**: procesos independientes, conexión HTTP REST/JSON, capas MVC, servicios, DAO y límites de persistencia. |
| **Diagrama de clases** | **Secciones 3 y 4**: clases del Controller y del Router, atributos, métodos públicos, asociaciones, dependencias, interfaces y responsables. |
| **Mapeo MVC para ambas aplicaciones** | **Sección 5**: tabla de Model, View y Controller; complementada con las secciones 3.1 y 4.1. |
| **DAOs en ambas aplicaciones** | **Secciones 2.1, 3.1, 4.1 y 5**: interfaces `TopologyDAO`/`ForwardingLogDAO`, implementaciones y archivos propios. |
| **Inyección de dependencias** | **Sección 6**: construcción por bootstrap, dependencias por constructor y sustitución por fake/mock. También representada en los diagramas de las secciones 2, 3 y 4. |
| **Coherencia y aceptación** | **Secciones 7 y 8**: correspondencia con API, secuencias, pruebas y lista de revisión. |

## 1. Objetivo, alcance y decisiones de diseño

Se diseñan **dos aplicaciones Python independientes** que intercambian mensajes mediante **HTTP REST/JSON**:

- **Controller (Estudiante A: Erika Juliana Diaz Yanalá):** es propietario de la topología, calcula rutas con **NetworkX y Bellman-Ford**, y permite deshabilitar/restaurar enlaces.
- **Router (Estudiante B: Maria Camila Salazar Cifuentes):** recibe paquetes simulados, **consulta la ruta al Controller mediante HTTP**, simula el reenvío siguiendo exactamente esa ruta y guarda los resultados.

No hay OpenFlow ni transmisión de paquetes reales. Ambas aplicaciones implementan **MVC, servicios de dominio, abstracciones DAO e inyección de dependencias**. Los controladores HTTP no calculan rutas, no simulan forwarding y no leen o escriben archivos. Las reglas de entrada, salida y errores se definen en `01-requirements.md` y `04-api-contract.md`.

**Convenciones propuestas, consistentes con el documento 01 (requieren aprobación de A y B):** grafo no dirigido; nodos identificados mediante cadenas no vacías; enlaces sin duplicados ni bucles; pueden existir nodos aislados; métricas `delay`, `inverse_bandwidth` y `loss`; los enlaces inactivos y los de pérdida igual a 1 no se usan para enrutar. `topology_version` empieza en 1 y solo aumenta ante un cambio real de estado de un enlace. Las solicitudes repetidas de falla/restauración son idempotentes.

## 2. Diagrama de componentes

> Las líneas **continuas** representan solicitudes, dependencias o acceso a través de interfaces; las líneas **punteadas** indican construcción/inyectado de dependencias o implementación de una interfaz. Los dos recuadros son **procesos independientes**.

```mermaid
flowchart LR
    U["Cliente REST"]

    subgraph ROUTER["Proceso independiente: Router"]
        RB["RouterBootstrap: construye e inyecta"]
        RA["RouterAPI: Controller MVC"]
        RV["Views: PacketRequest, ForwardingResponse, ErrorResponse"]
        RM["Models: Packet, ForwardingResult"]
        FS["ForwardingService: logica de reenvio"]
        HC["ControllerClient: adaptador HTTP"]
        FD["ForwardingLogDAO: interfaz"]
        JFD["JsonlForwardingLogDAO: implementacion"]
        LOG[("forwarding.jsonl")]

        RA --> RV
        RA --> FS
        FS --> RM
        FS --> HC
        FS --> FD
        JFD -. implementa .-> FD
        JFD --> LOG
        RB -. inyecta .-> RA
        RB -. inyecta .-> FS
        RB -. configura .-> HC
        RB -. construye .-> JFD
    end

    subgraph CONTROLLER["Proceso independiente: Controller"]
        CB["ControllerBootstrap: construye e inyecta"]
        CA["ControllerAPI: Controller MVC"]
        CV["Views: TopologyResponse, RouteResponse, LinkStateResponse, ErrorResponse"]
        CM["Models: Topology, Link, Route"]
        RS["RoutingService: NetworkX y Bellman-Ford"]
        LS["LinkService: falla y restauracion"]
        TD["TopologyDAO: interfaz"]
        JTD["JsonTopologyDAO: implementacion"]
        TOPO[("topology.json")]

        CA --> CV
        CA --> RS
        CA --> LS
        RS --> CM
        RS --> TD
        LS --> TD
        JTD -. implementa .-> TD
        JTD --> TOPO
        CB -. inyecta .-> CA
        CB -. inyecta .-> RS
        CB -. inyecta .-> LS
        CB -. construye .-> JTD
    end

    U -->|"POST /packets y GET /health"| RA
    U -->|"GET /topology, GET /route, POST /links/*, GET /health"| CA
    HC -->|"HTTP REST/JSON: GET /route"| CA
```

### 2.1. Límites entre procesos y persistencia

| Elemento | Controller | Router |
|---|---|---|
| Proceso y puerto | Proceso Python; puerto configurable (ejemplo: 8000). | Proceso Python; puerto configurable (ejemplo: 8001). |
| Responsabilidad principal | Mantener topología y elegir rutas. | Solicitar rutas y simular forwarding. |
| Modelo (dominio) | `Topology`, `Link`, `Route`. | `Packet`, `ForwardingResult`. |
| Servicio de dominio | `RoutingService`, `LinkService`. | `ForwardingService`. |
| Acceso a datos | Interfaz `TopologyDAO`, implementación `JsonTopologyDAO`. | Interfaz `ForwardingLogDAO`, implementación `JsonlForwardingLogDAO`. |
| Persistencia propia | `topology.json`, leído/actualizado exclusivamente por `JsonTopologyDAO`. | `forwarding.jsonl`, leído/escrito exclusivamente por `JsonlForwardingLogDAO`. |
| Comunicación entre procesos | Expone REST/JSON. | `ControllerClient` consume `GET /route` del Controller por HTTP. |

**Regla obligatoria:** el Router no accede a `topology.json`, no importa clases internas del Controller y no ejecuta Bellman-Ford. El Controller no escribe `forwarding.jsonl`. Los datos de la ruta se comunican como JSON y el Router los interpreta según el contrato API.

## 3. Diagrama de clases del Controller (Estudiante A: Erika Juliana Diaz Yanalá)

Incluye las **clases, atributos, métodos públicos, asociaciones, DAOs y punto de composición**. Los métodos de las API corresponden a los endpoints descritos en `04-api-contract.md`.

```mermaid
classDiagram
    class Topology {
        +list nodes
        +list links
        +int version
    }
    class Link {
        +str source
        +str target
        +float delay_ms
        +float bandwidth_mbps
        +float loss_probability
        +bool enabled
    }
    class Route {
        +list path
        +str metric
        +float total_cost
        +int topology_version
    }
    class TopologyDAO {
        <<interface>>
        +get_topology() Topology
        +set_link_status(src,dst,enabled) Topology
    }
    class JsonTopologyDAO {
        +str file_path
        +JsonTopologyDAO(file_path)
        +get_topology() Topology
        +set_link_status(src,dst,enabled) Topology
    }
    class RoutingService {
        +TopologyDAO topology_dao
        +RoutingService(topology_dao)
        +get_route(src,dst,metric) Route
    }
    class LinkService {
        +TopologyDAO topology_dao
        +LinkService(topology_dao)
        +get_topology() Topology
        +set_status(src,dst,enabled) Topology
    }
    class ControllerAPI {
        +RoutingService routing_service
        +LinkService link_service
        +ControllerAPI(routing_service,link_service)
        +get_topology()
        +get_route(src,dst,metric)
        +fail_link(source,target)
        +restore_link(source,target)
        +health()
    }
    class ControllerViews {
        <<View>>
        +TopologyResponse
        +RouteResponse
        +LinkStateRequest
        +LinkStateResponse
        +ErrorResponse
        +HealthResponse
    }
    class ControllerBootstrap {
        +build_app() ControllerAPI
    }

    Topology "1" o-- "0..*" Link : contiene
    JsonTopologyDAO ..|> TopologyDAO : implementa
    RoutingService --> TopologyDAO : usa interfaz inyectada
    RoutingService ..> Route : crea
    LinkService --> TopologyDAO : usa interfaz inyectada
    ControllerAPI --> RoutingService : delega
    ControllerAPI --> LinkService : delega
    ControllerAPI ..> ControllerViews : valida y serializa
    ControllerBootstrap ..> JsonTopologyDAO : construye
    ControllerBootstrap ..> RoutingService : inyecta DAO
    ControllerBootstrap ..> LinkService : inyecta DAO
    ControllerBootstrap ..> ControllerAPI : inyecta servicios
```

### 3.1. Responsabilidades — Controller

| Clase / módulo | Responsabilidad y límites |
|---|---|
| `Topology` y `Link` (**Model**) | Representan nodos, enlaces y propiedades; topología no dirigida y versión vigente. Sin operaciones de archivo ni HTTP. |
| `Route` (**Model**) | Conserva camino, métrica, costo total y `topology_version`. |
| `ControllerViews` (**View**) | Agrupa esquemas de entrada/salida: topología, ruta, cambio de enlace, salud y errores JSON. Solo validación/formato; no algoritmo. |
| `ControllerAPI` (**Controller MVC**) | Maneja `GET /topology`, `GET /route`, `POST /links/fail`, `POST /links/restore` y `GET /health`. Valida solicitud, delega a servicios y serializa respuesta/errores. **No toca DAO ni archivos directamente.** |
| `RoutingService` (**servicio de dominio**) | Obtiene topología mediante `TopologyDAO`, valida origen/destino, descarta enlaces no utilizables, calcula pesos (`delay_ms`, `1/bandwidth_mbps`, `-ln(1-loss_probability)`), usa NetworkX y Bellman-Ford, detecta ciclos negativos alcanzables cuando corresponda y construye `Route`. |
| `LinkService` (**servicio de dominio**) | Consulta el estado de topología y solicita al DAO fallar o restaurar enlaces; el DAO garantiza persistencia y versión consistente. |
| `TopologyDAO` (**interfaz DAO**) | Define `get_topology()` y `set_link_status(...)`; las reglas de dominio no dependen de la implementación JSON. |
| `JsonTopologyDAO` (**DAO concreto**) | Carga/valida el JSON, modifica y guarda el estado de enlace; incrementa la versión solo si hay un cambio real. Es la **única** clase del Controller que accede a `topology.json`. |
| `ControllerBootstrap` (**composición/DI**) | Lee configuración y construye `JsonTopologyDAO`; la inyecta a `RoutingService` y `LinkService` y luego inyecta ambos servicios a `ControllerAPI`. No contiene lógica de negocio. |

## 4. Diagrama de clases del Router (Estudiante B: Maria Camila Salazar Cifuentes)

```mermaid
classDiagram
    class Packet {
        +str packet_id
        +str src
        +str dst
        +str metric
        +str payload
    }
    class ForwardingResult {
        +str packet_id
        +str status
        +list trace
        +float route_cost
        +str metric
        +str error_code
        +int topology_version
    }
    class ControllerClient {
        +str base_url
        +float timeout_seconds
        +ControllerClient(base_url,timeout_seconds)
        +get_route(src,dst,metric) RouteData
    }
    class RouteData {
        +list path
        +str metric
        +float total_cost
        +int topology_version
    }
    class ForwardingLogDAO {
        <<interface>>
        +save(result) void
        +list_results() list
    }
    class JsonlForwardingLogDAO {
        +str file_path
        +JsonlForwardingLogDAO(file_path)
        +save(result) void
        +list_results() list
    }
    class ForwardingService {
        +ControllerClient controller_client
        +ForwardingLogDAO log_dao
        +ForwardingService(controller_client,log_dao)
        +forward(packet) ForwardingResult
    }
    class RouterAPI {
        +ForwardingService forwarding_service
        +RouterAPI(forwarding_service)
        +post_packet(packet)
        +health()
    }
    class RouterViews {
        <<View>>
        +PacketRequest
        +ForwardingResponse
        +ErrorResponse
        +HealthResponse
    }
    class RouterBootstrap {
        +build_app() RouterAPI
    }

    ControllerClient ..> RouteData : interpreta JSON de ruta
    ForwardingService --> ControllerClient : usa cliente inyectado
    ForwardingService --> ForwardingLogDAO : usa interfaz inyectada
    ForwardingService ..> Packet : recibe
    ForwardingService ..> ForwardingResult : crea y registra
    JsonlForwardingLogDAO ..|> ForwardingLogDAO : implementa
    RouterAPI --> ForwardingService : delega
    RouterAPI ..> RouterViews : valida y serializa
    RouterBootstrap ..> ControllerClient : construye y configura
    RouterBootstrap ..> JsonlForwardingLogDAO : construye
    RouterBootstrap ..> ForwardingService : inyecta cliente y DAO
    RouterBootstrap ..> RouterAPI : inyecta servicio
```

**Nota sobre `RouteData`:** es un DTO local del Router que decodifica el JSON del Controller (`path`, `metric`, `total_cost`, `topology_version`). No importa la clase `Route` del Controller; por ello la independencia entre los procesos se mantiene.

### 4.1. Responsabilidades — Router

| Clase / módulo | Responsabilidad y límites |
|---|---|
| `Packet` (**Model**) | Representa `packet_id`, `src`, `dst`, `metric` y `payload`. |
| `ForwardingResult` (**Model**) | Representa estado `delivered`/`failed`, traza, costo, métrica, código de error y versión, cuando estén disponibles. |
| `RouterViews` (**View**) | Valida el paquete recibido y serializa respuestas de reenvío, salud y errores del contrato API. No hace forwarding. |
| `RouterAPI` (**Controller MVC**) | Maneja `POST /packets` y `GET /health`; delega a `ForwardingService` y transforma resultados/errores en HTTP. No calcula rutas ni escribe archivos. |
| `ForwardingService` (**servicio de dominio**) | Solicita ruta a `ControllerClient`, copia el camino seleccionado como `trace`, produce resultado simulado y registra **todos los intentos**, exitosos o fallidos, usando `ForwardingLogDAO`. No usa NetworkX. |
| `ControllerClient` (**adaptador HTTP**) | Consume `GET /route?src=...&dst=...&metric=...`, decodifica JSON y comunica errores controlados (incluido timeout, 2 s por defecto). Se inyecta en el servicio y puede reemplazarse por un fake en pruebas. |
| `ForwardingLogDAO` (**interfaz DAO**) | Define las operaciones `save(...)` y `list_results()` sin dependencia de disco. |
| `JsonlForwardingLogDAO` (**DAO concreto**) | Guarda/consulta resultados en `forwarding.jsonl`. Es la **única** clase del Router que accede al archivo de registro. |
| `RouterBootstrap` (**composición/DI**) | Construye cliente HTTP y DAO concreto, los inyecta en `ForwardingService`, e inyecta este servicio en `RouterAPI`. |

## 5. Mapeo explícito MVC y DAO de las dos aplicaciones

| Aplicación | Model (datos) | View (esquemas JSON) | Controller MVC (HTTP) | Servicios (reglas de negocio) | DAO / almacenamiento |
|---|---|---|---|---|---|
| **Controller** | `Topology`, `Link`, `Route` | `ControllerViews`: `TopologyResponse`, `RouteResponse`, `LinkStateRequest/Response`, `ErrorResponse`, `HealthResponse` | `ControllerAPI` | `RoutingService`, `LinkService` | `TopologyDAO` → `JsonTopologyDAO` → `topology.json` |
| **Router** | `Packet`, `ForwardingResult` y DTO local `RouteData` | `RouterViews`: `PacketRequest`, `ForwardingResponse`, `ErrorResponse`, `HealthResponse` | `RouterAPI` | `ForwardingService` (utiliza `ControllerClient`) | `ForwardingLogDAO` → `JsonlForwardingLogDAO` → `forwarding.jsonl` |

**Separación entre capas:** el **Controller MVC** atiende HTTP, el **View** describe los JSON de entrada/salida, el **Model** representa datos del dominio, los **servicios** ejecutan las reglas y el **DAO** encapsula exclusivamente la persistencia. El nombre `ControllerAPI` identifica la capa MVC del servicio Controller; no debe confundirse con el proceso SDN Controller.

## 6. Inyección de dependencias: diseño verificable

La **inyección por constructor** (o proveedor de dependencias equivalente de FastAPI) se configura **al arrancar cada aplicación**, no dentro de cada endpoint.

| Paso | Controller | Router |
|---|---|---|
| 1. Configurar | `TOPOLOGY_FILE`, `CONTROLLER_PORT`. | `FORWARDING_LOG_FILE`, `ROUTER_PORT`, `CONTROLLER_URL`, `CONTROLLER_TIMEOUT_SECONDS`. |
| 2. Crear implementaciones | `JsonTopologyDAO(file_path)` | `JsonlForwardingLogDAO(file_path)` y `ControllerClient(base_url, timeout_seconds)` |
| 3. Inyectar en servicios | `RoutingService(topology_dao)` y `LinkService(topology_dao)` reciben **la interfaz** `TopologyDAO`. | `ForwardingService(controller_client, log_dao)` recibe cliente HTTP y **la interfaz** `ForwardingLogDAO`. |
| 4. Inyectar en APIs | `ControllerAPI(routing_service, link_service)` | `RouterAPI(forwarding_service)` |
| 5. Sustitución en pruebas | Cambiar `JsonTopologyDAO` por `FakeTopologyDAO` **sin modificar** `RoutingService` (TC-08). | Cambiar `JsonlForwardingLogDAO` por `FakeForwardingLogDAO` y el cliente real por un fake **sin modificar** `ForwardingService` (TC-09). |

**Contrato de arquitectura:** solo los DAOs concretos acceden a los archivos. Los servicios dependen de **interfaces DAO**, nunca instancian implementaciones concretas. Los handlers HTTP dependen de servicios inyectados, nunca crean DAOs ni ejecutan el algoritmo. La configuración es externa y puede cambiarse sin modificar el código (NFR-01, NFR-02, NFR-03, NFR-05, NFR-07 y NFR-09).

## 7. Consistencia con REST, secuencias y pruebas

| Escenario | Clases participantes (todas figuran en los diagramas) | Endpoint | Pruebas planificadas |
|---|---|---|---|
| Consultar topología | `ControllerAPI` → `LinkService` → `TopologyDAO` | Controller `GET /topology` | TC-08 y prueba de contrato |
| Consultar ruta | `ControllerAPI` → `RoutingService` → `TopologyDAO` | Controller `GET /route` | TC-01, TC-02, TC-08, TC-14 |
| Fallar/restaurar enlace | `ControllerAPI` → `LinkService` → `TopologyDAO` | Controller `POST /links/fail` / `POST /links/restore` | TC-03, TC-04 |
| Enviar paquete | `RouterAPI` → `ForwardingService` → `ControllerClient` → Controller REST; `ForwardingService` → `ForwardingLogDAO` | Router `POST /packets` | TC-05, TC-06, TC-09 |
| Controller no disponible | `ControllerClient` → `ForwardingService` → `ForwardingLogDAO` → `RouterAPI` | Router responde HTTP 503; su `GET /health` sigue en 200 | TC-07, TC-13 |
| Comprobar separación arquitectónica | `ControllerAPI`, `RouterAPI`, `RoutingService`, `ForwardingService`, ambos DAO | Revisión de capas | TC-08, TC-09, TC-11 |

**Aclaración del ciclo negativo:** las topologías normales rechazan retardos negativos. TC-14 inyecta un grafo artificial con pesos negativos mediante un fake para probar que Bellman-Ford detecta un ciclo negativo alcanzable; el caso no amplía el esquema de entrada permitido.

**Errores controlados previstos:** `INVALID_INPUT` (400), `NODE_NOT_FOUND` (404), `ROUTE_NOT_FOUND` (404), `LINK_NOT_FOUND` (404), `NEGATIVE_CYCLE` (422), `CONTROLLER_UNAVAILABLE` (503, Router) y `LOG_WRITE_FAILED` (500). Para cada caso las APIs entregan `{"error":{"code":"...","message":"..."}}` según `04-api-contract.md`. `ForwardingService` registra el resultado fallido cuando el DAO está disponible; si el registro falla, se informa `LOG_WRITE_FAILED`, no se declara falsamente éxito.

**Coherencia de secuencias:** las clases `RouterAPI`, `ForwardingService`, `ControllerClient`, `ControllerAPI`, `RoutingService`, `TopologyDAO`, `LinkService` y `ForwardingLogDAO` utilizadas en los tres diagramas de `03-dynamic-architecture.md` también aparecen en este documento. Las respuestas entre procesos se transmiten por JSON, no por referencias a objetos Python.

## 8. Lista de aceptación de la arquitectura estática (Sesión 1)

- [x] Dos **procesos** representados y conectados por REST/JSON.
- [x] **Diagrama de componentes** con MVC, servicios, interfaces DAO, implementaciones y límites de persistencia.
- [x] **Diagramas de clases** de ambas aplicaciones con atributos, métodos públicos y asociaciones/dependencias.
- [x] **Mapeo MVC** explícito para Controller y Router.
- [x] **DAO** identificado e implementaciones de archivo encapsuladas para ambas aplicaciones.
- [x] **Inyección de dependencias** explicada, reflejada en diagramas y sustituible por mocks/fakes.
- [x] Clases y métodos de secuencias compatibles con `03-dynamic-architecture.md` y endpoints mínimos de `04-api-contract.md`.
- [x] Bellman-Ford solo en `RoutingService` y forwarding solo en `ForwardingService`.
- [ ] **Aprobación real de Estudiante A (Erika Juliana Diaz Yanalá):** fecha y confirmación ____________________.
- [ ] **Aprobación real de Estudiante B (Maria Camila Salazar Cifuentes):** fecha y confirmación ____________________.

**Nota de entrega:** en Sesión 1 se presentan diagramas y especificaciones, no aplicaciones ejecutadas. Esta lista confirma elementos **descritos** en el diseño, pero **no** implementación ni pruebas aprobadas; eso se comprueba en Sesión 2.


**Comprobación adicional de coherencia:** `ControllerClient.get_route()` produce un DTO `RouteData` local en el Router; los intercambios entre procesos son únicamente REST/JSON. Consultar las pruebas TC-05, TC-08, TC-09 y TC-11.
