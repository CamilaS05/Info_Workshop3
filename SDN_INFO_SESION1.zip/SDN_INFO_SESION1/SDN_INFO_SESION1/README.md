# Grupo 2 — Sesión 1 completa a nivel documental | SDN Bellman-Ford

**Integrantes:**
- **Estudiante A — Controller:** Erika Juliana Diaz Yanalá
- **Estudiante B — Router:** Maria Camila Salazar Cifuentes

**Versión documental definitiva preparada:** 28 de octubre de 2026. **Sesión 2:** comenzar únicamente tras la aprobación real de ambas integrantes.

## Alcance y estado real

Se incluyen los **seis documentos `specs/`**, `prompts-session1.md`, los **seis diagramas editables Mermaid**, representaciones gráficas de apoyo, un JSON de topología **solo de ejemplo**, y guías de comprobación/evidencia. El diseño queda alineado en requisitos, clases, secuencias, contratos y pruebas. **No se ha generado código Python de implementación ni ejecutado los tests**.

**Estado de revisión:** especificaciones preparadas; **aún falta revisión y confirmación real por ambas estudiantes** y llenar el registro de prompts con uso/evidencias auténticos. No corresponde declarar las casillas de aprobación completadas automáticamente.

## 7 entregables oficiales

1. `specs/01-requirements.md`: FR-01–FR-10, NFR-01–NFR-11; entradas, salidas, errores, criterios, casos de uso.
2. `specs/02-static-architecture.md`: componente, dos diagramas de clases, MVC y DAO en las dos apps, DI.
3. `specs/03-dynamic-architecture.md`: 3 secuencias de envío, caída/restauración y timeout.
4. `specs/04-api-contract.md`: todos los endpoints, parámetros, JSON y errores.
5. `specs/05-implementation-plan.md`: roles, plan de la segunda sesión, matriz de trazabilidad y acta de congelamiento.
6. `specs/06-test-specification.md`: 22 pruebas diseñadas, incluidas TC-08 y TC-09 obligatorias.
7. `prompts-session1.md`: 5 técnicas, 6 prompts modelo, ambigüedades y registro pendiente de ejecución real.

## Otros archivos

- `diagramas/`: fuentes `.mmd` de los seis diagramas y PNG de referencia/consulta.
- `ejemplos/topology-example.json`: topología base (A–D), para rutas y cambios de enlace.
- `ejemplos/topology-isolated-example.json`: segunda topología con `E` aislado para TC-10; **ninguna es código de la aplicación**.
- `demo-evidence/`: guardar capturas propias auténticas según `EVIDENCIAS_Y_PASOS.md`.
- `controller/`, `router/`, `tests/`: carpetas vacías para desarrollar **en Sesión 2**.
- `VERIFICACION_CRUZADA.md`: hallazgos y correspondencia entre archivos.
- `AUDITORIA_Y_PUNTUACION_100.md`: calificación argumentada antes/después, criterios y pendientes.
- `ACTA_APROBACION_S1-v1.md`: formato para que las estudiantes aprueben de verdad la línea base.
- `PREPARACION_SESION2.md`: comprobación rápida de herramientas y comienzo de implementación según la línea base.

## Qué hacer primero en la Sesión 2

1. Revisar y aprobar S1-v1 ambas estudiantes; confirmar decisiones de grafo y errores.
2. Crear entornos y servicios únicamente después de aprobar el diseño.
3. Erika implementa Controller; Maria Camila implementa Router; integrar mediante REST.
4. Ejecutar al menos **ocho tests aprobados**, incluidos TC-08 y TC-09; guardar salida real de pytest y capturas de la demostración.

**Nota:** la guía de la actividad prohíbe generar código de implementación en la Sesión 1. Esta entrega conserva dicha separación.

**Reevaluación solicitada:** nota documental orientativa **94/100** con umbral **90/100**. Véase `AUDITORIA_Y_PUNTUACION_100.md`. Los registros de IA y la aprobación real de ambas estudiantes siguen pendientes.
