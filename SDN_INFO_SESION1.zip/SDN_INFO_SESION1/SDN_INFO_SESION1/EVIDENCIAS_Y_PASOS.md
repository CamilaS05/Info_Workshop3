# Evidencias y últimos pasos para cerrar Sesión 1

**Erika Juliana Diaz Yanalá = Estudiante A (Controller)**  
**Maria Camila Salazar Cifuentes = Estudiante B (Router)**

## Qué es obligatorio y qué no

La guía exige **seis documentos de especificación y `prompts-session1.md`**, uso y documentación de cinco técnicas de IA, ≥3 ambigüedades resueltas por juicio propio, coherencia entre documentos y aprobación de las dos integrantes. Los diagramas son evidencia técnica del diseño. **No exige capturas de ejecución de Python en Sesión 1** (son de Sesión 2). El registro de prompts debe reflejar interacciones reales y sus correcciones.

## Pasos rápidos para evidencias reales

1. **Estructura:** abrir esta carpeta en VS Code, desplegar `specs/` y `prompts-session1.md`, capturar la pantalla (`Win+Shift+S`), guardar `demo-evidence/01-estructura.png`.
2. **Diagramas:** abrir cada `.mmd` en `diagramas/`; ir a https://mermaid.live ; pegar el código y comprobar que se renderiza. Guardar desde Export **PNG** con los nombres del directorio. Los PNG de referencia incluidos son esquemas de apoyo; los exportados por ustedes verifican la fuente Mermaid exacta.
3. **Prompts:** abrir `prompts-session1.md`. Ejecutar realmente P1, P2, P3, P4, P5 (mensaje inicial **y refinamiento posterior**) y P6, o documentar con exactitud interacciones previas que correspondan a cada técnica. Guardar capturas de texto del prompt y respuesta en `demo-evidence/prompt-P1.png` ... `prompt-P6.png` y `prompt-P5-iteracion.png`.
4. **Crítica real:** completar la tabla de la sección 4 de `prompts-session1.md` con respuesta observada, error/limitación real, corrección efectiva y ruta de captura. Si no hubo error, indicar qué se revisó y no inventar.
5. **Tres ambigüedades:** analizar tabla de sección 3 de prompts; ambas ratifican o cambian las decisiones (grafo no dirigido, empate lexicográfico, versión idempotente, p=1 excluido). Escribir acuerdos reales.
6. **Fixtures de pruebas (solo revisión documental ahora):** comparar `ejemplos/topology-example.json` (A–D) con `ejemplos/topology-isolated-example.json` (A–E, nodo E aislado); ver TC-10 y protocolo de reinicio de pruebas en `specs/06-test-specification.md`.
7. **Revisión cruzada:** Erika Juliana Diaz Yanalá revisa Controller/FR-01–06, Maria Camila Salazar Cifuentes revisa Router/FR-07–10, y ambas revisan NFR, API, secuencias, TC-01–22.
8. **Aprobación:** llenar **fecha y decisión real** de cada una en `specs/05-implementation-plan.md` sección 7; registrar commits auténticos e identificables de cada integrante en el repositorio compartido. No firmar en nombre de otra persona ni marcar realizado sin revisar.
9. **Congelar:** después de las verificaciones, registrar línea base S1-v1 y guardar copia ZIP/repositorio para Sesión 2. Si cambian algo, registrar razón y archivos afectados.

## Capturas recomendadas (no son todas obligatorias por la guía)

- `01-estructura.png`: explorador VS Code.
- `02-componentes.png`, `03-clases-controller.png`, `04-clases-router.png`: exportaciones del editor Mermaid Live.
- `05-secuencia-forwarding.png`, `06-secuencia-enlace.png`, `07-secuencia-timeout.png`: exportaciones de las tres secuencias.
- `prompt-P1.png` ... `prompt-P6.png`, `prompt-P5-iteracion.png`: evidencia auténtica de IA.

**No deben inventar** resultados `pytest`, respuestas de prompts ni confirmaciones de las integrantes. El JSON de ejemplo y las imágenes/diagramas son artefactos de diseño, no pruebas de software funcionando.
