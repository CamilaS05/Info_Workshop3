# Comprobaciones documentales de la carpeta

**Fecha de revisión documental:** 27/10/2026.

Verificación local automatizada **aprobada** para los siguientes puntos: seis especificaciones y un registro de prompts; identificación de las dos estudiantes; bloques Markdown balanceados; JSON válido en los ejemplos; FR-01–10, NFR-01–11 y TC-01–22 presentes; endpoints mínimos; tres diagramas estáticos, tres secuencias, seis fuentes Mermaid `.mmd` que coinciden con los bloques del texto; todos los participantes técnicos de secuencias aparecen en la arquitectura estática; seis esquemas PNG legibles por software; topología de ejemplo JSON válida y carpetas de implementación sin código.

**Importante:** esta comprobación verifica **estructura y sintaxis JSON**, no ejecución Python ni conformidad de un parser Mermaid. Las estudiantes deben abrir las fuentes Mermaid en el editor, ratificar decisiones, documentar las respuestas auténticas de IA y aprobar formalmente la línea base S1-v1.

**Responsables propuestos:** Erika Juliana Diaz Yanalá (Controller) y Maria Camila Salazar Cifuentes (Router).

## Actualización de auditoría definitiva — 28/10/2026

Se agregaron un fixture con E aislado para TC-10, el protocolo de copias independientes por prueba, aclaraciones de fallos de arranque y caso defensivo de Bellman-Ford, y criterios de medición p95. La nueva puntuación orientativa y los aspectos todavía pendientes se documentan en `AUDITORIA_Y_PUNTUACION_100.md`. Las comprobaciones estructurales se repiten antes de empaquetar.
