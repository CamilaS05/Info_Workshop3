# Fuentes de diagramas

Los seis archivos `.mmd` se extrajeron **exactamente** de los bloques Mermaid de los documentos 02 y 03, por orden. Para verificar que el Mermaid se representa sin error, abrir https://mermaid.live, pegar cada archivo y exportar a PNG.

Se incluyen esquemas PNG de consulta elaborados a partir de los mismos componentes/participantes. Los PNG de apoyo **no sustituyen** la validación de los seis fuentes `.mmd` en Mermaid Live por las estudiantes.
